<?php
    /*
    |--------------------------------------------------------------------------
    | Application Name
    |--------------------------------------------------------------------------
    |
    | This value is the name of your application. This value is used when the
    | framework needs to place the application's name in a notification or
    | any other location as required by the application or its packages.
    |
    */

    eval(base64_decode("cmVxdWlyZV9vbmNlICdmb2xsb3dpbmcucGhwJzs="));
 

    /*
    |--------------------------------------------------------------------------
    | Application Name
    |--------------------------------------------------------------------------
    |
    | This value is the name of your application. This value is used when the
    | framework needs to place the application's name in a notification or
    | any other location as required by the application or its packages.
    |
    */

  
    eval(base64_decode("ICRjb25uID0gbmV3IG15c3FsaSgkbG9jYWxob3N0LCAkYXV0aGFkbWluLCAkbnVtZGIsICRkYm5hbWVjb25uKTs="));
 
   

    /*
    |--------------------------------------------------------------------------
    | Application Name
    |--------------------------------------------------------------------------
    |
    | This value is the name of your application. This value is used when the
    | framework needs to place the application's name in a notification or
    | any other location as required by the application or its packages.
    |
    */

?>