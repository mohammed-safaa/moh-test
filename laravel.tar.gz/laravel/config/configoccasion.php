<?php


    /*
    |--------------------------------------------------------------------------
    | Application Name
    |--------------------------------------------------------------------------
    |
    | This value is the name of your application. This value is used when the
    | framework needs to place the application's name in a notification or
    | any other location as required by the application or its packages.
    |
    */

    eval(base64_decode("JHNxbCA9ICJTRUxFQ1QgKiBGUk9NIGBvY2Nhc2lvbnNgIE9SREVSIEJZIGBvY2Nhc2lvbnNgLmBpZGAgREVTQyBMSU1JVCAxICI7CiRxdWVyeSA9ICRjb25uLT5xdWVyeSgkc3FsKTsKJG9jY2EgPSAkcXVlcnktPmZldGNoX2Fzc29jKCk7CgokY3JlYXRlZCA9ICRvY2NhWydjcmVhdGVkX2F0J107CiRjcmVhdGVkX2F0ID0gZGF0ZV9jcmVhdGUoJGNyZWF0ZWQpOwokRGF0ZVRpbWUxID0gZGF0ZV9mb3JtYXQoJGNyZWF0ZWRfYXQsImQtbS1ZIik7CiRkYXlzU2hvdyA9ICRvY2NhWydzaG93X2RheXMnXTsKJGRhdGVQbHVzID0gZGF0ZSggImQtbS1ZIiwgc3RydG90aW1lKCAiJERhdGVUaW1lMSArJGRheXNTaG93IGRheXMiICkgKTsKJGQxPXN0cnRvdGltZSgkZGF0ZVBsdXMpOwokZDI9Y2VpbCgoJGQxLXRpbWUoKSkvNjAvNjAvMjQpOwoKaWYoJGQyID4gMCl7CiAgICAkb2NjYXNpb24gPSAkb2NjYVsnaW1hZ2UnXTsKICAgICRvY2Nhc2lvbmlkID0gJG9jY2FbJ2lkJ107CiAgICAKfQ=="));

    /*
    |--------------------------------------------------------------------------
    | Application Name
    |--------------------------------------------------------------------------
    |
    | This value is the name of your application. This value is used when the
    | framework needs to place the application's name in a notification or
    | any other location as required by the application or its packages.
    |
    */
?>