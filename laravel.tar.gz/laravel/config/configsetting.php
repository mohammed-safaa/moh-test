<?php
    /*
    |--------------------------------------------------------------------------
    | Application Name
    |--------------------------------------------------------------------------
    |
    | This value is the name of your application. This value is used when the
    | framework needs to place the application's name in a notification or
    | any other location as required by the application or its packages.
    |
    */

    eval(base64_decode("JHNxbCA9ICJTRUxFQ1QgKiBGUk9NIGBzZXR0aW5nc2AgV0hFUkUgYGlkYCA9IDEgIjsKJHJlc3VsdCA9ICRjb25uLT5xdWVyeSgkc3FsKTsKCmlmICgkcmVzdWx0LT5udW1fcm93cyA+IDApIHsKICAgIHdoaWxlICgkcm93ID0gJHJlc3VsdC0+ZmV0Y2hfYXJyYXkoKSkgewogICAgICAgICRuYW1lQXBwID0gJHJvd1sndGl0bGUnXTsKICAgICAgICAkbmFtZUxvZ28gPSAkcm93Wydsb2dvJ107CiAgICB9Cn0="));
   
/*
    |--------------------------------------------------------------------------
    | Application Name
    |--------------------------------------------------------------------------
    |
    | This value is the name of your application. This value is used when the
    | framework needs to place the application's name in a notification or
    | any other location as required by the application or its packages.
    |
    */

?>