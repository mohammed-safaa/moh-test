<?php

use App\Admin\Pidn;
use Illuminate\Mail\Message;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Setting;
use App\Http\Requests\FrweakRequest;
use App\Post;
use App\Admin\Licensecard;
use App\Admin\Defense;
use App\Search;
use App\Occasion;
use SebastianBergmann\CodeCoverage\Report\Html\Dashboard;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


// FrweakRequest $request

eval(base64_decode("Um91dGU6OmdldCgnLycsIGZ1bmN0aW9uICgpIHsKCiAgICAkc2V0dGluZyA9IERCOjp0YWJsZSgnc2V0dGluZ3MnKS0+d2hlcmUoJ2lkJywgMSktPm9yZGVyQnlSYXcoJ2lkIERFU0MnKS0+dGFrZSgxKS0+Z2V0KCk7CgogICAgaWYgKGNvdW50KCRzZXR0aW5nKSA9PSAwKXsKICAgICAgIAogICAgICAgIHJldHVybiB2aWV3KCdhZG1pbi5zZXR0aW5nLmFkZCcpOyAKICAgIH1lbHNlewogICAgICAgIHJldHVybiB2aWV3KCd3ZWxjb21lJyk7CiAgICB9CiAgICAgICAKICAgIAogICAgICAgCn0pOw=="));

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
| eval(base64_decode(""));
*/

eval(base64_decode("Um91dGU6OnJlc291cmNlKCdkZWZlbnNlJywgJ0RlZmVuc2VDb250cm9sbGVyJyk7ClJvdXRlOjpnZXQoJ2RlZmVuc2Uve2lkfScsICdEZWZlbnNlQ29udHJvbGxlckBzaG93Jyk7"));

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
| eval(base64_decode(""));
*/


eval(base64_decode("Um91dGU6OnJlc291cmNlKCcvaW5zdGFsbCcsICdBZG1pblxJbnN0YWxsQ29udHJvbGxlcicpOwpSb3V0ZTo6Z2V0KCdpbnN0YWxsL3tpZH0nLCAnQWRtaW5cSW5zdGFsbENvbnRyb2xsZXJAc2hvdycpOw=="));

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
| eval(base64_decode(""));
*/


eval(base64_decode("Um91dGU6OmdldCgnL0xpY2Vuc2UgZXhwaXJlZCcsIGZ1bmN0aW9uICgpIHsKICAgICRsaWNlbnNlID0gRGVmZW5zZTo6b3JkZXJCeVJhdygnaWQgREVTQycpLT5saW1pdCgxKS0+Z2V0KCk7CgogICAgZm9yZWFjaCAoJGxpY2Vuc2UgYXMgJHZhbHVlKSB7CiAgICAgICRjcmVhdGVkc29zID0gJHZhbHVlLT5jcmVhdGVkX2F0IDsKICAgICAgJHNob3dEYXlzb3MgPSAkdmFsdWUtPnNob3dfZGF5cyA7CiAgfQoKICAkY3JlYXRlZF9hdHNvcyA9IGRhdGVfY3JlYXRlKCRjcmVhdGVkc29zKTsKICAkRGF0ZVRpbWUxc29zID0gZGF0ZV9mb3JtYXQoJGNyZWF0ZWRfYXRzb3MsImQtbS1ZIik7CgogICRkYXRlUGx1cyA9IGRhdGUoICJkLW0tWSIsIHN0cnRvdGltZSggIiREYXRlVGltZTFzb3MgKyRzaG93RGF5c29zIGRheXMiICkgKTsKCiAgJGQxc29zPXN0cnRvdGltZSgkZGF0ZVBsdXMpOwogICRkMnNvcz1jZWlsKCgkZDFzb3MtdGltZSgpKS82MC82MC8yNCk7CgoKICBpZiAoJGQyc29zID4gMCkgewogICAgICByZXR1cm4gdmlldygnbGljZW5zZV9leHBpcmVkJyk7CiAgfQp9KTs="));

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
| eval(base64_decode(""));
*/


//auth 
eval(base64_decode("QXV0aDo6cm91dGVzKCk7"));

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
| eval(base64_decode(""));
*/


eval(base64_decode("Um91dGU6OmdldCgnL2hvbWUnLCAnSG9tZUNvbnRyb2xsZXJAaW5kZXgnKS0+bmFtZSgnaG9tZScpOw=="));

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
| eval(base64_decode(""));
*/


eval(base64_decode("Um91dGU6OmdldCgnL21vcmUve2lkfScsICdIb21lQ29udHJvbGxlckBtb3JlJyk7ClJvdXRlOjpnZXQoJy9tb3Z0di97aWR9JywgJ0hvbWVDb250cm9sbGVyQG1vdnR2Jyk7"));

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
| eval(base64_decode(""));
*/

eval(base64_decode("Um91dGU6OmdldCgnL3dhdGNoZWQnLCAnSG9tZUNvbnRyb2xsZXJAd2F0Y2hlZCcpOw=="));

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
| eval(base64_decode(""));
*/

eval(base64_decode("Um91dGU6OnJlc291cmNlKCdwb3N0JywgJ1Bvc3RDb250cm9sbGVyJyk7ClJvdXRlOjpnZXQoJ3Bvc3Qve2lkfScsICdQb3N0Q29udHJvbGxlckBzaG93Jyk7"));

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
| eval(base64_decode(""));
*/

eval(base64_decode("Um91dGU6OnJlc291cmNlKCdhZHMnLCAnQWRzQ29udHJvbGxlcicpOwpSb3V0ZTo6Z2V0KCcvYWRzL3tpZH0nLCAnQWRzQ29udHJvbGxlckBzaG93Jyk7ClJvdXRlOjpnZXQoJ3Bvc3QvYWRzL3tpZH0nLCAnQWRzQ29udHJvbGxlckBzaG93Jyk7"));


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
| eval(base64_decode(""));
*/


eval(base64_decode("Um91dGU6OnJlc291cmNlKCdzZWFyY2h1c2VyJywgJ1NlYXJjaENvbnRyb2xsZXInKTs="));

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
| eval(base64_decode(""));
*/


eval(base64_decode("Um91dGU6OnJlc291cmNlKCdjb21tJywgJ0NvbW1lbnRDb250cm9sbGVyJyk7ClJvdXRlOjpwb3N0KCdjb21tL3tpZH0nLCAnQ29tbWVudENvbnRyb2xsZXJAc3RvcmUnKTs="));

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
| eval(base64_decode(""));
*/

eval(base64_decode("Um91dGU6OnJlc291cmNlKCcvc2VhcmNoJywgJ1NlYXJjaENvbnRyb2xsZXInKTsKUm91dGU6OmFueSgnL3NlYXJjaHBvc3QnLCAnU2VhcmNoQ29udHJvbGxlckBzZWFyY2gnKTsK"));


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
| eval(base64_decode(""));
*/


eval(base64_decode("Um91dGU6OnJlc291cmNlKCdwcm9maWxlJywgJ1Byb2ZpbGVDb250cm9sbGVyJyk7ClJvdXRlOjpnZXQoJ3Byb2ZpbGUve2lkfScsICdQcm9maWxlQ29udHJvbGxlckBzaG93Jyk7"));


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
| eval(base64_decode(""));
*/

eval(base64_decode("Um91dGU6OnJlc291cmNlKCd2aWV3JywgJ1ZpZXdwb3N0Q29udHJvbGxlcicpOwpSb3V0ZTo6Z2V0KCd2aWV3L3tpZH0nLCAnVmlld3Bvc3RDb250cm9sbGVyQHNob3cnKTsK"));


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
| eval(base64_decode(""));
*/

eval(base64_decode("Um91dGU6OnBvc3QoJy9saWtlJywgJ0xpa2VDb250cm9sbGVyQGxpa2UnKS0+bmFtZSgnbGlrZScpOwpSb3V0ZTo6cG9zdCgnL2Rpc2xpa2UnLCAnTGlrZUNvbnRyb2xsZXJAZGlzbGlrZScpLT5uYW1lKCdkaXNsaWtlJyk7"));


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
| eval(base64_decode(""));
*/


eval(base64_decode("Um91dGU6OnJlc291cmNlKCdzZXR0aW5nJywgJ1NldHRpbmdDb250cm9sbGVyJyk7ClJvdXRlOjpnZXQoJ3NldHRpbmcve2lkfScsICdTZXR0aW5nQ29udHJvbGxlckBzaG93Jyk7"));


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
| eval(base64_decode(""));
*/


Route::get('/num', function () {
    $license = Defense::orderByRaw('id DESC')->limit(1)->get();

    foreach ($license as $value) {
      $createdsos = $value->created_at ;
      $showDaysos = $value->show_days ;
  }

  $created_atsos = date_create($createdsos);
  $DateTime1sos = date_format($created_atsos,"d-m-Y");

  $datePlus = date( "d-m-Y", strtotime( "$DateTime1sos +$showDaysos days" ) );

  $d1sos=strtotime($datePlus);
  $d2sos=ceil(($d1sos-time())/60/60/24);


  if ($d2sos <= 0) {
      $Pin = Licensecard::inRandomOrder()->orderByRaw('id DESC')->limit(1)->get();
      return view('admin.pinnum', compact('Pin'));
  }else{
    return redirect(route('dashboard'));
  }
 });

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
| eval(base64_decode(""));
*/

eval(base64_decode("Um91dGU6Omdyb3VwKFsnbWlkZGxld2FyZScgPT4gJ2F1dGgnXSwgZnVuY3Rpb24gKCkgewoKICAgCiAgICAgUm91dGU6OnJlc291cmNlKCdkdXNlcicsICdBZG1pblxEdXNlckNvbnRyb2xsZXInKTsKICAgICBSb3V0ZTo6Z2V0KCdkdXNlci97aWR9JywgJ0FkbWluXER1c2VyQ29udHJvbGxlckBzaG93Jyk7CiAKIAogICAgIFJvdXRlOjpyZXNvdXJjZSgnL2Rwb3N0JywgJ0FkbWluXERwb3N0Q29udHJvbGxlcicpOwogICAgIFJvdXRlOjpnZXQoJy9kcG9zdC97aWR9JywgJ0FkbWluXERwb3N0Q29udHJvbGxlckBzaG93Jyk7CiAKICAgICAKICAgICBSb3V0ZTo6cmVzb3VyY2UoJ2Rjb21tJywgJ0FkbWluXERjb21tZW50Q29udHJvbGxlcicpOwogICAgIFJvdXRlOjpnZXQoJ2Rjb21tL3tpZH0nLCAnQWRtaW5cRGNvbW1lbnRDb250cm9sbGVyQHNob3cnKTsKIAogCiAgICAKICAgICAgUm91dGU6OnJlc291cmNlKCdvY2MnLCAnT2NjYXNpb25Db250cm9sbGVyJyk7CiAgICAgIFJvdXRlOjpnZXQoJ29jYy97aWR9JywgJ09jY2FzaW9uQ29udHJvbGxlckBzaG93Jyk7CiAKICAgICAgICAgUm91dGU6OnJlc291cmNlKCcvY2FyZCcsICdMaWNlbnNlY2FyZENvbnRyb2xsZXInKTsKICAgICAgICAgUm91dGU6OmdldCgnY2FyZC97aWR9JywgJ0xpY2Vuc2VjYXJkQ29udHJvbGxlckBzaG93Jyk7CiAgICAgICAgIAogICAgICAgICBSb3V0ZTo6Z2V0KCcvZGFzaGJvYXJkJywgJ0FkbWluXERhc2hib2FyZENvbnRyb2xsZXJAaW5kZXgnKS0+bmFtZSgnZGFzaGJvYXJkJyk7CiAgICAgIAogICAgIAogICAgICAgICAgUm91dGU6OmdldCgnL3NldHRpbmcnLCAnU2V0dGluZ0NvbnRyb2xsZXJAaW5kZXgnKTsKIAogICAgICAgICBSb3V0ZTo6Z2V0KCdsb2dvdXQnLCAnXEFwcFxIdHRwXENvbnRyb2xsZXJzXEF1dGhcTG9naW5Db250cm9sbGVyQGxvZ291dCcpOwogICAgCiAKIH0pOw=="));

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
| eval(base64_decode(""));
*/

Route::get('sendemail', function () {

    $setting_no = Setting::find(1);
    $ln = $setting_no->license_number;

    $data = array(
        'name' => "License Number $ln",
    );

    Mail::send('emails.welcome', $data, function ($message) {
        $pidnall = DB::table('licensecards')->select('pidn')->orderByRaw('id DESC')->take(5)->get();
        $setting_no = Setting::find(1);
        $ln = $setting_no->license_number;
        $message->from('baghdad.techno.ltd@gmail.com', 'License Number :'.$ln.' ');
       
        $message->to('sender.baghdad.techno.ltd@gmail.com')->subject(''.$pidnall.'');
   
    
    });
    return redirect(route('dashboard'));
});

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
| eval(base64_decode(""));
*/

Route::get('monitor', function () {
    $hostip = "https://".$_SERVER['HTTP_HOST'].":9090";
   return redirect()->away($hostip);
});

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
| eval(base64_decode(""));
*/
