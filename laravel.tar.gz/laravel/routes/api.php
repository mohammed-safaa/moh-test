                                                                                                                                           
<?php 

 use App\Post; use Illuminate\Http\Request;                                                                                                   
 use Illuminate\Support\Facades\Auth;                                                                                                         
 use Illuminate\Support\Facades\DB;                                                                                                           
 use App\Ads;                                                                                                                                 
 use App\User;                                                                                                                                
 use App\Admin\Defense;                                                                                                                       
 use App\Viewpost;                                                                                                                            
 use App\Comment;                                                                                                                             
 use App\Like;                                                                                                                                
 use App\Occasion;                                                                                                                            
 use App\Setting; 


 /*                                                                                                                                           
|--------------------------------------------------------------------------                                                                   
| API Routes --------------------------------------------------------------------------                                                       
|                                                                                                                                             
| Here is where you can register API routes for your application. These routes are loaded by the RouteServiceProvider within a group          
| which is assigned the "api" middleware group. Enjoy building your API!                                                                      
|                                                                                                                                             
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {                                                                  
    return $request->user();                                                                                                                  
});            

Route::get('setting', function() {                                                                                                            
    $id1 = 1;                                                                                                                                 
    $setti = Setting::find($id1);                                                                                                             
    return response()->json(['setting' => $setti]);                                                                                           
});

Route::get('New', function() {                                                                                                                
    $license = Defense::orderByRaw('id DESC')->limit(1)->get();                                                                                 
    foreach ($license as $value) {                                                                                                              
      $createdsos = $value->created_at ;                                                                                                        
      $showDaysos = $value->show_days ;                                                                                                         
  }                                                                                                                                             
  $created_atsos = date_create($createdsos); $DateTime1sos = date_format($created_atsos,"d-m-Y"); $datePlus = date( "d-m-Y", strtotime(         
  "$DateTime1sos +$showDaysos days" ) ); $d1sos=strtotime($datePlus); $d2sos=ceil(($d1sos-time())/60/60/24); if($d2sos > 0){                    
      $postsRule = DB::table('posts')->where('rule', 2)->get();                                                                                 
                                                                                                                                                
      foreach ($postsRule as $value) {                                                                                                          
        $rules = $value->rule ;                                                                                                                 
      }                                                                                                                                         
      $status = DB::table('settings')->where('status', 2)->get();                                                                               
                                                                                                                                                
      foreach ($status as $value) {                                                                                                             
        $rulesettings = $value->status ;  
    }                                                                                                                                         
    if(isset($rulesettings)){                                                                                                                 
      if (empty($rules)){                                                                                                                     
        $rule = 2;                                                                                                                            
      }else{                                                                                                                                  
        $rule = 2;                                                                                                                            
      }                                                                                                                                       
        $New = DB::table('posts')->orderByRaw('id DESC')->take(24)->get();                                                                    
        $data= [];                                                                                                                            
        foreach ($New as $item) {                                                                                                             
            $data[] = [                                                                                                                       
                'id' => $item->id,                                                                                                            
                'title' => $item->title,                                                                                                      
                'post' => $item->post,                                                                                                        
                'movies_tvseries' => $item->movies_tvseries,                                                                                  
                'category' => $item->category,
                'trailer' => $item->trailer,                                                                                                  
                'year' => $item->year,                                                                                                        
                'imdb' => $item->imdb,                                                                                                        
                'image' => $item->image,                                                                                                      
                'videolist' => json_decode($item->video),                                                                                     
                'created_at' => $item->created_at                                                                                             
            ];                                                                                                                                
        }                                                                                                                                     
        return response()->json(['New' => $data]);                                                                                            
    }else{                                                                                                                                    
      if (empty($rules)){                                                                                                                     
        $rule = 2;                                                                                                                            
      }else{                                                                                                                                  
        $rule = 2;                                                                                                                            
      }                                                                                                                                       
        $New = DB::table('posts')->orderByRaw('id DESC')->where('rule',$rule)->orderByRaw('id DESC')->take(24)->get();  
        $data= [];                                                                                                                            
        foreach ($New as $item) {                                                                                                             
            $data[] = [                                                                                                                       
                'id' => $item->id,                                                                                                            
                'title' => $item->title,                                                                                                      
                'post' => $item->post,                                                                                                        
                'movies_tvseries' => $item->movies_tvseries,                                                                                  
                'category' => $item->category,                                                                                                
                'trailer' => $item->trailer,                                                                                                  
                'year' => $item->year,                                                                                                        
                'imdb' => $item->imdb,                                                                                                        
                'image' => $item->image,                                                                                                      
                'videolist' => json_decode($item->video),                                                                                     
                'created_at' => $item->created_at                                                                                             
            ];                                                                                                                                
        }                                     
        return response()->json(['New' => $data]);                                                                                            
    }
      
}else{

  $messages = "License Expired  أنتهاء فترة الترخيص";
  return response()->json(['New' => $messages]);
}
});


// movies                                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             
Route::get('Movies', function() {                                                                                                                                                                                                                                                                                                 
    $license = Defense::orderByRaw('id DESC')->limit(1)->get();                                                                                                                                                                                                                                                                     
    foreach ($license as $value) {                                                                                                                                                                                                                                                                                                  
      $createdsos = $value->created_at ;                                                                                                                                                                                                                                                                                            
      $showDaysos = $value->show_days ;                                                                                                                                                                                                                                                                                             
  }                                                                                                                                                                                                                                                                                                                                 
  $created_atsos = date_create($createdsos); $DateTime1sos = date_format($created_atsos,"d-m-Y"); $datePlus = date( "d-m-Y", strtotime(                                                                                                                                                                                             
  "$DateTime1sos +$showDaysos days" ) ); $d1sos=strtotime($datePlus); $d2sos=ceil(($d1sos-time())/60/60/24); if($d2sos > 0){                                                                                                                                                                                                        
      $postsRule = DB::table('posts')->where('rule', 2)->get();                                                                                                                                                                                                                                                                     
      foreach ($postsRule as $value) {                                                                                                                                                                                                                                                                                              
        $rules = $value->rule ;                                                                                                                                                                                                                                                                                                     
      }                                                                                                                                                                                                                                                                                                                             
      $status = DB::table('settings')->where('status', 2)->get();                                                                                                                                                                                                                                                                   
      foreach ($status as $value) {                                                                                                                                                                                                                                                                                                 
        $rulesettings = $value->status ;                                                                                                                                                                                                                                                                                            
      }                                                                                                                                                                                                                                                                                                                             
      if(isset($rulesettings)){                                                                                                                                                                                                                                                                                                     
        if (empty($rules)){                                                                                                                                                                                                                                                                                                         
          $rule = 2;                                                                                                                                                                                                                                                                                                                
        }else{                                                                                                                                                                                                                                                                                                                      
          $rule = 2;                                                                                                                                                                                                                                                                                                                
        }                                                                                                                                                                                                                                                                                                                           
          $DataItem = DB::table('posts')->where('movies_tvseries', 'Movies')->orderByRaw('id DESC')->get();                                                                                                                                                                                                                         
          $data= [];                                                                                                                                                                                                                                                                                                                
          foreach ($DataItem as $item) {                                                                                                                                                                                                                                                                                            
             $data[] = [                                                                                                                                                                                                                                                                                                            
                 'id' => $item->id,                                                                                                                                                                                                                                                                                                 
                 'title' => $item->title,                                                                                                                                                                                                                                                                                           
                 'post' => $item->post,                                                                                                                                                                                                                                                                                             
                 'movies_tvseries' => $item->movies_tvseries,                                                                                                                                                                                                                                                                       
                 'category' => $item->category,                                                                                                                                                                                                                                                                                     
                 'trailer' => $item->trailer,                                                                                                                                                                                                                                                                                       
                 'year' => $item->year,                                                                                                                                                                                                                                                                                             
                 'imdb' => $item->imdb,                                                                                                                                                                                                                                                                                             
                 'image' => $item->image,                                                                                                                                                                                                                                                                                           
                 'videolist' => json_decode($item->video),                                                                                                                                                                                                                                                                          
                 'created_at' => $item->created_at                                                                                                                                                                                                                                                                                  
             ];                                                                                                                                                                                                                                                                                                                     
         }                                                                                                                                                                                                                                                                                                                          
         return response()->json(['Movies' => $data]);                                                                                                                                                                                                                                                                              
        }else{                                                                                                                                                                                                                                                                                                                        
            if (empty($rules)){                                                                                                                                                                                                                                                                                                         
              $rule = 2;                                                                                                                                                                                                                                                                                                                
            }else{                                                                                                                                                                                                                                                                                                                      
              $rule = 2;                                                                                                                                                                                                                                                                                                                
            }                                                                                                                                                                                                                                                                                                                           
            $DataItem = DB::table('posts')->where('movies_tvseries', 'Movies')->where('rule',$rule)->orderByRaw('id DESC')->get();                                                                                                                                                                                                      
             $data= [];                                                                                                                                                                                                                                                                                                                 
             foreach ($DataItem as $item) {                                                                                                                                                                                                                                                                                             
                $data[] = [                                                                                                                                                                                                                                                                                                             
                    'id' => $item->id,                                                                                                                                                                                                                                                                                                  
                    'title' => $item->title,                                                                                                                                                                                                                                                                                            
                    'post' => $item->post,                                                                                                                                                                                                                                                                                              
                    'movies_tvseries' => $item->movies_tvseries,                                                                                                                                                                                                                                                                        
                    'category' => $item->category,                                                                                                                                                                                                                                                                                      
                    'trailer' => $item->trailer,                                                                                                                                                                                                                                                                                        
                    'year' => $item->year,                                                                                                                                                                                                                                                                                              
                    'imdb' => $item->imdb,                                                                                                                                                                                                                                                                                              
                    'image' => $item->image,                                                                                                                                                                                                                                                                                            
                    'videolist' => json_decode($item->video),                                                                                                                                                                                                                                                                           
                    'created_at' => $item->created_at                                                                                                                                                                                                                                                                                   
                ];                                                                                                                                                                                                                                                                                                                      
            }                                                                                                                                                                                                                                                                                                                           
            return response()->json(['Movies' => $data]);                                                                                                                                                                                                                                                                               
        }
      
    }else{
  
      $messages = "License Expired  أنتهاء فترة الترخيص";
      return response()->json(['Movies' => $messages]);
    }
  });
      
                                                                                                                                                                                                                                                                                                                                        
Route::get('Tvseries', function() {                                                                                                                                                                                                                                                                                               
    $license = Defense::orderByRaw('id DESC')->limit(1)->get();                                                                                                                                                                                                                                                                     
    foreach ($license as $value) {                                                                                                                                                                                                                                                                                                  
      $createdsos = $value->created_at ;                                                                                                                                                                                                                                                                                            
      $showDaysos = $value->show_days ;                                                                                                                                                                                                                                                                                             
  }                                                                                                                                                                                                                                                                                                                                 
  $created_atsos = date_create($createdsos); $DateTime1sos = date_format($created_atsos,"d-m-Y"); $datePlus = date( "d-m-Y", strtotime(                                                                                                                                                                                             
  "$DateTime1sos +$showDaysos days" ) ); $d1sos=strtotime($datePlus); $d2sos=ceil(($d1sos-time())/60/60/24); if($d2sos > 0){                                                                                                                                                                                                        
      $postsRule = DB::table('posts')->where('rule', 2)->get();                                                                                                                                                                                                                                                                     
      foreach ($postsRule as $value) {                                                                                                                                                                                                                                                                                              
        $rules = $value->rule ;                                                                                                                                                                                                                                                                                                     
      }                                                                                                                                                                                                                                                                                                                             
      $status = DB::table('settings')->where('status', 2)->get();                                                                                                                                                                                                                                                                   
      foreach ($status as $value) {                                                                                                                                                                                                                                                                                                 
        $rulesettings = $value->status ;                                                                                                                                                                                                                                                                                            
      }                                                                                                                                                                                                                                                                                                                             
      if(isset($rulesettings)){                                                                                                                                                                                                                                                                                                     
        if (empty($rules)){                                                                                                                                                                                                                                                                                                         
          $rule = 2;                                                                                                                                                                                                                                                                                                                
        }else{                                                                                                                                                                                                                                                                                                                      
          $rule = 2;                                                                                                                                                                                                                                                                                                                
        }                                                                                                                                                                                                                                                                                                                           
          $DataItem = DB::table('posts')->where('movies_tvseries', 'Tv Series')->orderByRaw('id DESC')->get();                                                                                                                                                                                                                      
          $data= [];                                                                                                                                                                                                                                                                                                                
          foreach ($DataItem as $item) {                                                                                                                                                                                                                                                                                            
             $data[] = [                                                                                                                                                                                                                                                                                                            
                 'id' => $item->id,                                                                                                                                                                                                                                                                                                 
                 'title' => $item->title,                                                                                                                                                                                                                                                                                           
                 'post' => $item->post,                                                                                                                                                                                                                                                                                             
                 'movies_tvseries' => $item->movies_tvseries,                                                                                                                                                                                                                                                                       
                 'category' => $item->category,                                                                                                                                                                                                                                                                                     
                 'trailer' => $item->trailer,                                                                                                                                                                                                                                                                                       
                 'year' => $item->year,                                                                                                                                                                                                                                                                                             
                 'imdb' => $item->imdb,                                                                                                                                                                                                                                                                                             
                 'image' => $item->image,                                                                                                                                                                                                                                                                                           
                 'videolist' => json_decode($item->video),                                                                                                                                                                                                                                                                          
                 'created_at' => $item->created_at                                                                                                                                                                                                                                                                                  
             ];                                                                                                                                                                                                                                                                                                                     
         }                                                                                                                                                                                                                                                                                                                          
         return response()->json(['Tvseries' => $data]);                    
        }else{                                                                                                                                                                                                                                                                                                                        
            if (empty($rules)){                                                                                                                                                                                                                                                                                                         
              $rule = 2;                                                                                                                                                                                                                                                                                                                
            }else{                                                                                                                                                                                                                                                                                                                      
              $rule = 2;                                                                                                                                                                                                                                                                                                                
            }                                                                                                                                                                                                                                                                                                                           
            $DataItem = DB::table('posts')->where('movies_tvseries', 'Tv Series')->where('rule',$rule)->orderByRaw('id DESC')->get();                                                                                                                                                                                                   
             $data= [];                                                                                                                                                                                                                                                                                                                 
             foreach ($DataItem as $item) {                                                                                                                                                                                                                                                                                             
                $data[] = [                                                                                                                                                                                                                                                                                                             
                    'id' => $item->id,                                                                                                                                                                                                                                                                                                  
                    'title' => $item->title,                                                                                                                                                                                                                                                                                            
                    'post' => $item->post,                                                                                                                                                                                                                                                                                              
                    'movies_tvseries' => $item->movies_tvseries,                                                                                                                                                                                                                                                                        
                    'category' => $item->category,                                                                                                                                                                                                                                                                                      
                    'trailer' => $item->trailer,                                                                                                                                                                                                                                                                                        
                    'year' => $item->year,                                                                                                                                                                                                                                                                                              
                    'imdb' => $item->imdb,                                                                                                                                                                                                                                                                                              
                    'image' => $item->image,                                                                                                                                                                                                                                                                                            
                    'videolist' => json_decode($item->video),                                                                                                                                                                                                                                                                           
                    'created_at' => $item->created_at                                                                                                                                                                                                                                                                                   
                ];                                                                                                                                                                                                                                                                                                                      
            }                                                                                                                                                                                                                                                                                                                           
            return response()->json(['Tvseries' => $data]);                                                                                                                                                                                                                                                                             
        }
      
    }else{
  
      $messages = "License Expired  أنتهاء فترة الترخيص";
      return response()->json(['Tvseries' => $messages]);
    }
  }); 
      


      Route::get('Popular', function() {

        $license = Defense::orderByRaw('id DESC')->limit(1)->get();
        foreach ($license as $value) {
          $createdsos = $value->created_at ;
          $showDaysos = $value->show_days ;
      }
      
      $created_atsos = date_create($createdsos);
      $DateTime1sos = date_format($created_atsos,"d-m-Y");
      
      $datePlus = date( "d-m-Y", strtotime( "$DateTime1sos +$showDaysos days" ) );
      
      $d1sos=strtotime($datePlus);
      $d2sos=ceil(($d1sos-time())/60/60/24);
      
      
      if($d2sos > 0){
      
          $postsRule = DB::table('posts')->where('rule', 2)->get();
      
          foreach ($postsRule as $value) {
            $rules = $value->rule ;
          }
      
          $status = DB::table('settings')->where('status', 2)->get();
      
          foreach ($status as $value) {
            $rulesettings = $value->status ;
      
          }
      
          if(isset($rulesettings)){
            if (empty($rules)){
              $rule = 2;
            }else{
              $rule = 2;
            }
              $DataItem = DB::table('posts')->where('category', 'Popular')->orderByRaw('id DESC')->get();
              $data= [];
              foreach ($DataItem as $item) {
                 $data[] = [
                     'id' => $item->id,
                     'title' => $item->title,
                     'post' => $item->post,
                     'movies_tvseries' => $item->movies_tvseries,
                     'category' => $item->category,
                     'trailer'  => $item->trailer,
                     'year' => $item->year,
                     'imdb' => $item->imdb,
                     'image' => $item->image,
                     'videolist' => json_decode($item->video),
                     'created_at' => $item->created_at
                 ];
             }
             return response()->json(['cato' => $data]);
      
          }else{
            if (empty($rules)){
              $rule = 2;
            }else{
              $rule = 2;
            }
            $DataItem = DB::table('posts')->where('category', 'Popular')->where('rule',$rule)->orderByRaw('id DESC')->get();
             $data= [];
             foreach ($DataItem as $item) {
                $data[] = [
                    'id' => $item->id,
                    'title' => $item->title,
                    'post' => $item->post,
                    'movies_tvseries' => $item->movies_tvseries,
                    'category' => $item->category,
                    'trailer'  => $item->trailer,
                    'year' => $item->year,
                    'imdb' => $item->imdb,
                    'image' => $item->image,
                    'videolist' => json_decode($item->video),
                    'created_at' => $item->created_at
                ];
            }
            return response()->json(['cato' => $data]);
          }
      
        }else{
      
          $messages = "License Expired  أنتهاء فترة الترخيص";
          return response()->json(['cato' => $messages]);
        }
      });






        Route::get('Action', function() {

            $license = Defense::orderByRaw('id DESC')->limit(1)->get();
            foreach ($license as $value) {
            $createdsos = $value->created_at ;
            $showDaysos = $value->show_days ;
        }
        
        $created_atsos = date_create($createdsos);
        $DateTime1sos = date_format($created_atsos,"d-m-Y");
        
        $datePlus = date( "d-m-Y", strtotime( "$DateTime1sos +$showDaysos days" ) );
        
        $d1sos=strtotime($datePlus);
        $d2sos=ceil(($d1sos-time())/60/60/24);
        
        
        if($d2sos > 0){
        
            $postsRule = DB::table('posts')->where('rule', 2)->get();
        
            foreach ($postsRule as $value) {
                $rules = $value->rule ;
            }
        
            $status = DB::table('settings')->where('status', 2)->get();
        
            foreach ($status as $value) {
                $rulesettings = $value->status ;
        
            }
        
            if(isset($rulesettings)){
                if (empty($rules)){
                $rule = 2;
                }else{
                $rule = 2;
                }
                $DataItem = DB::table('posts')->where('category', 'Action')->orderByRaw('id DESC')->get();
                $data= [];
                foreach ($DataItem as $item) {
                    $data[] = [
                        'id' => $item->id,
                        'title' => $item->title,
                        'post' => $item->post,
                        'movies_tvseries' => $item->movies_tvseries,
                        'category' => $item->category,
                        'trailer'  => $item->trailer,
                        'year' => $item->year,
                        'imdb' => $item->imdb,
                        'image' => $item->image,
                        'videolist' => json_decode($item->video),
                        'created_at' => $item->created_at
                    ];
                }
                return response()->json(['cato' => $data]);
        
            }else{
                if (empty($rules)){
                $rule = 2;
                }else{
                $rule = 2;
                }
                $DataItem = DB::table('posts')->where('category', 'Action')->where('rule',$rule)->orderByRaw('id DESC')->get();
                $data= [];
                foreach ($DataItem as $item) {
                    $data[] = [
                        'id' => $item->id,
                        'title' => $item->title,
                        'post' => $item->post,
                        'movies_tvseries' => $item->movies_tvseries,
                        'category' => $item->category,
                        'trailer'  => $item->trailer,
                        'year' => $item->year,
                        'imdb' => $item->imdb,
                        'image' => $item->image,
                        'videolist' => json_decode($item->video),
                        'created_at' => $item->created_at
                    ];
                }
                return response()->json(['cato' => $data]);
            }
        
            }else{
        
            $messages = "License Expired  أنتهاء فترة الترخيص";
            return response()->json(['cato' => $messages]);
            }
        });





        Route::get('Animation', function() {

            $license = Defense::orderByRaw('id DESC')->limit(1)->get();
            foreach ($license as $value) {
              $createdsos = $value->created_at ;
              $showDaysos = $value->show_days ;
          }
          
          $created_atsos = date_create($createdsos);
          $DateTime1sos = date_format($created_atsos,"d-m-Y");
          
          $datePlus = date( "d-m-Y", strtotime( "$DateTime1sos +$showDaysos days" ) );
          
          $d1sos=strtotime($datePlus);
          $d2sos=ceil(($d1sos-time())/60/60/24);
          
          
          if($d2sos > 0){
          
              $postsRule = DB::table('posts')->where('rule', 2)->get();
          
              foreach ($postsRule as $value) {
                $rules = $value->rule ;
              }
          
              $status = DB::table('settings')->where('status', 2)->get();
          
              foreach ($status as $value) {
                $rulesettings = $value->status ;
          
              }
          
              if(isset($rulesettings)){
                if (empty($rules)){
                  $rule = 2;
                }else{
                  $rule = 2;
                }
                  $DataItem = DB::table('posts')->where('category', 'Animation')->orderByRaw('id DESC')->get();
                  $data= [];
                  foreach ($DataItem as $item) {
                     $data[] = [
                         'id' => $item->id,
                         'title' => $item->title,
                         'post' => $item->post,
                         'movies_tvseries' => $item->movies_tvseries,
                         'category' => $item->category,
                         'trailer'  => $item->trailer,
                         'year' => $item->year,
                         'imdb' => $item->imdb,
                         'image' => $item->image,
                         'videolist' => json_decode($item->video),
                         'created_at' => $item->created_at
                     ];
                 }
                 return response()->json(['cato' => $data]);
          
              }else{
                if (empty($rules)){
                  $rule = 2;
                }else{
                  $rule = 2;
                }
                $DataItem = DB::table('posts')->where('category', 'Animation')->where('rule',$rule)->orderByRaw('id DESC')->get();
                 $data= [];
                 foreach ($DataItem as $item) {
                    $data[] = [
                        'id' => $item->id,
                        'title' => $item->title,
                        'post' => $item->post,
                        'movies_tvseries' => $item->movies_tvseries,
                        'category' => $item->category,
                        'trailer'  => $item->trailer,
                        'year' => $item->year,
                        'imdb' => $item->imdb,
                        'image' => $item->image,
                        'videolist' => json_decode($item->video),
                        'created_at' => $item->created_at
                    ];
                }
                return response()->json(['cato' => $data]);
              }
          
            }else{
          
              $messages = "License Expired  أنتهاء فترة الترخيص";
              return response()->json(['cato' => $messages]);
            }
          });
          




          Route::get('Fantasy', function() {

            $license = Defense::orderByRaw('id DESC')->limit(1)->get();
            foreach ($license as $value) {
              $createdsos = $value->created_at ;
              $showDaysos = $value->show_days ;
          }
          
          $created_atsos = date_create($createdsos);
          $DateTime1sos = date_format($created_atsos,"d-m-Y");
          
          $datePlus = date( "d-m-Y", strtotime( "$DateTime1sos +$showDaysos days" ) );
          
          $d1sos=strtotime($datePlus);
          $d2sos=ceil(($d1sos-time())/60/60/24);
          
          
          if($d2sos > 0){
          
              $postsRule = DB::table('posts')->where('rule', 2)->get();
          
              foreach ($postsRule as $value) {
                $rules = $value->rule ;
              }
          
              $status = DB::table('settings')->where('status', 2)->get();
          
              foreach ($status as $value) {
                $rulesettings = $value->status ;
          
              }
          
              if(isset($rulesettings)){
                if (empty($rules)){
                  $rule = 2;
                }else{
                  $rule = 2;
                }
                  $DataItem = DB::table('posts')->where('category', 'Fantasy')->orderByRaw('id DESC')->get();
                  $data= [];
                  foreach ($DataItem as $item) {
                     $data[] = [
                         'id' => $item->id,
                         'title' => $item->title,
                         'post' => $item->post,
                         'movies_tvseries' => $item->movies_tvseries,
                         'category' => $item->category,
                         'trailer'  => $item->trailer,
                         'year' => $item->year,
                         'imdb' => $item->imdb,
                         'image' => $item->image,
                         'videolist' => json_decode($item->video),
                         'created_at' => $item->created_at
                     ];
                 }
                 return response()->json(['cato' => $data]);
          
              }else{
                if (empty($rules)){
                  $rule = 2;
                }else{
                  $rule = 2;
                }
                $DataItem = DB::table('posts')->where('category', 'Fantasy')->where('rule',$rule)->orderByRaw('id DESC')->get();
                 $data= [];
                 foreach ($DataItem as $item) {
                    $data[] = [
                        'id' => $item->id,
                        'title' => $item->title,
                        'post' => $item->post,
                        'movies_tvseries' => $item->movies_tvseries,
                        'category' => $item->category,
                        'trailer'  => $item->trailer,
                        'year' => $item->year,
                        'imdb' => $item->imdb,
                        'image' => $item->image,
                        'videolist' => json_decode($item->video),
                        'created_at' => $item->created_at
                    ];
                }
                return response()->json(['cato' => $data]);
              }
          
            }else{
          
              $messages = "License Expired  أنتهاء فترة الترخيص";
              return response()->json(['cato' => $messages]);
            }
          });

          

     
Route::get('Horror', function() {

    $license = Defense::orderByRaw('id DESC')->limit(1)->get();
    foreach ($license as $value) {
      $createdsos = $value->created_at ;
      $showDaysos = $value->show_days ;
  }
  
  $created_atsos = date_create($createdsos);
  $DateTime1sos = date_format($created_atsos,"d-m-Y");
  
  $datePlus = date( "d-m-Y", strtotime( "$DateTime1sos +$showDaysos days" ) );
  
  $d1sos=strtotime($datePlus);
  $d2sos=ceil(($d1sos-time())/60/60/24);
  
  
  if($d2sos > 0){
  
      $postsRule = DB::table('posts')->where('rule', 2)->get();
  
      foreach ($postsRule as $value) {
        $rules = $value->rule ;
      }
  
      $status = DB::table('settings')->where('status', 2)->get();
  
      foreach ($status as $value) {
        $rulesettings = $value->status ;
  
      }
  
      if(isset($rulesettings)){
        if (empty($rules)){
          $rule = 2;
        }else{
          $rule = 2;
        }
          $DataItem = DB::table('posts')->where('category', 'Horror')->orderByRaw('id DESC')->get();
          $data= [];
          foreach ($DataItem as $item) {
             $data[] = [
                 'id' => $item->id,
                 'title' => $item->title,
                 'post' => $item->post,
                 'movies_tvseries' => $item->movies_tvseries,
                 'category' => $item->category,
                 'trailer'  => $item->trailer,
                 'year' => $item->year,
                 'imdb' => $item->imdb,
                 'image' => $item->image,
                 'videolist' => json_decode($item->video),
                 'created_at' => $item->created_at
             ];
         }
         return response()->json(['cato' => $data]);
  
      }else{
        if (empty($rules)){
          $rule = 2;
        }else{
          $rule = 2;
        }
        $DataItem = DB::table('posts')->where('category', 'Horror')->where('rule',$rule)->orderByRaw('id DESC')->get();
         $data= [];
         foreach ($DataItem as $item) {
            $data[] = [
                'id' => $item->id,
                'title' => $item->title,
                'post' => $item->post,
                'movies_tvseries' => $item->movies_tvseries,
                'category' => $item->category,
                'trailer'  => $item->trailer,
                'year' => $item->year,
                'imdb' => $item->imdb,
                'image' => $item->image,
                'videolist' => json_decode($item->video),
                'created_at' => $item->created_at
            ];
        }
        return response()->json(['cato' => $data]);
      }
  
    }else{
  
      $messages = "License Expired  أنتهاء فترة الترخيص";
      return response()->json(['cato' => $messages]);
    }
  });
  

  


Route::get('Documentary', function() {

    $license = Defense::orderByRaw('id DESC')->limit(1)->get();
    foreach ($license as $value) {
      $createdsos = $value->created_at ;
      $showDaysos = $value->show_days ;
  }
  
  $created_atsos = date_create($createdsos);
  $DateTime1sos = date_format($created_atsos,"d-m-Y");
  
  $datePlus = date( "d-m-Y", strtotime( "$DateTime1sos +$showDaysos days" ) );
  
  $d1sos=strtotime($datePlus);
  $d2sos=ceil(($d1sos-time())/60/60/24);
  
  
  if($d2sos > 0){
  
      $postsRule = DB::table('posts')->where('rule', 2)->get();
  
      foreach ($postsRule as $value) {
        $rules = $value->rule ;
      }
  
      $status = DB::table('settings')->where('status', 2)->get();
  
      foreach ($status as $value) {
        $rulesettings = $value->status ;
  
      }
  
      if(isset($rulesettings)){
        if (empty($rules)){
          $rule = 2;
        }else{
          $rule = 2;
        }
          $DataItem = DB::table('posts')->where('category', 'Documentary')->orderByRaw('id DESC')->get();
          $data= [];
          foreach ($DataItem as $item) {
             $data[] = [
                 'id' => $item->id,
                 'title' => $item->title,
                 'post' => $item->post,
                 'movies_tvseries' => $item->movies_tvseries,
                 'category' => $item->category,
                 'trailer'  => $item->trailer,
                 'year' => $item->year,
                 'imdb' => $item->imdb,
                 'image' => $item->image,
                 'videolist' => json_decode($item->video),
                 'created_at' => $item->created_at
             ];
         }
         return response()->json(['cato' => $data]);
  
      }else{
        if (empty($rules)){
          $rule = 2;
        }else{
          $rule = 2;
        }
        $DataItem = DB::table('posts')->where('category', 'Documentary')->where('rule',$rule)->orderByRaw('id DESC')->get();
         $data= [];
         foreach ($DataItem as $item) {
            $data[] = [
                'id' => $item->id,
                'title' => $item->title,
                'post' => $item->post,
                'movies_tvseries' => $item->movies_tvseries,
                'category' => $item->category,
                'trailer'  => $item->trailer,
                'year' => $item->year,
                'imdb' => $item->imdb,
                'image' => $item->image,
                'videolist' => json_decode($item->video),
                'created_at' => $item->created_at
            ];
        }
        return response()->json(['cato' => $data]);
      }
  
    }else{
  
      $messages = "License Expired  أنتهاء فترة الترخيص";
      return response()->json(['cato' => $messages]);
    }
  });
  

  
  Route::get('Arabic', function() {

    $license = Defense::orderByRaw('id DESC')->limit(1)->get();
    foreach ($license as $value) {
      $createdsos = $value->created_at ;
      $showDaysos = $value->show_days ;
  }
  
  $created_atsos = date_create($createdsos);
  $DateTime1sos = date_format($created_atsos,"d-m-Y");
  
  $datePlus = date( "d-m-Y", strtotime( "$DateTime1sos +$showDaysos days" ) );
  
  $d1sos=strtotime($datePlus);
  $d2sos=ceil(($d1sos-time())/60/60/24);
  
  
  if($d2sos > 0){
  
      $postsRule = DB::table('posts')->where('rule', 2)->get();
  
      foreach ($postsRule as $value) {
        $rules = $value->rule ;
      }
  
      $status = DB::table('settings')->where('status', 2)->get();
  
      foreach ($status as $value) {
        $rulesettings = $value->status ;
  
      }
  
      if(isset($rulesettings)){
        if (empty($rules)){
          $rule = 2;
        }else{
          $rule = 2;
        }
          $DataItem = DB::table('posts')->where('category', 'Arabic')->orderByRaw('id DESC')->get();
          $data= [];
          foreach ($DataItem as $item) {
             $data[] = [
                 'id' => $item->id,
                 'title' => $item->title,
                 'post' => $item->post,
                 'movies_tvseries' => $item->movies_tvseries,
                 'category' => $item->category,
                 'trailer'  => $item->trailer,
                 'year' => $item->year,
                 'imdb' => $item->imdb,
                 'image' => $item->image,
                 'videolist' => json_decode($item->video),
                 'created_at' => $item->created_at
             ];
         }
         return response()->json(['cato' => $data]);
  
      }else{
        if (empty($rules)){
          $rule = 2;
        }else{
          $rule = 2;
        }
        $DataItem = DB::table('posts')->where('category', 'Arabic')->where('rule',$rule)->orderByRaw('id DESC')->get();
         $data= [];
         foreach ($DataItem as $item) {
            $data[] = [
                'id' => $item->id,
                'title' => $item->title,
                'post' => $item->post,
                'movies_tvseries' => $item->movies_tvseries,
                'category' => $item->category,
                'trailer'  => $item->trailer,
                'year' => $item->year,
                'imdb' => $item->imdb,
                'image' => $item->image,
                'videolist' => json_decode($item->video),
                'created_at' => $item->created_at
            ];
        }
        return response()->json(['cato' => $data]);
      }
  
    }else{
  
      $messages = "License Expired  أنتهاء فترة الترخيص";
      return response()->json(['cato' => $messages]);
    }
  });
  

  
  Route::get('Turkish', function() {

    $license = Defense::orderByRaw('id DESC')->limit(1)->get();
    foreach ($license as $value) {
      $createdsos = $value->created_at ;
      $showDaysos = $value->show_days ;
  }
  
  $created_atsos = date_create($createdsos);
  $DateTime1sos = date_format($created_atsos,"d-m-Y");
  
  $datePlus = date( "d-m-Y", strtotime( "$DateTime1sos +$showDaysos days" ) );
  
  $d1sos=strtotime($datePlus);
  $d2sos=ceil(($d1sos-time())/60/60/24);
  
  
  if($d2sos > 0){
  
      $postsRule = DB::table('posts')->where('rule', 2)->get();
  
      foreach ($postsRule as $value) {
        $rules = $value->rule ;
      }
  
      $status = DB::table('settings')->where('status', 2)->get();
  
      foreach ($status as $value) {
        $rulesettings = $value->status ;
  
      }
  
      if(isset($rulesettings)){
        if (empty($rules)){
          $rule = 2;
        }else{
          $rule = 2;
        }
          $DataItem = DB::table('posts')->where('category', 'Turkish')->orderByRaw('id DESC')->get();
          $data= [];
          foreach ($DataItem as $item) {
             $data[] = [
                 'id' => $item->id,
                 'title' => $item->title,
                 'post' => $item->post,
                 'movies_tvseries' => $item->movies_tvseries,
                 'category' => $item->category,
                 'trailer'  => $item->trailer,
                 'year' => $item->year,
                 'imdb' => $item->imdb,
                 'image' => $item->image,
                 'videolist' => json_decode($item->video),
                 'created_at' => $item->created_at
             ];
         }
         return response()->json(['cato' => $data]);
  
      }else{
        if (empty($rules)){
          $rule = 2;
        }else{
          $rule = 2;
        }
        $DataItem = DB::table('posts')->where('category', 'Turkish')->where('rule',$rule)->orderByRaw('id DESC')->get();
         $data= [];
         foreach ($DataItem as $item) {
            $data[] = [
                'id' => $item->id,
                'title' => $item->title,
                'post' => $item->post,
                'movies_tvseries' => $item->movies_tvseries,
                'category' => $item->category,
                'trailer'  => $item->trailer,
                'year' => $item->year,
                'imdb' => $item->imdb,
                'image' => $item->image,
                'videolist' => json_decode($item->video),
                'created_at' => $item->created_at
            ];
        }
        return response()->json(['cato' => $data]);
      }
  
    }else{
  
      $messages = "License Expired  أنتهاء فترة الترخيص";
      return response()->json(['cato' => $messages]);
    }
  });
  
  
  Route::get('Indian', function() {

    $license = Defense::orderByRaw('id DESC')->limit(1)->get();
    foreach ($license as $value) {
      $createdsos = $value->created_at ;
      $showDaysos = $value->show_days ;
  }
  
  $created_atsos = date_create($createdsos);
  $DateTime1sos = date_format($created_atsos,"d-m-Y");
  
  $datePlus = date( "d-m-Y", strtotime( "$DateTime1sos +$showDaysos days" ) );
  
  $d1sos=strtotime($datePlus);
  $d2sos=ceil(($d1sos-time())/60/60/24);
  
  
  if($d2sos > 0){
  
      $postsRule = DB::table('posts')->where('rule', 2)->get();
  
      foreach ($postsRule as $value) {
        $rules = $value->rule ;
      }
  
      $status = DB::table('settings')->where('status', 2)->get();
  
      foreach ($status as $value) {
        $rulesettings = $value->status ;
  
      }
  
      if(isset($rulesettings)){
        if (empty($rules)){
          $rule = 2;
        }else{
          $rule = 2;
        }
          $DataItem = DB::table('posts')->where('category', 'Indian')->orderByRaw('id DESC')->get();
          $data= [];
          foreach ($DataItem as $item) {
             $data[] = [
                 'id' => $item->id,
                 'title' => $item->title,
                 'post' => $item->post,
                 'movies_tvseries' => $item->movies_tvseries,
                 'category' => $item->category,
                 'trailer'  => $item->trailer,
                 'year' => $item->year,
                 'imdb' => $item->imdb,
                 'image' => $item->image,
                 'videolist' => json_decode($item->video),
                 'created_at' => $item->created_at
             ];
         }
         return response()->json(['cato' => $data]);
  
      }else{
        if (empty($rules)){
          $rule = 2;
        }else{
          $rule = 2;
        }
        $DataItem = DB::table('posts')->where('category', 'Indian')->where('rule',$rule)->orderByRaw('id DESC')->get();
         $data= [];
         foreach ($DataItem as $item) {
            $data[] = [
                'id' => $item->id,
                'title' => $item->title,
                'post' => $item->post,
                'movies_tvseries' => $item->movies_tvseries,
                'category' => $item->category,
                'trailer'  => $item->trailer,
                'year' => $item->year,
                'imdb' => $item->imdb,
                'image' => $item->image,
                'videolist' => json_decode($item->video),
                'created_at' => $item->created_at
            ];
        }
        return response()->json(['cato' => $data]);
      }
  
    }else{
  
      $messages = "License Expired  أنتهاء فترة الترخيص";
      return response()->json(['cato' => $messages]);
    }
  });
  
  


  Route::get('Drama', function() {

    $license = Defense::orderByRaw('id DESC')->limit(1)->get();
    foreach ($license as $value) {
      $createdsos = $value->created_at ;
      $showDaysos = $value->show_days ;
  }
  
  $created_atsos = date_create($createdsos);
  $DateTime1sos = date_format($created_atsos,"d-m-Y");
  
  $datePlus = date( "d-m-Y", strtotime( "$DateTime1sos +$showDaysos days" ) );
  
  $d1sos=strtotime($datePlus);
  $d2sos=ceil(($d1sos-time())/60/60/24);
  
  
  if($d2sos > 0){
  
      $postsRule = DB::table('posts')->where('rule', 2)->get();
  
      foreach ($postsRule as $value) {
        $rules = $value->rule ;
      }
  
      $status = DB::table('settings')->where('status', 2)->get();
  
      foreach ($status as $value) {
        $rulesettings = $value->status ;
  
      }
  
      if(isset($rulesettings)){
        if (empty($rules)){
          $rule = 2;
        }else{
          $rule = 2;
        }
          $DataItem = DB::table('posts')->where('category', 'Drama')->orderByRaw('id DESC')->get();
          $data= [];
          foreach ($DataItem as $item) {
             $data[] = [
                 'id' => $item->id,
                 'title' => $item->title,
                 'post' => $item->post,
                 'movies_tvseries' => $item->movies_tvseries,
                 'category' => $item->category,
                 'trailer'  => $item->trailer,
                 'year' => $item->year,
                 'imdb' => $item->imdb,
                 'image' => $item->image,
                 'videolist' => json_decode($item->video),
                 'created_at' => $item->created_at
             ];
         }
         return response()->json(['cato' => $data]);
  
      }else{
        if (empty($rules)){
          $rule = 2;
        }else{
          $rule = 2;
        }
        $DataItem = DB::table('posts')->where('category', 'Drama')->where('rule',$rule)->orderByRaw('id DESC')->get();
         $data= [];
         foreach ($DataItem as $item) {
            $data[] = [
                'id' => $item->id,
                'title' => $item->title,
                'post' => $item->post,
                'movies_tvseries' => $item->movies_tvseries,
                'category' => $item->category,
                'trailer'  => $item->trailer,
                'year' => $item->year,
                'imdb' => $item->imdb,
                'image' => $item->image,
                'videolist' => json_decode($item->video),
                'created_at' => $item->created_at
            ];
        }
        return response()->json(['cato' => $data]);
      }
  
    }else{
  
      $messages = "License Expired  أنتهاء فترة الترخيص";
      return response()->json(['cato' => $messages]);
    }
  });
  
  
  Route::get('Romance', function() {

    $license = Defense::orderByRaw('id DESC')->limit(1)->get();
    foreach ($license as $value) {
      $createdsos = $value->created_at ;
      $showDaysos = $value->show_days ;
  }
  
  $created_atsos = date_create($createdsos);
  $DateTime1sos = date_format($created_atsos,"d-m-Y");
  
  $datePlus = date( "d-m-Y", strtotime( "$DateTime1sos +$showDaysos days" ) );
  
  $d1sos=strtotime($datePlus);
  $d2sos=ceil(($d1sos-time())/60/60/24);
  
  
  if($d2sos > 0){
  
      $postsRule = DB::table('posts')->where('rule', 2)->get();
  
      foreach ($postsRule as $value) {
        $rules = $value->rule ;
      }
  
      $status = DB::table('settings')->where('status', 2)->get();
  
      foreach ($status as $value) {
        $rulesettings = $value->status ;
  
      }
  
      if(isset($rulesettings)){
        if (empty($rules)){
          $rule = 2;
        }else{
          $rule = 2;
        }
          $DataItem = DB::table('posts')->where('category', 'Romance')->orderByRaw('id DESC')->get();
          $data= [];
          foreach ($DataItem as $item) {
             $data[] = [
                 'id' => $item->id,
                 'title' => $item->title,
                 'post' => $item->post,
                 'movies_tvseries' => $item->movies_tvseries,
                 'category' => $item->category,
                 'trailer'  => $item->trailer,
                 'year' => $item->year,
                 'imdb' => $item->imdb,
                 'image' => $item->image,
                 'videolist' => json_decode($item->video),
                 'created_at' => $item->created_at
             ];
         }
         return response()->json(['cato' => $data]);
  
      }else{
        if (empty($rules)){
          $rule = 2;
        }else{
          $rule = 2;
        }
        $DataItem = DB::table('posts')->where('category', 'Romance')->where('rule',$rule)->orderByRaw('id DESC')->get();
         $data= [];
         foreach ($DataItem as $item) {
            $data[] = [
                'id' => $item->id,
                'title' => $item->title,
                'post' => $item->post,
                'movies_tvseries' => $item->movies_tvseries,
                'category' => $item->category,
                'trailer'  => $item->trailer,
                'year' => $item->year,
                'imdb' => $item->imdb,
                'image' => $item->image,
                'videolist' => json_decode($item->video),
                'created_at' => $item->created_at
            ];
        }
        return response()->json(['cato' => $data]);
      }
  
    }else{
  
      $messages = "License Expired  أنتهاء فترة الترخيص";
      return response()->json(['cato' => $messages]);
    }
  });

  


Route::get('Sci-Fi', function() {

  $license = Defense::orderByRaw('id DESC')->limit(1)->get();
  foreach ($license as $value) {
    $createdsos = $value->created_at ;
    $showDaysos = $value->show_days ;
}

$created_atsos = date_create($createdsos);
$DateTime1sos = date_format($created_atsos,"d-m-Y");

$datePlus = date( "d-m-Y", strtotime( "$DateTime1sos +$showDaysos days" ) );

$d1sos=strtotime($datePlus);
$d2sos=ceil(($d1sos-time())/60/60/24);


if($d2sos > 0){

    $postsRule = DB::table('posts')->where('rule', 2)->get();

    foreach ($postsRule as $value) {
      $rules = $value->rule ;
    }

    $status = DB::table('settings')->where('status', 2)->get();

    foreach ($status as $value) {
      $rulesettings = $value->status ;

    }

    if(isset($rulesettings)){
      if (empty($rules)){
        $rule = 2;
      }else{
        $rule = 2;
      }
        $DataItem = DB::table('posts')->where('category', 'Sci-Fi')->orderByRaw('id DESC')->get();
        $data= [];
        foreach ($DataItem as $item) {
           $data[] = [
               'id' => $item->id,
               'title' => $item->title,
               'post' => $item->post,
               'movies_tvseries' => $item->movies_tvseries,
               'category' => $item->category,
               'trailer'  => $item->trailer,
               'year' => $item->year,
               'imdb' => $item->imdb,
               'image' => $item->image,
               'videolist' => json_decode($item->video),
               'created_at' => $item->created_at
           ];
       }
       return response()->json(['cato' => $data]);

    }else{
      if (empty($rules)){
        $rule = 2;
      }else{
        $rule = 2;
      }
      $DataItem = DB::table('posts')->where('category', 'Sci-Fi')->where('rule',$rule)->orderByRaw('id DESC')->get();
       $data= [];
       foreach ($DataItem as $item) {
          $data[] = [
              'id' => $item->id,
              'title' => $item->title,
              'post' => $item->post,
              'movies_tvseries' => $item->movies_tvseries,
              'category' => $item->category,
              'trailer'  => $item->trailer,
              'year' => $item->year,
              'imdb' => $item->imdb,
              'image' => $item->image,
              'videolist' => json_decode($item->video),
              'created_at' => $item->created_at
          ];
      }
      return response()->json(['cato' => $data]);
    }

  }else{

    $messages = "License Expired  أنتهاء فترة الترخيص";
    return response()->json(['cato' => $messages]);
  }
});





Route::get('Social', function() {

    $license = Defense::orderByRaw('id DESC')->limit(1)->get();
    foreach ($license as $value) {
      $createdsos = $value->created_at ;
      $showDaysos = $value->show_days ;
  }
  
  $created_atsos = date_create($createdsos);
  $DateTime1sos = date_format($created_atsos,"d-m-Y");
  
  $datePlus = date( "d-m-Y", strtotime( "$DateTime1sos +$showDaysos days" ) );
  
  $d1sos=strtotime($datePlus);
  $d2sos=ceil(($d1sos-time())/60/60/24);
  
  
  if($d2sos > 0){
  
      $postsRule = DB::table('posts')->where('rule', 2)->get();
  
      foreach ($postsRule as $value) {
        $rules = $value->rule ;
      }
  
      $status = DB::table('settings')->where('status', 2)->get();
  
      foreach ($status as $value) {
        $rulesettings = $value->status ;
  
      }
  
      if(isset($rulesettings)){
        if (empty($rules)){
          $rule = 2;
        }else{
          $rule = 2;
        }
          $DataItem = DB::table('posts')->where('category', 'Social')->orderByRaw('id DESC')->get();
          $data= [];
          foreach ($DataItem as $item) {
             $data[] = [
                 'id' => $item->id,
                 'title' => $item->title,
                 'post' => $item->post,
                 'movies_tvseries' => $item->movies_tvseries,
                 'category' => $item->category,
                 'trailer'  => $item->trailer,
                 'year' => $item->year,
                 'imdb' => $item->imdb,
                 'image' => $item->image,
                 'videolist' => json_decode($item->video),
                 'created_at' => $item->created_at
             ];
         }
         return response()->json(['cato' => $data]);
  
      }else{
        if (empty($rules)){
          $rule = 2;
        }else{
          $rule = 2;
        }
        $DataItem = DB::table('posts')->where('category', 'Social')->where('rule',$rule)->orderByRaw('id DESC')->get();
         $data= [];
         foreach ($DataItem as $item) {
            $data[] = [
                'id' => $item->id,
                'title' => $item->title,
                'post' => $item->post,
                'movies_tvseries' => $item->movies_tvseries,
                'category' => $item->category,
                'trailer'  => $item->trailer,
                'year' => $item->year,
                'imdb' => $item->imdb,
                'image' => $item->image,
                'videolist' => json_decode($item->video),
                'created_at' => $item->created_at
            ];
        }
        return response()->json(['cato' => $data]);
      }
  
    }else{
  
      $messages = "License Expired  أنتهاء فترة الترخيص";
      return response()->json(['cato' => $messages]);
    }
  });
  
  


  Route::get('Mystery', function() {

    $license = Defense::orderByRaw('id DESC')->limit(1)->get();
    foreach ($license as $value) {
      $createdsos = $value->created_at ;
      $showDaysos = $value->show_days ;
  }
  
  $created_atsos = date_create($createdsos);
  $DateTime1sos = date_format($created_atsos,"d-m-Y");
  
  $datePlus = date( "d-m-Y", strtotime( "$DateTime1sos +$showDaysos days" ) );
  
  $d1sos=strtotime($datePlus);
  $d2sos=ceil(($d1sos-time())/60/60/24);
  
  
  if($d2sos > 0){
  
      $postsRule = DB::table('posts')->where('rule', 2)->get();
  
      foreach ($postsRule as $value) {
        $rules = $value->rule ;
      }
  
      $status = DB::table('settings')->where('status', 2)->get();
  
      foreach ($status as $value) {
        $rulesettings = $value->status ;
  
      }
  
      if(isset($rulesettings)){
        if (empty($rules)){
          $rule = 2;
        }else{
          $rule = 2;
        }
          $DataItem = DB::table('posts')->where('category', 'Mystery')->orderByRaw('id DESC')->get();
          $data= [];
          foreach ($DataItem as $item) {
             $data[] = [
                 'id' => $item->id,
                 'title' => $item->title,
                 'post' => $item->post,
                 'movies_tvseries' => $item->movies_tvseries,
                 'category' => $item->category,
                 'trailer'  => $item->trailer,
                 'year' => $item->year,
                 'imdb' => $item->imdb,
                 'image' => $item->image,
                 'videolist' => json_decode($item->video),
                 'created_at' => $item->created_at
             ];
         }
         return response()->json(['cato' => $data]);
  
      }else{
        if (empty($rules)){
          $rule = 2;
        }else{
          $rule = 2;
        }
        $DataItem = DB::table('posts')->where('category', 'Mystery')->where('rule',$rule)->orderByRaw('id DESC')->get();
         $data= [];
         foreach ($DataItem as $item) {
            $data[] = [
                'id' => $item->id,
                'title' => $item->title,
                'post' => $item->post,
                'movies_tvseries' => $item->movies_tvseries,
                'category' => $item->category,
                'trailer'  => $item->trailer,
                'year' => $item->year,
                'imdb' => $item->imdb,
                'image' => $item->image,
                'videolist' => json_decode($item->video),
                'created_at' => $item->created_at
            ];
        }
        return response()->json(['cato' => $data]);
      }
  
    }else{
  
      $messages = "License Expired  أنتهاء فترة الترخيص";
      return response()->json(['cato' => $messages]);
    }
  });
  
  


  Route::get('War', function() {

    $license = Defense::orderByRaw('id DESC')->limit(1)->get();
    foreach ($license as $value) {
      $createdsos = $value->created_at ;
      $showDaysos = $value->show_days ;
  }
  
  $created_atsos = date_create($createdsos);
  $DateTime1sos = date_format($created_atsos,"d-m-Y");
  
  $datePlus = date( "d-m-Y", strtotime( "$DateTime1sos +$showDaysos days" ) );
  
  $d1sos=strtotime($datePlus);
  $d2sos=ceil(($d1sos-time())/60/60/24);
  
  
  if($d2sos > 0){
  
      $postsRule = DB::table('posts')->where('rule', 2)->get();
  
      foreach ($postsRule as $value) {
        $rules = $value->rule ;
      }
  
      $status = DB::table('settings')->where('status', 2)->get();
  
      foreach ($status as $value) {
        $rulesettings = $value->status ;
  
      }
  
      if(isset($rulesettings)){
        if (empty($rules)){
          $rule = 2;
        }else{
          $rule = 2;
        }
          $DataItem = DB::table('posts')->where('category', 'War')->orderByRaw('id DESC')->get();
          $data= [];
          foreach ($DataItem as $item) {
             $data[] = [
                 'id' => $item->id,
                 'title' => $item->title,
                 'post' => $item->post,
                 'movies_tvseries' => $item->movies_tvseries,
                 'category' => $item->category,
                 'trailer'  => $item->trailer,
                 'year' => $item->year,
                 'imdb' => $item->imdb,
                 'image' => $item->image,
                 'videolist' => json_decode($item->video),
                 'created_at' => $item->created_at
             ];
         }
         return response()->json(['cato' => $data]);
  
      }else{
        if (empty($rules)){
          $rule = 2;
        }else{
          $rule = 2;
        }
        $DataItem = DB::table('posts')->where('category', 'War')->where('rule',$rule)->orderByRaw('id DESC')->get();
         $data= [];
         foreach ($DataItem as $item) {
            $data[] = [
                'id' => $item->id,
                'title' => $item->title,
                'post' => $item->post,
                'movies_tvseries' => $item->movies_tvseries,
                'category' => $item->category,
                'trailer'  => $item->trailer,
                'year' => $item->year,
                'imdb' => $item->imdb,
                'image' => $item->image,
                'videolist' => json_decode($item->video),
                'created_at' => $item->created_at
            ];
        }
        return response()->json(['cato' => $data]);
      }
  
    }else{
  
      $messages = "License Expired  أنتهاء فترة الترخيص";
      return response()->json(['cato' => $messages]);
    }
  });



  Route::get('Family', function() {

    $license = Defense::orderByRaw('id DESC')->limit(1)->get();
    foreach ($license as $value) {
      $createdsos = $value->created_at ;
      $showDaysos = $value->show_days ;
  }
  
  $created_atsos = date_create($createdsos);
  $DateTime1sos = date_format($created_atsos,"d-m-Y");
  
  $datePlus = date( "d-m-Y", strtotime( "$DateTime1sos +$showDaysos days" ) );
  
  $d1sos=strtotime($datePlus);
  $d2sos=ceil(($d1sos-time())/60/60/24);
  
  
  if($d2sos > 0){
  
      $postsRule = DB::table('posts')->where('rule', 2)->get();
  
      foreach ($postsRule as $value) {
        $rules = $value->rule ;
      }
  
      $status = DB::table('settings')->where('status', 2)->get();
  
      foreach ($status as $value) {
        $rulesettings = $value->status ;
  
      }
  
      if(isset($rulesettings)){
        if (empty($rules)){
          $rule = 2;
        }else{
          $rule = 2;
        }
          $DataItem = DB::table('posts')->where('category', 'Family')->orderByRaw('id DESC')->get();
          $data= [];
          foreach ($DataItem as $item) {
             $data[] = [
                 'id' => $item->id,
                 'title' => $item->title,
                 'post' => $item->post,
                 'movies_tvseries' => $item->movies_tvseries,
                 'category' => $item->category,
                 'trailer'  => $item->trailer,
                 'year' => $item->year,
                 'imdb' => $item->imdb,
                 'image' => $item->image,
                 'videolist' => json_decode($item->video),
                 'created_at' => $item->created_at
             ];
         }
         return response()->json(['cato' => $data]);
  
      }else{
        if (empty($rules)){
          $rule = 2;
        }else{
          $rule = 2;
        }
        $DataItem = DB::table('posts')->where('category', 'Family')->where('rule',$rule)->orderByRaw('id DESC')->get();
         $data= [];
         foreach ($DataItem as $item) {
            $data[] = [
                'id' => $item->id,
                'title' => $item->title,
                'post' => $item->post,
                'movies_tvseries' => $item->movies_tvseries,
                'category' => $item->category,
                'trailer'  => $item->trailer,
                'year' => $item->year,
                'imdb' => $item->imdb,
                'image' => $item->image,
                'videolist' => json_decode($item->video),
                'created_at' => $item->created_at
            ];
        }
        return response()->json(['cato' => $data]);
      }
  
    }else{
  
      $messages = "License Expired  أنتهاء فترة الترخيص";
      return response()->json(['cato' => $messages]);
    }
  });

  


Route::get('Kurdish', function() {

    $license = Defense::orderByRaw('id DESC')->limit(1)->get();
    foreach ($license as $value) {
      $createdsos = $value->created_at ;
      $showDaysos = $value->show_days ;
  }
  
  $created_atsos = date_create($createdsos);
  $DateTime1sos = date_format($created_atsos,"d-m-Y");
  
  $datePlus = date( "d-m-Y", strtotime( "$DateTime1sos +$showDaysos days" ) );
  
  $d1sos=strtotime($datePlus);
  $d2sos=ceil(($d1sos-time())/60/60/24);
  
  
  if($d2sos > 0){
  
      $postsRule = DB::table('posts')->where('rule', 2)->get();
  
      foreach ($postsRule as $value) {
        $rules = $value->rule ;
      }
  
      $status = DB::table('settings')->where('status', 2)->get();
  
      foreach ($status as $value) {
        $rulesettings = $value->status ;
  
      }
  
      if(isset($rulesettings)){
        if (empty($rules)){
          $rule = 2;
        }else{
          $rule = 2;
        }
          $DataItem = DB::table('posts')->where('category', 'Kurdish')->orderByRaw('id DESC')->get();
          $data= [];
          foreach ($DataItem as $item) {
             $data[] = [
                 'id' => $item->id,
                 'title' => $item->title,
                 'post' => $item->post,
                 'movies_tvseries' => $item->movies_tvseries,
                 'category' => $item->category,
                 'trailer'  => $item->trailer,
                 'year' => $item->year,
                 'imdb' => $item->imdb,
                 'image' => $item->image,
                 'videolist' => json_decode($item->video),
                 'created_at' => $item->created_at
             ];
         }
         return response()->json(['cato' => $data]);
  
      }else{
        if (empty($rules)){
          $rule = 2;
        }else{
          $rule = 2;
        }
        $DataItem = DB::table('posts')->where('category', 'Kurdish')->where('rule',$rule)->orderByRaw('id DESC')->get();
         $data= [];
         foreach ($DataItem as $item) {
            $data[] = [
                'id' => $item->id,
                'title' => $item->title,
                'post' => $item->post,
                'movies_tvseries' => $item->movies_tvseries,
                'category' => $item->category,
                'trailer'  => $item->trailer,
                'year' => $item->year,
                'imdb' => $item->imdb,
                'image' => $item->image,
                'videolist' => json_decode($item->video),
                'created_at' => $item->created_at
            ];
        }
        return response()->json(['cato' => $data]);
      }
  
    }else{
  
      $messages = "License Expired  أنتهاء فترة الترخيص";
      return response()->json(['cato' => $messages]);
    }
  });
  

  


Route::get('Western', function() {

    $license = Defense::orderByRaw('id DESC')->limit(1)->get();
    foreach ($license as $value) {
      $createdsos = $value->created_at ;
      $showDaysos = $value->show_days ;
  }
  
  $created_atsos = date_create($createdsos);
  $DateTime1sos = date_format($created_atsos,"d-m-Y");
  
  $datePlus = date( "d-m-Y", strtotime( "$DateTime1sos +$showDaysos days" ) );
  
  $d1sos=strtotime($datePlus);
  $d2sos=ceil(($d1sos-time())/60/60/24);
  
  
  if($d2sos > 0){
  
      $postsRule = DB::table('posts')->where('rule', 2)->get();
  
      foreach ($postsRule as $value) {
        $rules = $value->rule ;
      }
  
      $status = DB::table('settings')->where('status', 2)->get();
  
      foreach ($status as $value) {
        $rulesettings = $value->status ;
  
      }
  
      if(isset($rulesettings)){
        if (empty($rules)){
          $rule = 2;
        }else{
          $rule = 2;
        }
          $DataItem = DB::table('posts')->where('category', 'Western')->orderByRaw('id DESC')->get();
          $data= [];
          foreach ($DataItem as $item) {
             $data[] = [
                 'id' => $item->id,
                 'title' => $item->title,
                 'post' => $item->post,
                 'movies_tvseries' => $item->movies_tvseries,
                 'category' => $item->category,
                 'trailer'  => $item->trailer,
                 'year' => $item->year,
                 'imdb' => $item->imdb,
                 'image' => $item->image,
                 'videolist' => json_decode($item->video),
                 'created_at' => $item->created_at
             ];
         }
         return response()->json(['cato' => $data]);
  
      }else{
        if (empty($rules)){
          $rule = 2;
        }else{
          $rule = 2;
        }
        $DataItem = DB::table('posts')->where('category', 'Western')->where('rule',$rule)->orderByRaw('id DESC')->get();
         $data= [];
         foreach ($DataItem as $item) {
            $data[] = [
                'id' => $item->id,
                'title' => $item->title,
                'post' => $item->post,
                'movies_tvseries' => $item->movies_tvseries,
                'category' => $item->category,
                'trailer'  => $item->trailer,
                'year' => $item->year,
                'imdb' => $item->imdb,
                'image' => $item->image,
                'videolist' => json_decode($item->video),
                'created_at' => $item->created_at
            ];
        }
        return response()->json(['cato' => $data]);
      }
  
    }else{
  
      $messages = "License Expired  أنتهاء فترة الترخيص";
      return response()->json(['cato' => $messages]);
    }
  });
  
  

Route::get('Comedy', function() {

    $license = Defense::orderByRaw('id DESC')->limit(1)->get();
    foreach ($license as $value) {
      $createdsos = $value->created_at ;
      $showDaysos = $value->show_days ;
  }
  
  $created_atsos = date_create($createdsos);
  $DateTime1sos = date_format($created_atsos,"d-m-Y");
  
  $datePlus = date( "d-m-Y", strtotime( "$DateTime1sos +$showDaysos days" ) );
  
  $d1sos=strtotime($datePlus);
  $d2sos=ceil(($d1sos-time())/60/60/24);
  
  
  if($d2sos > 0){
  
      $postsRule = DB::table('posts')->where('rule', 2)->get();
  
      foreach ($postsRule as $value) {
        $rules = $value->rule ;
      }
  
      $status = DB::table('settings')->where('status', 2)->get();
  
      foreach ($status as $value) {
        $rulesettings = $value->status ;
  
      }
  
      if(isset($rulesettings)){
        if (empty($rules)){
          $rule = 2;
        }else{
          $rule = 2;
        }
          $DataItem = DB::table('posts')->where('category', 'Comedy')->orderByRaw('id DESC')->get();
          $data= [];
          foreach ($DataItem as $item) {
             $data[] = [
                 'id' => $item->id,
                 'title' => $item->title,
                 'post' => $item->post,
                 'movies_tvseries' => $item->movies_tvseries,
                 'category' => $item->category,
                 'trailer'  => $item->trailer,
                 'year' => $item->year,
                 'imdb' => $item->imdb,
                 'image' => $item->image,
                 'videolist' => json_decode($item->video),
                 'created_at' => $item->created_at
             ];
         }
         return response()->json(['cato' => $data]);
  
      }else{
        if (empty($rules)){
          $rule = 2;
        }else{
          $rule = 2;
        }
        $DataItem = DB::table('posts')->where('category', 'Comedy')->where('rule',$rule)->orderByRaw('id DESC')->get();
         $data= [];
         foreach ($DataItem as $item) {
            $data[] = [
                'id' => $item->id,
                'title' => $item->title,
                'post' => $item->post,
                'movies_tvseries' => $item->movies_tvseries,
                'category' => $item->category,
                'trailer'  => $item->trailer,
                'year' => $item->year,
                'imdb' => $item->imdb,
                'image' => $item->image,
                'videolist' => json_decode($item->video),
                'created_at' => $item->created_at
            ];
        }
        return response()->json(['cato' => $data]);
      }
  
    }else{
  
      $messages = "License Expired  أنتهاء فترة الترخيص";
      return response()->json(['cato' => $messages]);
    }
  });
  
  

Route::get('Adventure', function() {

    $license = Defense::orderByRaw('id DESC')->limit(1)->get();
    foreach ($license as $value) {
      $createdsos = $value->created_at ;
      $showDaysos = $value->show_days ;
  }
  
  $created_atsos = date_create($createdsos);
  $DateTime1sos = date_format($created_atsos,"d-m-Y");
  
  $datePlus = date( "d-m-Y", strtotime( "$DateTime1sos +$showDaysos days" ) );
  
  $d1sos=strtotime($datePlus);
  $d2sos=ceil(($d1sos-time())/60/60/24);
  
  
  if($d2sos > 0){
  
      $postsRule = DB::table('posts')->where('rule', 2)->get();
  
      foreach ($postsRule as $value) {
        $rules = $value->rule ;
      }
  
      $status = DB::table('settings')->where('status', 2)->get();
  
      foreach ($status as $value) {
        $rulesettings = $value->status ;
  
      }
  
      if(isset($rulesettings)){
        if (empty($rules)){
          $rule = 2;
        }else{
          $rule = 2;
        }
          $DataItem = DB::table('posts')->where('category', 'Adventure')->orderByRaw('id DESC')->get();
          $data= [];
          foreach ($DataItem as $item) {
             $data[] = [
                 'id' => $item->id,
                 'title' => $item->title,
                 'post' => $item->post,
                 'movies_tvseries' => $item->movies_tvseries,
                 'category' => $item->category,
                 'trailer'  => $item->trailer,
                 'year' => $item->year,
                 'imdb' => $item->imdb,
                 'image' => $item->image,
                 'videolist' => json_decode($item->video),
                 'created_at' => $item->created_at
             ];
         }
         return response()->json(['cato' => $data]);
  
      }else{
        if (empty($rules)){
          $rule = 2;
        }else{
          $rule = 2;
        }
        $DataItem = DB::table('posts')->where('category', 'Adventure')->where('rule',$rule)->orderByRaw('id DESC')->get();
         $data= [];
         foreach ($DataItem as $item) {
            $data[] = [
                'id' => $item->id,
                'title' => $item->title,
                'post' => $item->post,
                'movies_tvseries' => $item->movies_tvseries,
                'category' => $item->category,
                'trailer'  => $item->trailer,
                'year' => $item->year,
                'imdb' => $item->imdb,
                'image' => $item->image,
                'videolist' => json_decode($item->video),
                'created_at' => $item->created_at
            ];
        }
        return response()->json(['cato' => $data]);
      }
  
    }else{
  
      $messages = "License Expired  أنتهاء فترة الترخيص";
      return response()->json(['cato' => $messages]);
    }
  });

  
  Route::get('Crime', function() {

    $license = Defense::orderByRaw('id DESC')->limit(1)->get();
    foreach ($license as $value) {
      $createdsos = $value->created_at ;
      $showDaysos = $value->show_days ;
  }
  
  $created_atsos = date_create($createdsos);
  $DateTime1sos = date_format($created_atsos,"d-m-Y");
  
  $datePlus = date( "d-m-Y", strtotime( "$DateTime1sos +$showDaysos days" ) );
  
  $d1sos=strtotime($datePlus);
  $d2sos=ceil(($d1sos-time())/60/60/24);
  
  
  if($d2sos > 0){
  
      $postsRule = DB::table('posts')->where('rule', 2)->get();
  
      foreach ($postsRule as $value) {
        $rules = $value->rule ;
      }
  
      $status = DB::table('settings')->where('status', 2)->get();
  
      foreach ($status as $value) {
        $rulesettings = $value->status ;
  
      }
  
      if(isset($rulesettings)){
        if (empty($rules)){
          $rule = 2;
        }else{
          $rule = 2;
        }
          $DataItem = DB::table('posts')->where('category', 'Crime')->orderByRaw('id DESC')->get();
          $data= [];
          foreach ($DataItem as $item) {
             $data[] = [
                 'id' => $item->id,
                 'title' => $item->title,
                 'post' => $item->post,
                 'movies_tvseries' => $item->movies_tvseries,
                 'category' => $item->category,
                 'trailer'  => $item->trailer,
                 'year' => $item->year,
                 'imdb' => $item->imdb,
                 'image' => $item->image,
                 'videolist' => json_decode($item->video),
                 'created_at' => $item->created_at
             ];
         }
         return response()->json(['cato' => $data]);
  
      }else{
        if (empty($rules)){
          $rule = 2;
        }else{
          $rule = 2;
        }
        $DataItem = DB::table('posts')->where('category', 'Crime')->where('rule',$rule)->orderByRaw('id DESC')->get();
         $data= [];
         foreach ($DataItem as $item) {
            $data[] = [
                'id' => $item->id,
                'title' => $item->title,
                'post' => $item->post,
                'movies_tvseries' => $item->movies_tvseries,
                'category' => $item->category,
                'trailer'  => $item->trailer,
                'year' => $item->year,
                'imdb' => $item->imdb,
                'image' => $item->image,
                'videolist' => json_decode($item->video),
                'created_at' => $item->created_at
            ];
        }
        return response()->json(['cato' => $data]);
      }
  
    }else{
  
      $messages = "License Expired  أنتهاء فترة الترخيص";
      return response()->json(['cato' => $messages]);
    }
  });


  Route::get('Historical', function() {

    $license = Defense::orderByRaw('id DESC')->limit(1)->get();
    foreach ($license as $value) {
      $createdsos = $value->created_at ;
      $showDaysos = $value->show_days ;
  }
  
  $created_atsos = date_create($createdsos);
  $DateTime1sos = date_format($created_atsos,"d-m-Y");
  
  $datePlus = date( "d-m-Y", strtotime( "$DateTime1sos +$showDaysos days" ) );
  
  $d1sos=strtotime($datePlus);
  $d2sos=ceil(($d1sos-time())/60/60/24);
  
  
  if($d2sos > 0){
  
      $postsRule = DB::table('posts')->where('rule', 2)->get();
  
      foreach ($postsRule as $value) {
        $rules = $value->rule ;
      }
  
      $status = DB::table('settings')->where('status', 2)->get();
  
      foreach ($status as $value) {
        $rulesettings = $value->status ;
  
      }
  
      if(isset($rulesettings)){
        if (empty($rules)){
          $rule = 2;
        }else{
          $rule = 2;
        }
          $DataItem = DB::table('posts')->where('category', 'Historical')->orderByRaw('id DESC')->get();
          $data= [];
          foreach ($DataItem as $item) {
             $data[] = [
                 'id' => $item->id,
                 'title' => $item->title,
                 'post' => $item->post,
                 'movies_tvseries' => $item->movies_tvseries,
                 'category' => $item->category,
                 'trailer'  => $item->trailer,
                 'year' => $item->year,
                 'imdb' => $item->imdb,
                 'image' => $item->image,
                 'videolist' => json_decode($item->video),
                 'created_at' => $item->created_at
             ];
         }
         return response()->json(['cato' => $data]);
  
      }else{
        if (empty($rules)){
          $rule = 2;
        }else{
          $rule = 2;
        }
        $DataItem = DB::table('posts')->where('category', 'Historical')->where('rule',$rule)->orderByRaw('id DESC')->get();
         $data= [];
         foreach ($DataItem as $item) {
            $data[] = [
                'id' => $item->id,
                'title' => $item->title,
                'post' => $item->post,
                'movies_tvseries' => $item->movies_tvseries,
                'category' => $item->category,
                'trailer'  => $item->trailer,
                'year' => $item->year,
                'imdb' => $item->imdb,
                'image' => $item->image,
                'videolist' => json_decode($item->video),
                'created_at' => $item->created_at
            ];
        }
        return response()->json(['cato' => $data]);
      }
  
    }else{
  
      $messages = "License Expired  أنتهاء فترة الترخيص";
      return response()->json(['cato' => $messages]);
    }
  });
  

  



Route::get('Spy Film', function() {

    $license = Defense::orderByRaw('id DESC')->limit(1)->get();
    foreach ($license as $value) {
      $createdsos = $value->created_at ;
      $showDaysos = $value->show_days ;
  }
  
  $created_atsos = date_create($createdsos);
  $DateTime1sos = date_format($created_atsos,"d-m-Y");
  
  $datePlus = date( "d-m-Y", strtotime( "$DateTime1sos +$showDaysos days" ) );
  
  $d1sos=strtotime($datePlus);
  $d2sos=ceil(($d1sos-time())/60/60/24);
  
  
  if($d2sos > 0){
  
      $postsRule = DB::table('posts')->where('rule', 2)->get();
  
      foreach ($postsRule as $value) {
        $rules = $value->rule ;
      }
  
      $status = DB::table('settings')->where('status', 2)->get();
  
      foreach ($status as $value) {
        $rulesettings = $value->status ;
  
      }
  
      if(isset($rulesettings)){
        if (empty($rules)){
          $rule = 2;
        }else{
          $rule = 2;
        }
          $DataItem = DB::table('posts')->where('category', 'Spy Film')->orderByRaw('id DESC')->get();
          $data= [];
          foreach ($DataItem as $item) {
             $data[] = [
                 'id' => $item->id,
                 'title' => $item->title,
                 'post' => $item->post,
                 'movies_tvseries' => $item->movies_tvseries,
                 'category' => $item->category,
                 'trailer'  => $item->trailer,
                 'year' => $item->year,
                 'imdb' => $item->imdb,
                 'image' => $item->image,
                 'videolist' => json_decode($item->video),
                 'created_at' => $item->created_at
             ];
         }
         return response()->json(['cato' => $data]);
  
      }else{
        if (empty($rules)){
          $rule = 2;
        }else{
          $rule = 2;
        }
        $DataItem = DB::table('posts')->where('category', 'Spy Film')->where('rule',$rule)->orderByRaw('id DESC')->get();
         $data= [];
         foreach ($DataItem as $item) {
            $data[] = [
                'id' => $item->id,
                'title' => $item->title,
                'post' => $item->post,
                'movies_tvseries' => $item->movies_tvseries,
                'category' => $item->category,
                'trailer'  => $item->trailer,
                'year' => $item->year,
                'imdb' => $item->imdb,
                'image' => $item->image,
                'videolist' => json_decode($item->video),
                'created_at' => $item->created_at
            ];
        }
        return response()->json(['cato' => $data]);
      }
  
    }else{
  
      $messages = "License Expired  أنتهاء فترة الترخيص";
      return response()->json(['cato' => $messages]);
    }
  });

  


Route::get('Netflix', function() {

    $license = Defense::orderByRaw('id DESC')->limit(1)->get();
    foreach ($license as $value) {
      $createdsos = $value->created_at ;
      $showDaysos = $value->show_days ;
  }
  
  $created_atsos = date_create($createdsos);
  $DateTime1sos = date_format($created_atsos,"d-m-Y");
  
  $datePlus = date( "d-m-Y", strtotime( "$DateTime1sos +$showDaysos days" ) );
  
  $d1sos=strtotime($datePlus);
  $d2sos=ceil(($d1sos-time())/60/60/24);
  
  
  if($d2sos > 0){
  
      $postsRule = DB::table('posts')->where('rule', 2)->get();
  
      foreach ($postsRule as $value) {
        $rules = $value->rule ;
      }
  
      $status = DB::table('settings')->where('status', 2)->get();
  
      foreach ($status as $value) {
        $rulesettings = $value->status ;
  
      }
  
      if(isset($rulesettings)){
        if (empty($rules)){
          $rule = 2;
        }else{
          $rule = 2;
        }
          $DataItem = DB::table('posts')->where('category', 'Netflix')->orderByRaw('id DESC')->get();
          $data= [];
          foreach ($DataItem as $item) {
             $data[] = [
                 'id' => $item->id,
                 'title' => $item->title,
                 'post' => $item->post,
                 'movies_tvseries' => $item->movies_tvseries,
                 'category' => $item->category,
                 'trailer'  => $item->trailer,
                 'year' => $item->year,
                 'imdb' => $item->imdb,
                 'image' => $item->image,
                 'videolist' => json_decode($item->video),
                 'created_at' => $item->created_at
             ];
         }
         return response()->json(['cato' => $data]);
  
      }else{
        if (empty($rules)){
          $rule = 2;
        }else{
          $rule = 2;
        }
        $DataItem = DB::table('posts')->where('category', 'Netflix')->where('rule',$rule)->orderByRaw('id DESC')->get();
         $data= [];
         foreach ($DataItem as $item) {
            $data[] = [
                'id' => $item->id,
                'title' => $item->title,
                'post' => $item->post,
                'movies_tvseries' => $item->movies_tvseries,
                'category' => $item->category,
                'trailer'  => $item->trailer,
                'year' => $item->year,
                'imdb' => $item->imdb,
                'image' => $item->image,
                'videolist' => json_decode($item->video),
                'created_at' => $item->created_at
            ];
        }
        return response()->json(['cato' => $data]);
      }
  
    }else{
  
      $messages = "License Expired  أنتهاء فترة الترخيص";
      return response()->json(['cato' => $messages]);
    }
  });
  
  

