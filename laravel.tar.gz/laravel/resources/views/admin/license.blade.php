
@extends('adminlte::page')

@section('title', 'Users | Lara Admin')

@section('content_header')
    <h1>License</h1>
@stop

@section('content')




@if (count($sosbol) > 0)

<form class="form-horizontal"  action="{{ route('card.store') }}" method="POST">
  {{ csrf_field() }}
  <button type="submit" class="btn btn-primary">
Request A License  طلب ترخيص
</button>



@endif


</form>

<br>


  <div class="row">
    <div class="col-xs-12">
     
    <!-- general form elements -->
    <div class="box box-primary">

        <!-- /.box-header -->
        <!-- form start -->
        <form role="form" method="POST" action="{{ route('defense.store') }}" enctype="multipart/form-data">
          {{ csrf_field() }}
          <div class="box-body">
            <div class="form-group">
              <br>
                <label for="exampleInputText">License Number </label>
                <input type="text" class="form-control" id="exampleInputText"  name="pidn" placeholder="License Number">
              </div>


            <div class="form-group">
              <label for="exampleInputText">License Password</label>
              <input type="password" class="form-control" id="exampleInputText" name="password"  placeholder="License Password">
        
            </div>


          </div>
     
  
          <div class="box-footer">
            <button type="submit" class="btn btn-primary">Dane</button>
            
          </div>
        </form>


      </div>
      <!-- /.box -->

      <!-- /.box -->
    </div>
    <!-- /.col -->
  </div>
@stop

@section('js')

<script>
  $(document).ready( function () {
    $('#laravel_datatable').DataTable();
  });
</script>

@stop
















