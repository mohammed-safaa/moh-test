@extends('adminlte::page')

@section('title', 'Users | Lara Admin')

@section('content_header')
    <h1>Media</h1>
@stop

@section('content')
  <div class="row">
    <div class="col-xs-12">
      <div class="box">
        <div class="box-header">
          @if(Session::has('message'))
            <p class="alert {{ Session::get('alert-class', 'alert-info') }}">{{ Session::get('message') }}</p>
          @endif     
        </div>
        <div class="box-body">
          <table id="laravel_datatable" class="table table-bordered table-striped">
            <thead>
              <tr>
                <th>Image</th>
                <th>Title</th>
                <th>Catgeory</th>
                <th>Genres</th>
                <th>Year</th>
                <th>imdb</th>
                <th>Username</th>
                <th>Publishing Status</th>
                <th>Created_at</th>
                <th>View</th>
                <th>Edit</th>
                <th>Delete</th>
              </tr>
            </thead>
            <tbody>
              @foreach ($allpost as $post)
                <tr>
                
                  <td>
                    <a href="post/{{ $post->id }}">
                    <img src="../storage/upload/{{ $post->image }}" alt="" width="80" height="50">
                  </a>
                  </td>
                  <a href="post/{{ $post->id }}">
                  <td>{{ $post->title }}</td>
                </a>
                  <td>{{ $post->movies_tvseries }}</td>
                  <td>{{ $post->category }}</td>
                  <td>{{ $post->year }}</td>
                  <td>{{ $post->imdb }}</td>
                  <td>{{ $post->user->name }}</td>
                  <td>
                  <?php 
                  $varrule = $post->rule;
                  if ($varrule == 1) {
                    echo '<p style="color: #d9534f">Not published</p>';                  
                  }else {
                    echo '<p style="color: #5cb85c">publishing</p>';
                  }
                  ?>
                  
                  </td>
                  <td>{{ $post->created_at }}</td>
                 <td> <a href="post/{{ $post->id }}" class="btn btn-default btn-sm" role="button">View</a></td>
                  <td>
                    <a href="{{ route('dpost.edit',$post->id ) }}" class="btn btn-info btn-sm" role="button">Edit</a>
                    </td>
                  <td>
                    <form action="{{ route('dpost.destroy',$post->id) }}" method="POST">
                      {{ csrf_field() }}
        
                      {{method_field('DELETE')}}
                
                      <button class="btn btn-primary btn-sm" type="submit" aria-label="">Delete</button>  
                  </form>
                  </td>
                </tr>
              @endforeach
            </tbody>
          </table>
        </div>
      </div>
      <!-- /.box -->
    </div>
    <!-- /.col -->
  </div>
@stop

@section('js')

<script>
  $(document).ready( function () {
    $('#laravel_datatable').DataTable();
  });
</script>

@stop