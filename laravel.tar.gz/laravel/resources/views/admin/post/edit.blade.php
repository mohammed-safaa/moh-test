@extends('adminlte::page')

@section('title', 'Users | Lara Admin')

@section('content_header')
    <h1>Edit Post</h1>
@stop

@section('content')
  <div class="row">
    <div class="col-xs-12" >
     
    <!-- general form elements -->
    <div class="box box-primary" >
        <div class="box-header with-border" >
          <h3 class="box-title">Edit Post</h3>

          <style>
            .switch {
              position: relative;
              display: inline-block;
              width: 54px;
              height: 29px;
            }
            
            .switch input { 
              opacity: 0;
              width: 0;
              height: 0;
            }
            
            .slider {
              position: absolute;
              cursor: pointer;
              top: 0;
              left: 0;
              right: 0;
              bottom: 0;
              background-color: #ccc;
              -webkit-transition: .4s;
              transition: .4s;
            }
            
            .slider:before {
              position: absolute;
              content: "";
              height: 20px;
              width: 20px;
              left: 4px;
              bottom: 4px;
              background-color: white;
              -webkit-transition: .4s;
              transition: .4s;
            }
            
            input:checked + .slider {
              background-color: #2196F3;
            }
            
            input:focus + .slider {
              box-shadow: 0 0 1px #2196F3;
            }
            
            input:checked + .slider:before {
              -webkit-transform: translateX(26px);
              -ms-transform: translateX(26px);
              transform: translateX(26px);
            }
            
            /* Rounded sliders */
            .slider.round {
              border-radius: 34px;
            }
            
            .slider.round:before {
              border-radius: 50%;
            }

            .form-group {
                margin: 10px;
            }
            </style>



        </div>
        <!-- /.box-header -->
        <!-- form start -->
        <form role="form" method="POST" action="{{ route('dpost.update',$postid->id) }}">
            {{ method_field('PUT') }}
            {{ csrf_field() }}
          <div class="box-body">




            <div class="form-group">
                <label for="exampleInputText">Title </label>
                <input type="text" class="form-control" id="exampleInputText" name="title" value="{{ $postid->title }}" placeholder="Enter email">
              </div>
            <div class="form-group">
              <label for="exampleInputText">About</label>
              <textarea class="form-control" name="post" value="{{ $postid->post }}" id="" cols="30" rows="2">{{ $postid->post }}</textarea>
    
            </div>
            <div class="form-group">
                <label for="exampleInputEmail1"> </label>
         
   
                  <?php 
                  $var = $postid->movies_tvseries;
                  $mov = "Movies";
                      if (strcmp($mov, $var) == 0) {
                    echo'<input  type="radio" name="movies&tvseries" value="Movies" checked> MOVIES '; 
                    echo ' <input  type="radio" name="movies&tvseries" value="Tv Series"> TV SERIES';
                    }else{
                    echo'<input  type="radio" name="movies&tvseries" value="Movies" > MOVIES'; 
                    echo '<input  type="radio" name="movies&tvseries" value="Tv Series" checked> TV SERIES';
                    }
                    ?>

               
                {{-- <input type="text" class="form-control" id="exampleInputText" name="movies&tvseries" value="{{ $postid->movies_tvseries }}" placeholder="Enter email"> --}}
              </div>
              <div class="form-group">
                <label for="exampleInputEmail1">Genres</label>
                <select type="text" class="form-control" name="category" value="{{ $postid->category }}" id="sel1" required autofocus>
                  <option>{{ $postid->category }}</option>
                  <option>Popular</option>
                  <option>Netflix</option>
                  <option>Action</option>
                  <option>Animation</option>
                  <option>Adventure</option>
                  <option>Comedy</option>
                  <option>Crime</option>
                  <option>Drama</option>
                  <option>Fantasy</option>
                  <option>Historical</option>
                  <option>Horror</option>
                  <option>Mystery</option>
                  <option>Romance</option>
                  <option>Sci-Fi</option>
                  <option>Social</option>
                  <option>Spy Film</option>
                  <option>Western</option>
                  <option>War</option>
                  <option value="Family">Children's/Family</option>
                  <option>Documentary</option>
                  <option>Arabic</option>
                  <option>Indian</option>
                  <option>Turkish</option>
                  <option>Kurdish</option>
                 
                </select>
           
              </div>
              <div class="form-group">
                <label for="exampleInputEmail1">Year </label>
                <input type="text" class="form-control" id="exampleInputText" name="year" value="{{ $postid->year }}" placeholder="Enter email">
              </div>
              <div class="form-group">
                <label for="exampleInputEmail1">imdb </label>
                <input type="text" class="form-control" id="exampleInputText" name="imdb" value="{{ $postid->imdb }}" placeholder="Enter email">
              </div>
              <div class="form-group">
                <label for="exampleInputEmail1">Trailer </label>
                <input type="text" class="form-control" id="exampleInputText" name="trailer" value="{{ $postid->trailer }}" placeholder="Enter email">
              </div>

          </div>
          <!-- /.box-body -->

          <div class="form-group" style='margin-left: 45px;'>
            
            
              {{-- checked --}}
       <?php

          $varrule = $postid->rule;
          $ch = "checked";
            if ($varrule == 1) {
              echo '<label for="exampleInputEmail1" style="color: #d9534f"> Not published </label><br>';
              echo '<label class="switch">';
              echo '<input type="checkbox" name="rule" value="2" >' ;
            }else{
              echo '<label for="exampleInputEmail1" style="color: #5cb85c"> publishing  </label><br>';
              echo '<label class="switch">';
              echo '<input type="checkbox" name="rule" value="'.$postid->rule.'" '.$ch.'>' ;
            }

        ?>

        <span class="slider round"></span>
        </label>

        </div>

  
          <div class="box-footer">
            <button type="submit" class="btn btn-primary" >Update</button>
          </div>
        </form>
      </div>
      <!-- /.box -->
     
      <!-- /.box -->
    </div>
    <!-- /.col -->
  </div>
@stop

@section('js')

<script>
  $(document).ready( function () {
    $('#laravel_datatable').DataTable();
  });
</script>

@stop















