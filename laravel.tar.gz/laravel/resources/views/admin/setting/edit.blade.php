@extends('adminlte::page')

@section('title', 'Users | Lara Admin')

@section('content_header')
    <h1>Edit Setting</h1>
@stop

@section('content')
  <div class="row">
    <div class="col-xs-12">
     
    <!-- general form elements -->
    <div class="box box-primary">
        <div class="box-header with-border">
          <h3 class="box-title">Edit Setting</h3>

          <style>
            .switch {
              position: relative;
              display: inline-block;
              width: 54px;
              height: 29px;
            }
            
            .switch input { 
              opacity: 0;
              width: 0;
              height: 0;
            }
            
            .slider {
              position: absolute;
              cursor: pointer;
              top: 0;
              left: 0;
              right: 0;
              bottom: 0;
              background-color: #ccc;
              -webkit-transition: .4s;
              transition: .4s;
            }
            
            .slider:before {
              position: absolute;
              content: "";
              height: 20px;
              width: 20px;
              left: 4px;
              bottom: 4px;
              background-color: white;
              -webkit-transition: .4s;
              transition: .4s;
            }
            
            input:checked + .slider {
              background-color: #2196F3;
            }
            
            input:focus + .slider {
              box-shadow: 0 0 1px #2196F3;
            }
            
            input:checked + .slider:before {
              -webkit-transform: translateX(26px);
              -ms-transform: translateX(26px);
              transform: translateX(26px);
            }
            
            /* Rounded sliders */
            .slider.round {
              border-radius: 34px;
            }
            
            .slider.round:before {
              border-radius: 50%;
            }


            </style>
        </div>
        <!-- /.box-header -->
        <!-- form start -->
        <form role="form" method="POST" action="{{ route('setting.update',$sett->id) }}" enctype="multipart/form-data">

            {{ method_field('PUT') }}
            {{ csrf_field() }}
          <div class="box-body">

    {{-- ----------------- --}}
    <div class="col-md-8">
    <div class="info-box">
      <!-- Apply any bg-* class to to the icon to color it -->
      <span class="info-box-icon bg-info"><i style="color: lightslategray;" class="fa fa-cogs"></i></span>
      <div class="info-box-content">
        <span class="info-box-text">License Number</span>
        <span class="info-box-number">{{ $sett->license_number }}</span>
        <span class="info-box-text" style="color: #15be1d;">Active</span>
      </div>
      <!-- /.info-box-content -->
    </div>
    <!-- /.info-box -->
  </div>
  {{-- ----------------- --}}
  <div class="col-md-4">
    <div class="form-group">
      <label for="exampleInputEmail1">logo </label>
      <input type="file"  id="exampleInputText" name="logo" value="{{ $sett->logo }}" >
    </div>
  </div>

  {{-- ----------------- --}}
  <div class="col-md-4">
    <div class="form-group">
      <label for="exampleInputEmail1"> Allowed Publications  </label>
                   {{-- checked --}}
                   <?php

                   $varstatus = $sett->status;
                   $ch = "checked";

                     if ($varstatus == 1) {
                       echo '<label  style="color: #d9534f"> : Not Allowed </label><br>';
                       echo '<label class="switch">';
                       echo '<input type="checkbox" name="status" value="2" >' ;
                     }else{
                       echo '<label  style="color: #5cb85c"> : Allowed  </label><br>';
                       echo '<label class="switch">';
                       echo '<input type="checkbox" name="status" value="'.$sett->status.'" '.$ch.'>' ;
                     }
       
                   

                 ?>
         
                 <span class="slider round"></span>
                 </label>
    </div>
  </div>

            <div class="col-md-6">
            <div class="form-group">

            
                <label for="exampleInputText">Name App </label>
                <input type="text" class="form-control" id="exampleInputText" name="title" value="{{ $sett->title }}" placeholder="Enter title">
              </div>
            </div>
            <div class="col-md-6">
            <div class="form-group">
              <label for="exampleInputEmail1">Email </label>
              <input type="email" class="form-control" id="exampleInputEmail1" name="email" value="{{ $sett->email }}" placeholder="Enter Email">
            </div>
          </div>
          <div class="col-md-12">
            <div class="form-group">
                <label for="exampleInputEmail1">about </label>
                <textarea  type="text" class="form-control" name="about" id="" cols="5" rows="5" value="{{ $sett->about }}" placeholder="Enter About">{{ $sett->about }}</textarea>

              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group">
                <label for="exampleInputEmail1">Address </label>
                <input type="text" class="form-control" id="exampleInputText" name="address" value="{{ $sett->address }}" placeholder="Enter Address">
              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group">
                <label for="exampleInputEmail1">Phone </label>
                <input type="text" class="form-control" id="exampleInputText" name="phone" value="{{ $sett->phone }}" placeholder="Enter Phone">
              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group">
                <label for="exampleInputEmail1">Website </label>
                <input type="text" class="form-control" id="exampleInputText" name="web" value="{{ $sett->web }}" placeholder="Enter Website">
              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group">
                <label for="exampleInputEmail1">Facebook </label>
                <input type="text" class="form-control" id="exampleInputText" name="facebook" value="{{ $sett->facebook }}" placeholder="Enter Facebook">
              </div></div>
              <div class="col-md-4">
              <div class="form-group">
                <label for="exampleInputEmail1">Youtube </label>
                <input type="text" class="form-control" id="exampleInputText" name="youtube" value="{{ $sett->youtube }}" placeholder="Enter Youtube">
              </div></div>
              <div class="col-md-4">
              <div class="form-group">
                <label for="exampleInputEmail1">Twitter </label>
                <input type="text" class="form-control" id="exampleInputText" name="twitter" value="{{ $sett->twitter }}" placeholder="Enter Twitter">
              </div></div>
              <div class="col-md-4">
                <div class="form-group">
                  <label for="exampleInputEmail1">App IOS </label>
                  <input type="text"  id="exampleInputText" name="app_ios" value="{{ $sett->app_ios }}" >
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <label for="exampleInputEmail1">App Android </label>
                  <input type="text"  id="exampleInputText" name="app_android" value="{{ $sett->app_android }}" >
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <label for="exampleInputEmail1">App ip </label>
                  <input type="text"  id="exampleInputText" name="app_ip" value="{{ $sett->app_ip }}" >
                </div>
              </div>

          </div>
          <!-- /.box-body -->

          <div class="box-footer">
            <button type="submit" class="btn btn-primary">Update</button>
          </div>
        </form>
      </div>
      <!-- /.box -->
     
      <!-- /.box -->
    </div>
    <!-- /.col -->
  </div>
@stop

@section('js')

<script>
  $(document).ready( function () {
    $('#laravel_datatable').DataTable();
  });
</script>

@stop
