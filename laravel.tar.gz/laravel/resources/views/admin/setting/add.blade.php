<!doctype html>
<html lang="{{ app()->getLocale() }}">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Quick Setup</title>

        <!-- Fonts -->
       
        <link href="{{ asset('css/style.css') }}" rel="stylesheet">
        <!-- Styles -->
        <style>


        </style>
    </head>
    <body>
        <div class="flex-center position-ref full-height">
            @if (Route::has('login'))
                <div class="top-right links">
                    @auth
                        <a href="{{ url('/home') }}">Home</a>
                    @else
                        <a href="{{ route('login') }}">Login</a>
                        <a href="{{ route('register') }}">Register</a>
                    @endauth
                </div>
            @endif

            <div class="content">
            <div class="row">
    <div class="col-xs-8">
 
    <!-- general form elements -->

        <div class="box-header with-border">
         
        <h3 class="box-title">Quick Setup </h3>
        <!-- /.box-header -->
        <!-- form start -->
        <form role="form" method="POST" action="{{ route('install.store') }}" enctype="multipart/form-data">
        {{ csrf_field() }}
          <div class="box-body">

            <div class="col-md-6">
            <div class="form-group">
                <label for="exampleInputText">Name App أسم التطبيق</label>
                <input type="text" class="form-control" id="exampleInputText" name="title"  placeholder="Name App">
              </div>
            </div>



          <!-- /.box-body -->

          <div class="box-footer">
          <br>
            <button type="submit" class="btn btn-primary">Setup</button>
          </div>
        </form>
      </div>
      <!-- /.box -->
     
      <!-- /.box -->
    </div>
    <!-- /.col -->
  </div>


            </div>
        </div>
    </body>
</html>



