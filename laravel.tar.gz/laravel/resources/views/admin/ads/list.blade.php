@extends('adminlte::page')

@section('title', 'Users | Lara Admin')

@section('content_header')
    <h1>ads</h1>
    <a href="{{ route('ads.create') }}" class="btn btn-primary" role="button" style="float: right;"><i class="fa fa-bullhorn" aria-hidden="true"> </i>

       Add AD</a>
      <br><br>
    @stop


@section('content')

  <div class="row">
    
    <div class="col-xs-12">

      <div class="box">
        <div class="box-header">
          @if(Session::has('message'))
            <p class="alert {{ Session::get('alert-class', 'alert-info') }}">{{ Session::get('message') }}</p>
          @endif     
        </div>
        <div class="box-body">
          <table id="laravel_datatable" class="table table-bordered table-striped">
            <thead>
              <tr>
                <th>Image</th>
                <th>Title</th>
                <th>About</th>
                <th>Created_at</th>
                <th>Updated_at</th>
                <th>View</th>
                <th>Edit</th>
                <th>Delete</th>
              </tr>
            </thead>
            <tbody>
              @foreach ($ads as $item)
                <tr>
                
                  <td>
                    <a href="ads/{{ $item->id }}">
                    <img src="../storage/upload/{{ $item->ads_image }}" alt="" width="120" height="80">
                  </a>
                  </td>
                  <a href="post/{{ $item->id }}">
                  <td>{{ $item->ads_title }}</td>
                </a>
                  <td>{{ $item->ads_about }}</td>
                  <td>{{ $item->created_at }}</td>
                  <td>{{ $item->updated_at }}</td>
                 <td> <a href="ads/{{ $item->id }}" class="btn btn-default btn-sm" role="button">View</a></td>
                  <td>
                    <a href="{{ route('ads.edit',$item->id ) }}" class="btn btn-info btn-sm" role="button">Edit</a>
                    </td>
                  <td>
                    <form action="{{ route('ads.destroy',$item->id) }}" method="POST">
                      {{ csrf_field() }}
        
                      {{method_field('DELETE')}}
                
                      <button class="btn btn-primary btn-sm" type="submit" aria-label="">Delete</button>  
                  </form>
                  </td>
                </tr>
              @endforeach
            </tbody>
          </table>
        </div>
      </div>
      <!-- /.box -->
    </div>
    <!-- /.col -->
  </div>
@stop

@section('js')

<script>
  $(document).ready( function () {
    $('#laravel_datatable').DataTable();
  });
</script>

@stop