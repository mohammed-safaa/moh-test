@extends('adminlte::page')

@section('title', 'Users | Lara Admin')

@section('content_header')
    <h1>Add Ad</h1>
@stop

@section('content')
  <div class="row">
    <div class="col-xs-12">
     
    <!-- general form elements -->
    <div class="box box-primary">

        <!-- /.box-header -->
        <!-- form start -->
        <form role="form" method="POST" action="{{ route('ads.store') }}" enctype="multipart/form-data">
          {{ csrf_field() }}
          <div class="box-body">
            <div class="form-group">
                <label for="exampleInputText">Title </label>
                <input type="text" class="form-control" id="exampleInputText"  name="ads_title" placeholder="Ad Title">
              </div>
            <div class="form-group">
              <label for="exampleInputText">About</label>
              <textarea class="form-control"  name="ads_about" id="" cols="30" rows="2" placeholder="Ad About"></textarea>
    
            </div>

            <div class="form-group">
              <label for="exampleInputText">Trailer </label>
              <input type="text" class="form-control" id="exampleInputText" name="ads_trailer"  placeholder="Ad Trailer">
            </div>

            <div class="form-group">
              <label  class="control-label">Image File - width: 525 x height: 200  </label>
                  <input type="file"  name="ads_image"  required>
          </div>

          </div>
          <!-- /.box-body -->
  
          <div class="box-footer">
            <button type="submit" class="btn btn-primary">Update</button>
          </div>
        </form>
      </div>
      <!-- /.box -->
     
      <!-- /.box -->
    </div>
    <!-- /.col -->
  </div>
@stop

@section('js')

<script>
  $(document).ready( function () {
    $('#laravel_datatable').DataTable();
  });
</script>

@stop















