
@extends('adminlte::page')

@section('title', 'Users | Lara Admin')

@section('content_header')
    <h1>License</h1>
@stop

@section('content')




<br>


  <div class="row">
    <div class="col-xs-12">
     
    <!-- general form elements -->
    <div class="box box-primary">
    
        <!-- /.box-header -->
      
      </div>
      <!-- /.box -->
      @if (count($Pin) > 0)
      @foreach ($Pin as $item)
      <div class="panel panel-warning">
        <div class="panel-heading">License Number </div>
        <div class="panel-body">{{ $item->pidn}}</div>
      @endforeach
      </div> 
      @endif
      <!-- /.box -->
    </div>
    <!-- /.col -->
  </div>
@stop

@section('js')

<script>
  $(document).ready( function () {
    $('#laravel_datatable').DataTable();
  });
</script>

@stop













