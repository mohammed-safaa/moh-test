@extends('adminlte::page')

@section('title', 'Users | Lara Admin')

@section('content_header')
    <h1>Comment</h1>
@stop

@section('content')
  <div class="row">
    <div class="col-xs-12">
      <div class="box">
        <div class="box-header">
          @if(Session::has('message'))
            <p class="alert {{ Session::get('alert-class', 'alert-info') }}">{{ Session::get('message') }}</p>
          @endif     
        </div>
        <div class="box-body">
          <table id="laravel_datatable" class="table table-bordered table-striped">
            <thead>
              <tr>
                <th>User Name</th>
                <th>Comment</th>
                <th>Created At</th>
                <th>View</th>
                <th>Delete</th>
              </tr>
            </thead>
            <tbody>
              @foreach ($comment as $comm)
                <tr>

                  <td>{{ $comm->user->name }}</td>
                  <td>{{ $comm->comment }}</td>
                  <td>{{ $comm->created_at->format('D d , F, m.Y H:i:s A') }}</td>
                  <td>
                    <a href="post/{{ $comm->post_id }}" class="btn btn-info btn-sm" role="button">view</a>

                  </td>
                <td>
                  <form action="{{ route('dcomm.destroy',$comm->id) }}" method="POST">
                    {{ csrf_field() }}
      
                    {{method_field('DELETE')}}
              
                    <button class="btn btn-primary btn-sm" type="submit" aria-label="">Delete</button>  
                </form>
                  
                </td>
                </tr>
              @endforeach
            </tbody>
          </table>
        </div>
      </div>
      <!-- /.box -->
    </div>
    <!-- /.col -->
  </div>
@stop

@section('js')

<script>
  $(document).ready( function () {
    $('#laravel_datatable').DataTable();
  });
</script>

@stop