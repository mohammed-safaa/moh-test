@extends('adminlte::page')

@section('title', 'Users | Lara Admin')

@section('content_header')
    <h1>Occasions</h1>
    <a href="{{ route('occ.create') }}" class="btn btn-primary" role="button" style="float: right;"><i class="fa fa-bullhorn" aria-hidden="true"> </i>

       Add Occasion</a>
      <br><br>
    @stop


@section('content')

  <div class="row">
    
    <div class="col-xs-12">

      <div class="box">
        <div class="box-header">
          @if(Session::has('message'))
            <p class="alert {{ Session::get('alert-class', 'alert-info') }}">{{ Session::get('message') }}</p>
          @endif     
        </div>
        <div class="box-body">
          <table id="laravel_datatable" class="table table-bordered table-striped">
            <thead>
              <tr>
                <th>Image</th>
                <th>Title</th>
                <th>About</th>
                <th>Show Days</th>
                <th>Created_at</th>
                <th>Updated_at</th>
                <th>View</th>
                <th>Edit</th>
                <th>Delete</th>
              </tr>
            </thead>
            <tbody>
              @foreach ($occ as $item)
                <tr>
                
                  <td style="background-color: #303030">
                    <a href="occ/{{ $item->id }}">
                    <img src="../storage/upload/{{ $item->image }}" alt="" width="100" height="50" >
                  </a>
                  </td>
                  <a href="post/{{ $item->id }}">
                  <td>{{ $item->occasion_title }}</td>
                </a>
                  <td>{{ $item->occasion_about }}</td>
                  <td>{{ $item->show_days }}</td>
                  <td>{{ $item->created_at }}</td>
                  <td>{{ $item->updated_at }}</td>
                 <td> <a href="occ/{{ $item->id }}" class="btn btn-default btn-sm" role="button">View</a></td>
                  <td>
                    <a href="{{ route('occ.edit',$item->id ) }}" class="btn btn-info btn-sm" role="button">Edit</a>
                    </td>
                  <td>
                    <form action="{{ route('occ.destroy',$item->id) }}" method="POST">
                      {{ csrf_field() }}
        
                      {{method_field('DELETE')}}
                
                      <button class="btn btn-primary btn-sm" type="submit" aria-label="">Delete</button>  
                  </form>
                  </td>
                </tr>
              @endforeach
            </tbody>
          </table>
        </div>
      </div>
      <!-- /.box -->
    </div>
    <!-- /.col -->
  </div>
@stop

@section('js')

<script>
  $(document).ready( function () {
    $('#laravel_datatable').DataTable();
  });
</script>

@stop