@extends('adminlte::page')

@section('title', 'Users | Lara Admin')

@section('content_header')
    <h1>Add Occasion</h1>
@stop

@section('content')
  <div class="row">
    <div class="col-xs-12">
     
    <!-- general form elements -->
    <div class="box box-primary">

        <!-- /.box-header -->
        <!-- form start -->
        <form role="form" method="POST" action="{{ route('occ.store') }}" enctype="multipart/form-data">
          {{ csrf_field() }}
          <div class="box-body">
            <div class="form-group">
                <label for="exampleInputText">Title </label>
                <input type="text" class="form-control" id="exampleInputText"  name="occasion_title" placeholder="Occasion Title">
              </div>
            <div class="form-group">
              <label for="exampleInputText">About</label>
              <textarea class="form-control"  name="occasion_about" id="" cols="30" rows="2" placeholder="Occasion About"></textarea>
    
            </div>

            <div class="form-group">
              <label for="exampleInputText">Days </label>
              <input type="text" class="form-control" id="exampleInputText" name="show_days"  placeholder="Days">
            </div>
          
            <div class="form-group">
              <label  class="control-label">Image File - width: 70 x height: 30  Image Type : png </label>
                  <input type="file"  name="image" >
          </div>

          </div>
          <!-- /.box-body -->
  
          <div class="box-footer">
            <button type="submit" class="btn btn-primary">Add </button>
          </div>
        </form>
      </div>
      <!-- /.box -->
     
      <!-- /.box -->
    </div>
    <!-- /.col -->
  </div>
@stop

@section('js')

<script>
  $(document).ready( function () {
    $('#laravel_datatable').DataTable();
  });
</script>

@stop















