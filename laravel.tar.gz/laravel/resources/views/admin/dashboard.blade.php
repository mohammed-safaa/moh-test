
@extends('adminlte::page')

@section('title', 'Dashboard')

@section('content_header')
    <h1>Dashboard</h1>
@stop
@section('content')

    <p>Welcome To Admin Panel.</p>
    <div class="row">
    {{-- ----------------- --}}
<div class="col-md-3">
    <div class="info-box">
        <!-- Apply any bg-* class to to the icon to color it -->
        <span class="info-box-icon bg-info"><i style="color: lightslategray;" class="fa fa-users"></i></span>
        <div class="info-box-content">
          <span class="info-box-text">Users</span>
          <span class="info-box-number">{{ $users }}</span>
        </div>
        <!-- /.info-box-content -->
      </div>
      <!-- /.info-box -->
    </div>
    {{-- ----------------- --}}
        {{-- ----------------- --}}
<div class="col-md-3">
    <div class="info-box">
        <!-- Apply any bg-* class to to the icon to color it -->
        <span class="info-box-icon bg-info"><i style="color: lightslategray;" class="fa fa-film"></i></span>
        <div class="info-box-content">
          <span class="info-box-text">Movies</span>
          <span class="info-box-number">{{ $movies }}</span>
        </div>
        <!-- /.info-box-content -->
      </div>
      <!-- /.info-box -->
    </div>
    {{-- ----------------- --}}
        {{-- ----------------- --}}
<div class="col-md-3">
    <div class="info-box">
        <!-- Apply any bg-* class to to the icon to color it -->
        <span class="info-box-icon bg-info"><i style="color: lightslategray;" class="fa fa-film"></i></span>
        <div class="info-box-content">
          <span class="info-box-text">Tv Series</span>
          <span class="info-box-number">{{ $tvseries }}</span>
        </div>
        <!-- /.info-box-content -->
      </div>
      <!-- /.info-box -->
    </div>
    {{-- ----------------- --}}
        {{-- ----------------- --}}
<div class="col-md-3">
    <div class="info-box">
        <!-- Apply any bg-* class to to the icon to color it -->
        <span class="info-box-icon bg-info"><i style="color: lightslategray;" class="fa fa-eye"></i></span>
        <div class="info-box-content">
          <span class="info-box-text">Views</span>
          <span class="info-box-number">{{ $views }}</span>
        </div>
        <!-- /.info-box-content -->
      </div>
      <!-- /.info-box -->
    </div>
    {{-- ----------------- --}}
            {{-- ----------------- --}}
<div class="col-md-3">
  <div class="info-box">
      <!-- Apply any bg-* class to to the icon to color it -->
      <span class="info-box-icon bg-info"><i style="color: lightslategray;" class="fa fa-comments"></i></span>
      <div class="info-box-content">
        <span class="info-box-text">Comments</span>
        <span class="info-box-number">{{ $comments }}</span>
      </div>
      <!-- /.info-box-content -->
    </div>
    <!-- /.info-box -->
  </div>
  {{-- ----------------- --}}
        {{-- ----------------- --}}
<div class="col-md-3">
    <div class="info-box">
        <!-- Apply any bg-* class to to the icon to color it -->
        <span class="info-box-icon bg-info"><i style="color: lightslategray;" class="fa fa-thumbs-up"></i></span>
        <div class="info-box-content">
          <span class="info-box-text">Likes</span>
          <span class="info-box-number">{{ $likes }}</span>
        </div>
        <!-- /.info-box-content -->
      </div>
      <!-- /.info-box -->
    </div>
    {{-- ----------------- --}}
            {{-- ----------------- --}}
<div class="col-md-3">
  <div class="info-box">
      <!-- Apply any bg-* class to to the icon to color it -->
      <span class="info-box-icon bg-info"><i style="color: lightslategray;" class="fas fa-flag"></i></span>
      <div class="info-box-content">
        <span class="info-box-text">report</span>
        <span class="info-box-number">{{ $dslikes }}</span>
      </div>
      <!-- /.info-box-content -->
    </div>
    <!-- /.info-box -->
  </div>
  {{-- ----------------- --}}
        {{-- ----------------- --}}
<div class="col-md-3">
    <div class="info-box">
        <!-- Apply any bg-* class to to the icon to color it -->
        <span class="info-box-icon bg-info"><i style="color: lightslategray;" class="fa fa-database"></i></span>
        <div class="info-box-content">
          <span class="info-box-text">free hard disk </span>
          <span class="info-box-number">
            <?php
            $bytes = disk_free_space(".");
            $si_prefix = array( 'B', 'KB', 'MB', 'GB', 'TB', 'EB', 'ZB', 'YB' );
            $base = 1024;
            $class = min((int)log($bytes , $base) , count($si_prefix) - 1);
           
            echo sprintf('%1.2f' , $bytes / pow($base,$class)) . ' ' . $si_prefix[$class] . '<br />';
        
        ?>
            </span>
        </div>
        <!-- /.info-box-content -->
      </div>
      <!-- /.info-box -->
    </div>
    {{-- ----------------- --}}




       {{-- ----------------- --}}
<div class="col-md-3">
    <div class="info-box">
        <!-- Apply any bg-* class to to the icon to color it -->
        <span class="info-box-icon bg-info"><i style="color: lightslategray;" class="fa fa-microchip"></i></span>
        <div class="info-box-content">
          <span class="info-box-text">ram</span>
          <span class="info-box-number" style="font-size: 13px">
                                  <?php

// Returns used memory (either in percent (without percent sign) or free and overall in bytes)
function getServerMemoryUsage($getPercentage=true)
{
    $memoryTotal = null;
    $memoryFree = null;

    if (stristr(PHP_OS, "win")) {
        // Get total physical memory (this is in bytes)
        $cmd = "wmic ComputerSystem get TotalPhysicalMemory";
        @exec($cmd, $outputTotalPhysicalMemory);

        // Get free physical memory (this is in kibibytes!)
        $cmd = "wmic OS get FreePhysicalMemory";
        @exec($cmd, $outputFreePhysicalMemory);

        if ($outputTotalPhysicalMemory && $outputFreePhysicalMemory) {
            // Find total value
            foreach ($outputTotalPhysicalMemory as $line) {
                if ($line && preg_match("/^[0-9]+\$/", $line)) {
                    $memoryTotal = $line;
                    break;
                }
            }

            // Find free value
            foreach ($outputFreePhysicalMemory as $line) {
                if ($line && preg_match("/^[0-9]+\$/", $line)) {
                    $memoryFree = $line;
                    $memoryFree *= 1024;  // convert from kibibytes to bytes
                    break;
                }
            }
        }
    }
    else
    {
        if (is_readable("/proc/meminfo"))
        {
            $stats = @file_get_contents("/proc/meminfo");

            if ($stats !== false) {
                // Separate lines
                $stats = str_replace(array("\r\n", "\n\r", "\r"), "\n", $stats);
                $stats = explode("\n", $stats);

                // Separate values and find correct lines for total and free mem
                foreach ($stats as $statLine) {
                    $statLineData = explode(":", trim($statLine));

                    //
                    // Extract size (TODO: It seems that (at least) the two values for total and free memory have the unit "kB" always. Is this correct?
                    //

                    // Total memory
                    if (count($statLineData) == 2 && trim($statLineData[0]) == "MemTotal") {
                        $memoryTotal = trim($statLineData[1]);
                        $memoryTotal = explode(" ", $memoryTotal);
                        $memoryTotal = $memoryTotal[0];
                        $memoryTotal *= 1024;  // convert from kibibytes to bytes
                    }

                    // Free memory
                    if (count($statLineData) == 2 && trim($statLineData[0]) == "MemFree") {
                        $memoryFree = trim($statLineData[1]);
                        $memoryFree = explode(" ", $memoryFree);
                        $memoryFree = $memoryFree[0];
                        $memoryFree *= 1024;  // convert from kibibytes to bytes
                    }
                }
            }
        }
    }

    if (is_null($memoryTotal) || is_null($memoryFree)) {
        return null;
    } else {
        if ($getPercentage) {
            return (100 - ($memoryFree * 100 / $memoryTotal));
        } else {
            return array(
                "total" => $memoryTotal,
                "free" => $memoryFree,
            );
        }
    }
}

function getNiceFileSize($bytes, $binaryPrefix=true) {
    if ($binaryPrefix) {
        $unit=array('B','KiB','MiB','GiB','TiB','PiB');
        if ($bytes==0) return '0 ' . $unit[0];
        return @round($bytes/pow(1024,($i=floor(log($bytes,1024)))),2) .' '. (isset($unit[$i]) ? $unit[$i] : 'B');
    } else {
        $unit=array('B','KB','MB','GB','TB','PB');
        if ($bytes==0) return '0 ' . $unit[0];
        return @round($bytes/pow(1000,($i=floor(log($bytes,1000)))),2) .' '. (isset($unit[$i]) ? $unit[$i] : 'B');
    }
}

// Memory usage: 4.55 GiB / 23.91 GiB (19.013557664178%)
$memUsage = getServerMemoryUsage(false);
echo sprintf("usage : %s <br> total : %s ",
    getNiceFileSize($memUsage["total"] - $memUsage["free"]),
    getNiceFileSize($memUsage["total"]),
    getServerMemoryUsage(true)
);

            ?>
                      </div>
          
          </span>
        </div>
        <!-- /.info-box-content -->
      </div>
      <!-- /.info-box -->
   
    {{-- ----------------- --}}

       
    {{-- ----------------- --}}
    <div class="col-md-3">
      <div class="info-box">
          <!-- Apply any bg-* class to to the icon to color it -->
          <span class="info-box-icon bg-info"><i style="color: lightslategray;" class="fa fa-power-off"></i></span>
          <div class="info-box-content">
            <span class="info-box-text">uptime</span>
            <span class="info-box-number" style="font-size: 13px">
              <?php

              function uptime(){
                if(PHP_OS == "Linux") {
                  $uptime = @file_get_contents( "/proc/uptime");
                  if ($uptime !== false) {
                    $uptime = explode(" ",$uptime);
                    $uptime = $uptime[0];
                    $days = explode(".",(($uptime % 31556926) / 86400));
                    $hours = explode(".",((($uptime % 31556926) % 86400) / 3600));
                    $minutes = explode(".",(((($uptime % 31556926) % 86400) % 3600) / 60));
                    $time = "";
                    
                    if ($minutes > 0)
                      $time=$minutes[0]."m".$time;
                      
                    if ($minutes > 0 && ($hours > 0 || $days > 0))
                      $time = "-".$time;
                      
                    if ($hours > 0)
                      $time = $hours[0]."H".$time;
                    if ($hours > 0 && $days > 0)
                      $time = "-".$time;
                      
                    if ($days > 0)
                      $time = $days[0]."D".$time;
                      
                  } else {
                    $time = false;
                  }
                } else {
                  $time = false;
                }
                return $time;
              }
              echo uptime();
                ?>
            
            </span>
          </div>
          <!-- /.info-box-content -->
        </div>
        <!-- /.info-box -->
      </div>
      {{-- ----------------- --}}


    {{-- ----------------- --}}
    <div class="col-md-3">
      <div class="info-box">
          <!-- Apply any bg-* class to to the icon to color it -->
          <span class="info-box-icon bg-info"><i style="color: lightslategray;" class="fas fa-shield-alt"></i></span>
          <div class="info-box-content">
            <span class="info-box-text">License  الترخيص</span>
            <span class="info-box-number">
             
           @foreach ($sos as $item)
           @php
           $createdsos = $item->created_at ;
           $showDaysos = $item->show_days ;  

           @endphp
   
           @endforeach
            @php
     $created_atsos = date_create($createdsos);
    $DateTime1sos = date_format($created_atsos,"d-m-Y");
    $datePlus = date( "d-m-Y", strtotime( "$DateTime1sos +$showDaysos days" ) );
    $d1sos=strtotime($datePlus);
    $d2sos=ceil(($d1sos-time())/60/60/24);
    if($d2sos > 0){
      echo $d2sos;
      echo '<small> : الأيام المتبقية</small>';
    }else {
      echo '<small> License Expired <br> انتهاء فترة الترخيص</small>';
    }
    
            @endphp
           
            </span>
          </div>
          <!-- /.info-box-content -->
        </div>
        <!-- /.info-box -->
      </div>
      {{-- ----------------- --}}



          {{-- ----------------- --}}
          <div class="col-md-3">
            <div class="info-box">
                <!-- Apply any bg-* class to to the icon to color it -->
                <span class="info-box-icon bg-info"><i style="color: lightslategray;" class="fa fa-calendar"></i></span>
                <div class="info-box-content">
                  <span class="info-box-text">data time</span>
                  <span class="info-box-number" style="font-size: 13px">
                    <?php
                      echo  date("M d/m/Y") . "<br>";
                     echo date("l h:i  A")
                      ?>
                  </span>
                </div>
                <!-- /.info-box-content -->
              </div>
              <!-- /.info-box -->
            </div>
            {{-- ----------------- --}}










  </div>
@stop

@section('css')
    <link rel="stylesheet" href="/css/admin_custom.css">
@stop

@section('js')
    <script> console.log('Hi!'); </script>
@stop





