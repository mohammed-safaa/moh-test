@extends('adminlte::page')

@section('title', 'Users | Lara Admin')

@section('content_header')
    <h1>Search</h1>
@stop

@section('content')
  <div class="row">
    <div class="col-xs-12">
      <div class="box">
        <div class="box-header">
    
        </div>
        <div class="box-body">
          <table id="laravel_datatable" class="table table-bordered table-striped">
            <thead>
              <tr>
                <th>search</th>
                <th>Name</th>
                <th>Created At</th>
                <th>Delete</th>
              </tr>
            </thead>
            <tbody>
              @foreach ($allsearch as $search)
                <tr>
                  <td>{{ $search->Search }}</td>
                  <td>{{ $search->user->name }}</td> 
                  <td>{{ $search->created_at }}</td>


                <td>
                  <form action="{{ route('search.destroy',$search->id) }}" method="POST">
                    {{ csrf_field() }}
      
                    {{method_field('DELETE')}}
              
                    <button class="btn btn-primary btn-sm" type="submit" aria-label="">Delete</button>  
                </form>
                  
                </td>
                </tr>
              @endforeach
            </tbody>
          </table>
        </div>
      </div>
      <!-- /.box -->
    </div>
    <!-- /.col -->
  </div>
@stop

@section('js')

<script>
  $(document).ready( function () {
    $('#laravel_datatable').DataTable();
  });
</script>

@stop