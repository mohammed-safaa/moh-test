@extends('adminlte::page')

@section('title', 'Users | Lara Admin')

@section('content_header')
    <h1>Edit User</h1>
@stop

@section('content')
  <div class="row">
    <div class="col-xs-12">
     
    <!-- general form elements -->
    <div class="box box-primary">
        <div class="box-header with-border">
          <h3 class="box-title">Edit User</h3>
        </div>
        <!-- /.box-header -->
        <!-- form start -->
        <form role="form" method="POST" action="{{ route('duser.update',$users->id) }}">
            {{ method_field('PUT') }}
            {{ csrf_field() }}
          <div class="box-body">
            <div class="form-group">
                <label for="exampleInputText">Name </label>
                <input type="text" class="form-control" id="exampleInputText" name="name" value="{{ $users->name }}" placeholder="Enter email">
              </div>
            <div class="form-group">
              <label for="exampleInputEmail1">Email address</label>
              <input type="email" class="form-control" id="exampleInputEmail1" name="email" value="{{ $users->email }}" placeholder="Enter email">
            </div>
            <div class="form-group">
                <label for="exampleInputEmail1">description </label>
                <input type="text" class="form-control" id="exampleInputText" name="description" value="{{ $users->description }}" placeholder="Enter email">
              </div>
              <div class="form-group">
                <label for="exampleInputEmail1">status </label>
                <input type="text" class="form-control" id="exampleInputText" name="status" value="{{ $users->status }}" placeholder="Enter email">
              </div>
              <div class="form-group">
                <label for="exampleInputEmail1">gender </label>
                <input type="text" class="form-control" id="exampleInputText" name="gender" value="{{ $users->gender }}" placeholder="Enter email">
              </div>
              <div class="form-group">
                <label for="exampleInputEmail1">birthday </label>
                <input type="text" class="form-control" id="exampleInputText" name="birthday" value="{{ $users->birthday }}" placeholder="Enter email">
              </div>
              <div class="form-group">
                <label for="exampleInputEmail1">country </label>
                <input type="text" class="form-control" id="exampleInputText" name="country" value="{{ $users->country }}" placeholder="Enter email">
              </div>
              <div class="form-group">
                <label for="exampleInputEmail1">city </label>
                <input type="text" class="form-control" id="exampleInputText" name="city" value="{{ $users->city }}" placeholder="Enter email">
              </div>



          </div>
          <!-- /.box-body -->
  
          <div class="box-footer">
            <button type="submit" class="btn btn-primary">Update</button>
          </div>
        </form>
      </div>
      <!-- /.box -->
     
      <!-- /.box -->
    </div>
    <!-- /.col -->
  </div>
@stop

@section('js')

<script>
  $(document).ready( function () {
    $('#laravel_datatable').DataTable();
  });
</script>

@stop















