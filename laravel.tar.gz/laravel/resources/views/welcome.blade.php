<!doctype html>
<html lang="{{ app()->getLocale() }}">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Welcome Guest</title>

        <!-- Fonts -->
       
        <link href="{{ asset('css/style.css') }}" rel="stylesheet">
        <!-- Styles -->
        <style>


        </style>
    </head>
    <body>
        <div class="flex-center position-ref full-height">
            @if (Route::has('login'))
                <div class="top-right links">
                    @auth
                        <a href="{{ url('/home') }}">Home</a>
                    @else
                        <a href="{{ route('login') }}">Login</a>
                        <a href="{{ route('register') }}">Register</a>
                    @endauth
                </div>
            @endif

            <div class="content">
                <div class="title m-b-md" style="color: #c0c6c9;">
                    <img src="../storage/upload/{{ config('app.logo') }}" width="100" height="100"  style="margin-left: 130px; margin-top: -100px; position: absolute;">
                    {{ config('app.name') }}
                </div>

                <div class="links">
                    <a href="login">Welcome guest let's go !</a>
                </div>
            </div>
        </div>
    </body>
</html>
