@extends('layouts.app')
@section('content')

<div class="container">

  <div class="row">

    <section id="row1">
      <h1 class="sectionTitle"></h1>
      <ul class="img-list">
      
        @if (count($watched) > 0) 
        @foreach ($watched as $item)
        <div class="col-xs-6 col-sm-3 col-md-3 col-lg-2 col-xl-2" >
           <li class="image"> 
              <a href="/post/{{ $item->postid }}">
              <img id="box1" src="../storage/upload/{{ $item->image }}" width="185" height="130" />
              <span class="text-content"><span>{{ $item->title }}</span></span>
               </a>
           </li>
        </div>
 
        @endforeach
   
           
 @endif
      </ul>
     
      </section>
    
        </div><!-- row-->
       
        <nav aria-label="Page navigation example">
          <ul class="pagination justify-content-end">

            <li class="page-item">{{ $watched->links() }}</li>


          </ul>
        </nav>




 {{-- botton up --}}
 <div class="text-right">
  <br>
  <button class="btn btn-outline-light" onclick="topFunction()" id="myBtn" title="Go to top"> <i class="fas fa-chevron-up"></i></button>
</div>
       
</div> <!-- container -->

{{-- ajax video data --}}
@endsection