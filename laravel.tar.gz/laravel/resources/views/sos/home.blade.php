@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12 col-md-offset-0">
            <div class="panel panel-default">
                <div class="panel-heading">All SOS</div>

                <div class="panel-body">
                    <!--- \\\\\\\Post مشورات -->
                      <p>The .table-striped class adds zebra-stripes to a table:</p>    
                      <a href="{{ route('sos.create') }}" class="btn btn-info btn-sm" role="button">Add SOS</a>   
                      <br>     
                      <table class="table table-striped">
                        <thead>
                          <tr>
                            <th>title</th>
                            <th>about</th>
                            <th>img</th>
                            <th>show days</th>
                            <th>time</th>
                            <th>View</th>
                            <th>Edit</th>
                            <th>Delete</th>
                          </tr>
                        </thead>
                        <tbody>

                    @if (count($allsos) > 0)
                   
                    @foreach ($allsos as $sos_item)
                          <tr>
                            
                            <td>{{ $sos_item->sos_title }}</td>
                            <td>{{ $sos_item->sos_about }}</td>
                            <td>{{ $sos_item->show_days }}</td>
                            <td><img  src="storage/sos/{{ $sos_item->image }}"  height="50" width="50"></td>
                            <td>{{ $sos_item->created_at }}</td>
                            <td><a href="sos/{{ $sos_item->id }}" class="btn btn-info btn-sm" role="button">View</a></td>
                            <td><a href="{{ route('sos.edit',$sos_item->id) }}" class="btn btn-warning btn-sm">Edit</a></td>
                            <td>
                            <!-- start delete Post حذف المنشور -->
                            <form action="{{ route('sos.destroy',$sos_item->id) }}" method="POST">
                              {{ csrf_field() }}
            
                              {{method_field('DELETE')}}
                         
                           <button class="btn btn-danger btn-sm" type="submit" >Delete</button>
                           </form>
             <!-- end delete Post حذف المنشور -->
                          </tr>

                          @endforeach
                        </tbody>
                      </table>

            
                            </div>
                            </div>
            
                            </div>
                            <!-- Post /////-->
                            <br>
                         
            
            
                            <!--START NO Post في حالة لا توجد منشورات  -->
                            @else
                            <div class="alert alert-danger" role="alert">
                              no database!
                            </div>
                             <!--END NO Post -->
            
                            @endif





                </div>
            </div>
        </div>
    </div>
</div>
@endsection
