@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">

        <div class="col-md-8">
            <h2>add sos</h2>
            <form  method="POST" action="{{ route('sos.store') }}" enctype="multipart/form-data">
                {{ csrf_field() }}
                <div class="form-group">
                  <label for="text">SOS Title:</label>
                  <input type="text" class="form-control" id="text"  name="title">
                </div>

                <div class="form-group">
                    <label for="comment">SOS About:</label>
                    <textarea  type="text" class="form-control" rows="4" id="comment" name="about"></textarea>
                  </div>
                  <div class="form-group">
                    <label for="comment">SOS show days:</label>
                    <input  type="text" class="form-control"   name="show_days">
                  </div>

                  <div class="form-group">
                    <label for="exampleFormControlFile1">image</label>
                    <input type="file" class="form-control-file" id="exampleFormControlFile1" name="image">
                  </div>



                <button type="submit" class="btn btn-primary">Submit</button>
              </form>





        </div>



      </div>
</div>
@endsection
