@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">

        <div class="col-md-8">
            <h2>Edit Ads </h2>
            <form  method="POST" action="{{ route('occasionGET.update',$sosid->id) }}" enctype="multipart/form-data">
                {{ method_field('PUT') }}
                {{ csrf_field() }}
                <div class="form-group">
                  <label for="text">Title:</label>
                  <input type="text" class="form-control" id="text" value="{{ $sosid->sos_title }}" name="title">
                </div>

                <div class="form-group">
                    <label for="comment">About:</label>
                    <textarea class="form-control" rows="4" id="comment" value="{{ $sosid->sos_about }}" name="about">{{ $sosid->sos_about }}</textarea>
                  </div>
                  <div class="form-group"> 
                    <label for="text">show_days:</label>
                    <input type="text" class="form-control" id="text" value="{{ $sosid->show_days }}" name="show_days">
                  </div>

                  <div class="form-group">
                   
                    <img  src="../../storage/sos/{{ $sosid->image }}"  height="150" width="150">
                   
                  </div>

                <button type="submit" class="btn btn-primary">Submit</button>
              </form>

        </div>



      </div>
</div>
@endsection
