@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <img src="../storage/sos/{{ $sos->image }}"  height="300" width="490">
           <br>
            <div class="card-body">
                <h5 class="card-title">{{ $sos->sos_title }} </h5>
            <div class="card-text">
                <p class="comment more">
                    {{ $sos->sos_about }}
                </p>
                </div>

        </div>



        </div>
   </div>
<div>






@endsection
