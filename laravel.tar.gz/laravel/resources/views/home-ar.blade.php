@extends('layouts.app2')
@section('content')


<div class="container">
  <div class="row">
<br>
    <section id="row1">
       
      <h1 class="sectionTitlear"> الأفلام المضافة مؤخرًا</h1>
      <ul class="img-list">
        @if (count($New) > 0)
        @foreach ($New as $item)
        <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2" >
           <li class="image"> 
              <a href="post/{{ $item->id }}">
              <img id="box1" src="../storage/upload/{{ $item->image }}" width="185" height="130" />
              <span class="text-content"><span>{{ $item->title }}</span></span>
               </a>
           </li>
        </div>
 
        @endforeach
   
  <!--START NO Post في حالة لا توجد منشورات  -->
       @else
        <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2">
              <div class="alert alert-dark">
                 <strong>عذراً ! </strong> لا توجد بيانات
              </div>
       </div> 
       <!--END NO Post -->
           
 @endif
      </ul>
     
      </section>
    
      </div><!-- row-->
     <div class="row" style="float: right">
      
     
     </div>
     <br>
     <br><br>


   
    
     {{-- --------------users card ------------------- --}}

<div class="row">
   @foreach ($userNew as $item)
   <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2">
<a href="profile/{{ $item->id }}">
   <figure class="snip1336">
      <img style="height: 150px " src="../storage/upload/{{ $item->img_backround }}" alt="sample87" />
      <figcaption>
        <img src="../storage/upload/{{ $item->img_avatar }}" alt="profile-sample4" class="profile" />
        <h2>{{ $item->name }}<span>{{ $item->country }} - {{ $item->city }} </span></h2>
      </figcaption>
     
    </figure>
   </a>
   </div>

   @endforeach
     </div>

     <br>
     <br><br>


{{-- -------------------users card ----------------------- --}}





     {{-- --------------------------------- --}}
     @if (count($Movies) > 0)
<div class="row">
  <section id="row1">
    <h1 class="sectionTitlear">الأفلام</h1>
    <ul class="img-list">
      @foreach ($Movies as $item)
      <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2">
         <li class="image"> 
            <a href="post/{{ $item->id }}">
            <img id="box1" src="../storage/upload/{{ $item->image }}" width="185" height="130" />
            <span class="text-content"><span>{{ $item->title }}</span></span>
             </a>
         </li>
      </div>
      @endforeach
    </ul>
    </section>

    </div><!-- row-->
    <div class="row" style="float: left">
      <br>
      <a href="movtv/{{ $item->movies_tvseries }}">لمشاهدة المزيد </a>
     
     </div>
     <br>
    <br><br>
    @endif
{{-- ------------------------------------------ --}}
    @if (count($Tvseries) > 0)
    <div class="row">
      <section id="row1">
        <h1 class="sectionTitlear"> مسلسل تلفزيونى</h1>
        <ul class="img-list">

          @foreach ($Tvseries as $item)
          <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2">
             <li class="image"> 
                <a href="post/{{ $item->id }}">
                <img id="box1" src="../storage/upload/{{ $item->image }}" width="185" height="130" />
                <span class="text-content"><span>{{ $item->title }}</span></span>
                 </a>
             </li>
          </div>
          @endforeach
        </ul>
        </section>
    
        </div><!-- row-->
        <div class="row" style="float: left">
         <br>
         <a href="movtv/{{ $item->movies_tvseries }}">لمشاهدة المزيد </a>
        </div>
        <br>
        <br><br>
        @endif


{{-- ------------------------------------ --}}
@if (count($Netflix) > 0)
<div class="row">
 <section id="row1">
   <h1 class="sectionTitlear">نتفليكس</h1>
   <ul class="img-list">
     @foreach ($Netflix as $item)
     <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2">
        <li class="image"> 
           <a href="post/{{ $item->id }}">
           <img id="box1" src="../storage/upload/{{ $item->image }}" width="185" height="130" />
           <span class="text-content"><span>{{ $item->title }}</span></span>
            </a>
        </li>
     </div>
     @endforeach
      

   </ul>
   </section>

   </div><!-- row-->
   <div class="row" style="float: left">
      <br>
    <a href="more/{{ $item->category }}">لمشاهدة المزيد</a>
   
   </div>
   <br>
   <br><br>
   @endif
{{-- ------------------------------------ --}}



{{-- ------------------------------------------------- --}}
        @if (count($populer) > 0)
        <div class="row">
         <section id="row1">
           <h1 class="sectionTitlearar">اﻷكثر شعبية</h1>
           <ul class="img-list">
             @foreach ($populer as $item)
             <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2">
                <li class="image"> 
                   <a href="post/{{ $item->id }}">
                   <img id="box1" src="../storage/upload/{{ $item->image }}" width="185" height="130" />
                   <span class="text-content"><span>{{ $item->title }}</span></span>
                    </a>
                </li>
             </div>
             @endforeach

           </ul>
           </section>
       
           </div><!-- row-->
           <div class="row" style="float: left">
            <br>
            <a href="more/{{ $item->category }}">لمشاهدة المزيد </a>
           
           </div>
           <br>
           <br><br>
           @endif
{{-- ----------------------------------------- --}}

           @if (count($Action) > 0)
           <div class="row">
            <section id="row1">
              <h1 class="sectionTitlear">أكشن</h1>
              <ul class="img-list">
                @foreach ($Action as $item)
                <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2">
                   <li class="image"> 
                      <a href="post/{{ $item->id }}">
                      <img id="box1" src="../storage/upload/{{ $item->image }}" width="185" height="130" />
                      <span class="text-content"><span>{{ $item->title }}</span></span>
                       </a>
                   </li>
                </div>
                @endforeach
              </ul>
              </section>
          
              </div><!-- row-->
              <div class="row" style="float: left">
               <br>
               <a href="more/{{ $item->category }}">لمشاهدة المزيد </a>
              
              </div>
              <br>
              <br><br>
              
{{-- --------------------------------------- --}}





     {{-- --------------users card ------------------- --}}

     <div class="row">

 
      @foreach ($userFemale as $item)
      <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2">
   <a href="profile/{{ $item->id }}">
      <figure class="snip1336">
         <img style="height: 150px " src="../storage/upload/{{ $item->img_backround }}" alt="sample87" />
         <figcaption>
           <img src="../storage/upload/{{ $item->img_avatar }}" alt="profile-sample4" class="profile" />
           <h2>{{ $item->name }}<span>{{ $item->country }} - {{ $item->city }} </span></h2>
         </figcaption>
        
       </figure>
      </a>
      </div>
   
      @endforeach
        </div>
   
        <br>
        <br><br>
   
   
   {{-- -------------------users card ----------------------- --}}
   @endif

{{-- --------------------------------------- --}}

              @if (count($Fantasy) > 0)
              <div class="row">
               <section id="row1">
                 <h1 class="sectionTitlear">خيالي</h1>
                 <ul class="img-list">
                   @foreach ($Fantasy as $item)
                   <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2">
                      <li class="image"> 
                         <a href="post/{{ $item->id }}">
                         <img id="box1" src="../storage/upload/{{ $item->image }}" width="185" height="130" />
                         <span class="text-content"><span>{{ $item->title }}</span></span>
                          </a>
                      </li>
                   </div>
                   @endforeach
                 </ul>
                 </section>
             
                 </div><!-- row-->
                 <div class="row" style="float: left">
                  <br>
                  <a href="more/{{ $item->category }}">لمشاهدة المزيد </a>
                 
                 </div>
                 <br>
                 <br><br>
                 @endif
{{-- -------------------------------- --}}

                 @if (count($Animation) > 0)
              <div class="row">
               <section id="row1">
                 <h1 class="sectionTitlear">  الانيميشن / اﻷطفال</h1>
                 <ul class="img-list">

                   @foreach ($Animation as $item)
                   <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2">
                      <li class="image"> 
                         <a href="post/{{ $item->id }}">
                         <img id="box1" src="../storage/upload/{{ $item->image }}" width="185" height="130" />
                         <span class="text-content"><span>{{ $item->title }}</span></span>
                          </a>
                      </li>
                   </div>
                   @endforeach
                 </ul>
                 </section>
             
                 </div><!-- row-->
                 <div class="row" style="float: left">
                  <br>
                  <a href="more/{{ $item->category }}">لمشاهدة المزيد </a>
                 
                 </div>
                 <br>
                 <br><br>

                 @endif

{{-- -------------------------------- --}}
                 @if (count($Horror) > 0)
                 <div class="row">
                  <section id="row1">
                    <h1 class="sectionTitlear">رعب</h1>
                    <ul class="img-list">
                      @foreach ($Horror as $item)
                      <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2">
                         <li class="image"> 
                            <a href="post/{{ $item->id }}">
                            <img id="box1" src="../storage/upload/{{ $item->image }}" width="185" height="130" />
                            <span class="text-content"><span>{{ $item->title }}</span></span>
                             </a>
                         </li>
                      </div>
                      @endforeach
                    </ul>
                    </section>
                
                    </div><!-- row-->
                    <div class="row" style="float: left">
                     <br>
                     <a href="more/{{ $item->category }}">لمشاهدة المزيد </a>
                    
                    </div>
                    <br>
                    <br><br>
   
                    @endif

                    {{-- ------------------------------------- --}}

                    @if (count($Arabic) > 0)
                    <div class="row">
                     <section id="row1">
                       <h1 class="sectionTitlear">اﻷفلام العربية</h1>
                       <ul class="img-list">
                         @foreach ($Arabic as $item)
                         <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2">
                            <li class="image"> 
                               <a href="post/{{ $item->id }}">
                               <img id="box1" src="../storage/upload/{{ $item->image }}" width="185" height="130" />
                               <span class="text-content"><span>{{ $item->title }}</span></span>
                                </a>
                            </li>
                         </div>
                         @endforeach
                       </ul>
                       </section>
                       </div><!-- row-->
                       <div class="row" style="float: left">
                        <br>
                        <a href="more/{{ $item->category }}">لمشاهدة المزيد </a>
                       </div>
                       <br>
                       <br><br>
                      
      {{-- -------------------------------------- --}}

    

     {{-- --------------users card ------------------- --}}

     <div class="row">

      @foreach ($userMale as $item)
      <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2">
   <a href="profile/{{ $item->id }}">
      <figure class="snip1336">
         <img style="height: 150px " src="../storage/upload/{{ $item->img_backround }}" alt="sample87" />
         <figcaption>
           <img src="../storage/upload/{{ $item->img_avatar }}" alt="profile-sample4" class="profile" />
           <h2>{{ $item->name }}<span>{{ $item->country }} - {{ $item->city }} </span></h2>
         </figcaption>
        
       </figure>
      </a>
      </div>
   
      @endforeach
        </div>
   
        <br>
        <br><br>
   
   
   {{-- -------------------users card ----------------------- --}}
   @endif




                            @if (count($Turkish) > 0)
                            <div class="row">
                              <section id="row1">
                                <h1 class="sectionTitlear">اﻷفلام التركية</h1>
                                <ul class="img-list">
                            @foreach ($Turkish as $item)
                            <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2">
                               <li class="image"> 
                                  <a href="post/{{ $item->id }}">
                                  <img id="box1" src="../storage/upload/{{ $item->image }}" width="185" height="130" />
                                  <span class="text-content"><span>{{ $item->title }}</span></span>
                                   </a>
                               </li>
                            </div>
                            @endforeach

                     </ul>
                  </section>
              
                  </div><!-- row-->
                  <div class="row" style="float: left">
                     <br>
                   <a href="more/{{ $item->category }}">لمشاهدة المزيد </a>
                  
                  </div>
                  <br>
                  <br><br>
   
                   @endif

         


                   @if (count($Indian) > 0)
                          <div class="row">
          
                               <section id="row1">
                                 <h1 class="sectionTitlear">اﻷفلام الهندية</h1>
                                 <ul class="img-list">
                               @foreach ($Indian as $item)
                               <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2">
                                  <li class="image"> 
                                     <a href="post/{{ $item->id }}">
                                     <img id="box1" src="../storage/upload/{{ $item->image }}" width="185" height="130" />
                                     <span class="text-content"><span>{{ $item->title }}</span></span>
                                      </a>
                                  </li>
                               </div>
                               @endforeach

                                
                     
                             </ul>
                             </section>
                         
                             </div><!-- row-->
                             <div class="row" style="float: left">
                              <br>
                              <a href="more/{{ $item->category }}">لمشاهدة المزيد</a>
                             
                             </div>
                             <br>
                             <br><br>

                             @endif
{{-- ------------------------------------ --}}
                     @if (count($Documentary) > 0)
                          <div class="row">
                           <section id="row1">
                             <h1 class="sectionTitlear">اﻷفلام الوثائقية</h1>
                             <ul class="img-list">
                               @foreach ($Documentary as $item)
                               <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2">
                                  <li class="image"> 
                                     <a href="post/{{ $item->id }}">
                                     <img id="box1" src="../storage/upload/{{ $item->image }}" width="185" height="130" />
                                     <span class="text-content"><span>{{ $item->title }}</span></span>
                                      </a>
                                  </li>
                               </div>
                               @endforeach
                                
                  
                             </ul>
                             </section>
                         
                             </div><!-- row-->
                             <div class="row" style="float: left">
                              <br>
                              <a href="more/{{ $item->category }}">لمشاهدة المزيد </a>
                             
                             </div>
                             <br>
                             <br><br>
                            
{{-- ------------------------------------ --}}


     {{-- --------------users card ------------------- --}}

     <div class="row">

      @foreach ($user as $item)
      <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2">
   <a href="profile/{{ $item->id }}">
      <figure class="snip1336">
         <img style="height: 150px " src="../storage/upload/{{ $item->img_backround }}" alt="sample87" />
         <figcaption>
           <img src="../storage/upload/{{ $item->img_avatar }}" alt="profile-sample4" class="profile" />
           <h2>{{ $item->name }}<span>{{ $item->country }} - {{ $item->city }} </span></h2>
         </figcaption>
        
       </figure>
      </a>
      </div>
   
      @endforeach
        </div>
   
        <br>
        <br><br>
   
   
   {{-- -------------------users card ----------------------- --}}
   @endif



@if (count($Drama) > 0)
<div class="row">
 <section id="row1">
   <h1 class="sectionTitlear">دراما</h1>
   <ul class="img-list">
     @foreach ($Drama as $item)
     <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2">
        <li class="image"> 
           <a href="post/{{ $item->id }}">
           <img id="box1" src="../storage/upload/{{ $item->image }}" width="185" height="130" />
           <span class="text-content"><span>{{ $item->title }}</span></span>
            </a>
        </li>
     </div>
     @endforeach
      

   </ul>
   </section>

   </div><!-- row-->
   <div class="row" style="float: left">
      <br>
    <a href="more/{{ $item->category }}">لمشاهدة المزيد</a>
   
   </div>
   <br>
   <br><br>
   @endif
{{-- ------------------------------------ --}}
@if (count($Romance) > 0)
<div class="row">
 <section id="row1">
   <h1 class="sectionTitlear">رومانسي</h1>
   <ul class="img-list">
     @foreach ($Romance as $item)
     <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2">
        <li class="image"> 
           <a href="post/{{ $item->id }}">
           <img id="box1" src="../storage/upload/{{ $item->image }}" width="185" height="130" />
           <span class="text-content"><span>{{ $item->title }}</span></span>
            </a>
        </li>
     </div>
     @endforeach
      

   </ul>
   </section>

   </div><!-- row-->
   <div class="row" style="float: left">
      <br>
    <a href="more/{{ $item->category }}">لمشاهدة المزيد</a>
   
   </div>
   <br>
   <br><br>
   @endif
{{-- ------------------------------------ --}}
@if (count($Sci_Fi) > 0)
<div class="row">
 <section id="row1">
   <h1 class="sectionTitlear">خيال علمي</h1>
   <ul class="img-list">
     @foreach ($Sci_Fi as $item)
     <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2">
        <li class="image"> 
           <a href="post/{{ $item->id }}">
           <img id="box1" src="../storage/upload/{{ $item->image }}" width="185" height="130" />
           <span class="text-content"><span>{{ $item->title }}</span></span>
            </a>
        </li>
     </div>
     @endforeach
      

   </ul>
   </section>

   </div><!-- row-->
   <div class="row" style="float: left">
      <br>
    <a href="more/{{ $item->category }}">لمشاهدة المزيد </a>
   
   </div>
   <br>
   <br><br>
   @endif
{{-- ------------------------------------ --}}
@if (count($Social) > 0)
<div class="row">
 <section id="row1">
   <h1 class="sectionTitlear">الاجتماعية</h1>
   <ul class="img-list">
     @foreach ($Social as $item)
     <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2">
        <li class="image"> 
           <a href="post/{{ $item->id }}">
           <img id="box1" src="../storage/upload/{{ $item->image }}" width="185" height="130" />
           <span class="text-content"><span>{{ $item->title }}</span></span>
            </a>
        </li>
     </div>
     @endforeach
      

   </ul>
   </section>

   </div><!-- row-->
   <div class="row" style="float: left">
      <br>
    <a href="more/{{ $item->category }}">لمشاهدة المزيد </a>
   
   </div>
   <br>
   <br><br>
  
{{-- ------------------------------------ --}}


     {{-- --------------users card ------------------- --}}

     <div class="row">

      @foreach ($user as $item)
      <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2">
   <a href="profile/{{ $item->id }}">
      <figure class="snip1336">
         <img style="height: 150px " src="../storage/upload/{{ $item->img_backround }}" alt="sample87" />
         <figcaption>
           <img src="../storage/upload/{{ $item->img_avatar }}" alt="profile-sample4" class="profile" />
           <h2>{{ $item->name }}<span>{{ $item->country }} - {{ $item->city }} </span></h2>
         </figcaption>
        
       </figure>
      </a>
      </div>
   
      @endforeach
        </div>
   
        <br>
        <br><br>
   
   
   {{-- -------------------users card ----------------------- --}}
   @endif



@if (count($Mystery) > 0)
<div class="row">
 <section id="row1">
   <h1 class="sectionTitlear">الغموض</h1>
   <ul class="img-list">
     @foreach ($Mystery as $item)
     <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2">
        <li class="image"> 
           <a href="post/{{ $item->id }}">
           <img id="box1" src="../storage/upload/{{ $item->image }}" width="185" height="130" />
           <span class="text-content"><span>{{ $item->title }}</span></span>
            </a>
        </li>
     </div>
     @endforeach
      

   </ul>
   </section>

   </div><!-- row-->
   <div class="row" style="float: left">
      <br>
    <a href="more/{{ $item->category }}">لمشاهدة المزيد</a>
   
   </div>
   <br>
   <br><br>
   @endif
{{-- ------------------------------------ --}}
@if (count($War) > 0)
<div class="row">
 <section id="row1">
   <h1 class="sectionTitlear">حرب</h1>
   <ul class="img-list">
     @foreach ($War as $item)
     <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2">
        <li class="image"> 
           <a href="post/{{ $item->id }}">
           <img id="box1" src="../storage/upload/{{ $item->image }}" width="185" height="130" />
           <span class="text-content"><span>{{ $item->title }}</span></span>
            </a>
        </li>
     </div>
     @endforeach
      

   </ul>
   </section>

   </div><!-- row-->
   <div class="row" style="float: left">
      <br>
    <a href="more/{{ $item->category }}">لمشاهدة المزيد</a>
   
   </div>
   <br>
   <br><br>
   @endif
{{-- ------------------------------------ --}}
@if (count($Family) > 0)
<div class="row">
 <section id="row1">
   <h1 class="sectionTitlear">عائلي/أطفال</h1>
   <ul class="img-list">
     @foreach ($Family as $item)
     <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2">
        <li class="image"> 
           <a href="post/{{ $item->id }}">
           <img id="box1" src="../storage/upload/{{ $item->image }}" width="185" height="130" />
           <span class="text-content"><span>{{ $item->title }}</span></span>
            </a>
        </li>
     </div>
     @endforeach
      

   </ul>
   </section>

   </div><!-- row-->
   <div class="row" style="float: left">
      <br>
    <a href="more/{{ $item->category }}">لمشاهدة المزيد</a>
   
   </div>
   <br>
   <br><br>
   @endif
{{-- ------------------------------------ --}}
{{-- ------------------------------------ --}}
@if (count($Western) > 0)
<div class="row">
 <section id="row1">
   <h1 class="sectionTitlear">الغربي</h1>
   <ul class="img-list">
     @foreach ($Western as $item)
     <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2">
        <li class="image"> 
           <a href="post/{{ $item->id }}">
           <img id="box1" src="../storage/upload/{{ $item->image }}" width="185" height="130" />
           <span class="text-content"><span>{{ $item->title }}</span></span>
            </a>
        </li>
     </div>
     @endforeach
      

   </ul>
   </section>

   </div><!-- row-->
   <div class="row" style="float: left">
      <br>
    <a href="more/{{ $item->category }}">لمشاهدة المزيد</a>
   
   </div>
   <br>
   <br><br>
  
{{-- ------------------------------------ --}}



     {{-- --------------users card ------------------- --}}

     <div class="row">

      @foreach ($user as $item)
      <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2">
   <a href="profile/{{ $item->id }}">
      <figure class="snip1336">
         <img style="height: 150px " src="../storage/upload/{{ $item->img_backround }}" alt="sample87" />
         <figcaption>
           <img src="../storage/upload/{{ $item->img_avatar }}" alt="profile-sample4" class="profile" />
           <h2>{{ $item->name }}<span>{{ $item->country }} - {{ $item->city }} </span></h2>
         </figcaption>
        
       </figure>
      </a>
      </div>
   
      @endforeach
        </div>
   
        <br>
        <br><br>
   
   
   {{-- -------------------users card ----------------------- --}}
   @endif





{{-- ------------------------------------ --}}
@if (count($Comedy) > 0)
<div class="row">
 <section id="row1">
   <h1 class="sectionTitlear">كوميديا</h1>
   <ul class="img-list">
     @foreach ($Comedy as $item)
     <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2">
        <li class="image"> 
           <a href="post/{{ $item->id }}">
           <img id="box1" src="../storage/upload/{{ $item->image }}" width="185" height="130" />
           <span class="text-content"><span>{{ $item->title }}</span></span>
            </a>
        </li>
     </div>
     @endforeach
      

   </ul>
   </section>

   </div><!-- row-->
   <div class="row" style="float: left">
      <br>
    <a href="more/{{ $item->category }}">لمشاهدة المزيد </a>
   
   </div>
   <br>
   <br><br>
   @endif
{{-- ------------------------------------ --}}
{{-- ------------------------------------ --}}
@if (count($Adventure) > 0)
<div class="row">
 <section id="row1">
   <h1 class="sectionTitlear">مغامرة</h1>
   <ul class="img-list">
     @foreach ($Adventure as $item)
     <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2">
        <li class="image"> 
           <a href="post/{{ $item->id }}">
           <img id="box1" src="../storage/upload/{{ $item->image }}" width="185" height="130" />
           <span class="text-content"><span>{{ $item->title }}</span></span>
            </a>
        </li>
     </div>
     @endforeach
      

   </ul>
   </section>

   </div><!-- row-->
   <div class="row" style="float: left">
      <br>
    <a href="more/{{ $item->category }}">لمشاهدة المزيد </a>
   
   </div>
   <br>
   <br><br>
   @endif
{{-- ------------------------------------ --}}
{{-- ------------------------------------ --}}
@if (count($Crime) > 0)
<div class="row">
 <section id="row1">
   <h1 class="sectionTitlear">جريمة</h1>
   <ul class="img-list">
     @foreach ($Crime as $item)
     <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2">
        <li class="image"> 
           <a href="post/{{ $item->id }}">
           <img id="box1" src="../storage/upload/{{ $item->image }}" width="185" height="130" />
           <span class="text-content"><span>{{ $item->title }}</span></span>
            </a>
        </li>
     </div>
     @endforeach
      

   </ul>
   </section>

   </div><!-- row-->
   <div class="row" style="float: left">
      <br>
    <a href="more/{{ $item->category }}">لمشاهدة المزيد </a>
   
   </div>
   <br>
   <br><br>
   @endif
{{-- ------------------------------------ --}}


{{-- ------------------------------------ --}}
@if (count($Historical) > 0)
<div class="row">
 <section id="row1">
   <h1 class="sectionTitlear">تاريخي</h1>
   <ul class="img-list">
     @foreach ($Historical as $item)
     <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2">
        <li class="image"> 
           <a href="post/{{ $item->id }}">
           <img id="box1" src="../storage/upload/{{ $item->image }}" width="185" height="130" />
           <span class="text-content"><span>{{ $item->title }}</span></span>
            </a>
        </li>
     </div>
     @endforeach
      

   </ul>
   </section>

   </div><!-- row-->
   <div class="row" style="float: left">
      <br>
    <a href="more/{{ $item->category }}">لمشاهدة المزيد </a>
   
   </div>
   <br>
   <br><br>
 
{{-- ------------------------------------ --}}




     {{-- --------------users card ------------------- --}}

     <div class="row">

      @foreach ($user as $item)
      <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2">
   <a href="profile/{{ $item->id }}">
      <figure class="snip1336">
         <img style="height: 150px " src="../storage/upload/{{ $item->img_backround }}" alt="sample87" />
         <figcaption>
           <img src="../storage/upload/{{ $item->img_avatar }}" alt="profile-sample4" class="profile" />
           <h2>{{ $item->name }}<span>{{ $item->country }} - {{ $item->city }} </span></h2>
         </figcaption>
        
       </figure>
      </a>
      </div>
   
      @endforeach
        </div>
   
        <br>
        <br><br>
   
   
   {{-- -------------------users card ----------------------- --}}
   @endif




{{-- ------------------------------------ --}}
@if (count($Spy_Film) > 0)
<div class="row">
 <section id="row1">
   <h1 class="sectionTitlear">أفلام التجسس</h1>
   <ul class="img-list">
     @foreach ($Spy_Film as $item)
     <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2">
        <li class="image"> 
           <a href="post/{{ $item->id }}">
           <img id="box1" src="../storage/upload/{{ $item->image }}" width="185" height="130" />
           <span class="text-content"><span>{{ $item->title }}</span></span>
            </a>
        </li>
     </div>
     @endforeach
      

   </ul>
   </section>

   </div><!-- row-->
   <div class="row" style="float: left">
      <br>
    <a href="more/{{ $item->category }}">لمشاهدة المزيد </a>
   
   </div>
   <br>
   <br><br>
   @endif
{{-- ------------------------------------ --}}



{{-- ------------------------------------ --}}
@if (count($Kurdish) > 0)
<div class="row">
 <section id="row1">
   <h1 class="sectionTitlear">الكورديه</h1>
   <ul class="img-list">
     @foreach ($Kurdish as $item)
     <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2">
        <li class="image"> 
           <a href="post/{{ $item->id }}">
           <img id="box1" src="../storage/upload/{{ $item->image }}" width="185" height="130" />
           <span class="text-content"><span>{{ $item->title }}</span></span>
            </a>
        </li>
     </div>
     @endforeach
      

   </ul>
   </section>

   </div><!-- row-->
   <div class="row" style="float: left">
      <br>
    <a href="more/{{ $item->category }}">لمشاهدة المزيد </a>
   
   </div>
   <br>
   <br><br>
   @endif
{{-- ------------------------------------ --}}


@if (count($Watching) > 0)

    <div class="row">
      <section id="row1">
        <h1 class="sectionTitlear">التي تم مشاهداتها مؤخراً</h1>
        <ul class="img-list">
     
          @foreach ($Watching as $item)
          <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2">
             <li class="image"> 
                <a href="post/{{ $item->postid }}">
                <img id="box1" src="../storage/upload/{{ $item->image }}" width="185" height="130" />
                <span class="text-content"><span>{{ $item->title }}</span></span>
                 </a>
             </li>
          </div>
          @endforeach


        </ul>
        </section>
    
        </div><!-- row-->
        <div class="row" style="float: left">
         <br>
         <a href="watched/">لمشاهدة المزيد</a>
        
        </div>
        <br><br>
        <br>
        @endif
 {{-- botton up --}}
 <div class="text-left">
   <br>
   <button class="btn btn-outline-left" onclick="topFunction()" id="myBtn" title="Go to top"> <i class="fas fa-chevron-up"></i></button>
 </div>
</div> <!-- container -->

{{-- ajax video data --}}
@endsection