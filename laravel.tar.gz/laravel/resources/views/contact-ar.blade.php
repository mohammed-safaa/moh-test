@extends('layouts.app2')

@section('content')
<div class="flex-center position-ref full-height">
  <div class="content">
      <div class="title m-b-md" style="color: #c0c6c9; font-size: 70px; margin-top: -30px;">
          <img src="../storage/upload/{{ $contact->logo }}" width="80" height="80"  style="  margin-left: -10px; margin-top: -30px;">
          {{ $contact->title }}
      </div>
      <p style="font-size: 14px; width:900px;" class="text-center">{{ $contact->about }}</p>
      <p class="text">Address : {{ $contact->address }} &nbsp;|&nbsp; Phone : {{ $contact->phone }} &nbsp;| &nbsp;Email : {{ $contact->email }}</p>
     <a target="_blank" rel="noopener noreferrer"href="{{ $contact->facebook }}/">Facebook : {{ $contact->facebook }}</a>   &nbsp;|&nbsp; <a target="_blank" rel="noopener noreferrer"href="{{ $contact->youtube }}/">Youtube : {{ $contact->youtube }}</a> &nbsp;| &nbsp; <a target="_blank" rel="noopener noreferrer"href="{{ $contact->twitter }}/">Twitter : {{ $contact->twitter }}</a> 
     <p class="text"> <a target="_blank" rel="noopener noreferrer" href="{{ $contact->web }}/">Website : {{ $contact->web }}</a>  
     </p>
    
      <div class="links">
          <a href="/home">go to  {{ $contact->title }}</a>
      </div>
<br>
    <a target="_blank" rel="noopener noreferrer" href="{{ $contact->app_ios }}/">  <img src="../storage/upload/app.svg"  width="150" height="60"> </a>  <a target="_blank" rel="noopener noreferrer"  href="{{ $contact->app_android }}/"><img src="../storage/upload/google.svg" alt="" width="150" height="60"></a>
  </div>
</div>

@endsection
