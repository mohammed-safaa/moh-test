@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">

<div class="col-md-8 col-md-offset-2">
  @if (Auth::user()->id === $postid->user_id)
  <div class="panel panel-default">
    <div class="panel-heading">Edit Published</div>

    <div class="panel-body">
            <form class="form-horizontal" method="POST" action="{{ htmlspecialchars(route('post.update',$postid->id)) }}" enctype="multipart/form-data">
              {{ method_field('PUT') }}
              {{ csrf_field() }} 
                <div class="form-group">
                  <label for="name" class="col-md-4 control-label">Titel : </label>
                  <div class="col-md-6">
                  <input type="text" class="form-control" id="text" value="{{ $postid->title }}" placeholder="Enter Title" name="title" required autofocus>
                </div>
              </div>
              <div class="form-group">
                <label for="name" class="col-md-4 control-label">About : </label>
                <div class="col-md-6">
                    <textarea class="form-control" rows="5" value="{{ $postid->post }}" id="comment" name="post" required autofocus>{{ $postid->post }}</textarea>
                  </div>
                </div>

                <div class="form-group">
                  <label for="name" class="col-md-4 radio-inline"></label>
                  <div class="col-md-6">
                    <?php 
                    $var = $postid->movies_tvseries;
                    $mov = "Movies";
                        if (strcmp($mov, $var) == 0) {
                      echo'<input  type="radio" name="movies&tvseries" value="Movies" checked> MOVIES'; 
                      echo '<input  type="radio" name="movies&tvseries" value="Tv Series"> TV SERIES';
                      }else{
                      echo'<input  type="radio" name="movies&tvseries" value="Movies" > MOVIES'; 
                      echo '<input  type="radio" name="movies&tvseries" value="Tv Series" checked> TV SERIES';
                      }
                      ?>

                    </div>
                  </div>
                <div class="form-group">
                  <label for="sel1" class="col-md-4 control-label">Genres : </label>
                  <div class="col-md-6">
                    <select type="text" class="form-control" value="{{ $postid->category }}"  name="category" id="sel1" required autofocus>
                      <option>{{ $postid->category }}</option>
                    <option>Popular</option>
                    <option>Netflix</option>
                    <option>Action</option>
                    <option>Animation</option>
                    <option>Adventure</option>
                    <option>Comedy</option>
                    <option>Crime</option>
                    <option>Drama</option>
                    <option>Fantasy</option>
                    <option>Historical</option>
                    <option>Horror</option>
                    <option>Mystery</option>
                    <option>Romance</option>
                    <option>Sci-Fi</option>
                    <option>Social</option>
                    <option>Spy Film</option>
                    <option>Western</option>
                    <option>War</option>
                    <option>Family</option>
                    <option>Documentary</option>
                    <option>Arabic</option>
                    <option>Indian</option>
                    <option>Turkish</option>
                    <option>Kurdish</option>
                  </select>
                </div> 
              </div> 

              <div class="form-group">
                <label for="sel1" class="col-md-4 control-label">Year : </label>
                <div class="col-md-6">
                  <select type="text" class="form-control" value="{{ $postid->year }}" name="year" id="sel1" required autofocus>
                    <option>{{ $postid->year }}</option>
                  <?php 
                     $datay = date("Y");
                     if (isset($datay)) {
                      $x = 1950;
                        while($x <= $datay) {
                          echo "<option>$x</option>";
                          $x++;
                        } 
                      }else {
                        $x = 1950 ;
                        $s = $x + 100;
                        while($x <= $s) {
                          echo "<option>$x</option>";
                          $x++;
                        } 
                      }
               

                  ?> 

                </select>
              </div> 
            </div> 

                  <div class="form-group">
                    <label for="name" class="col-md-4 control-label">IMDb : </label>
                    <div class="col-md-6">
                    <input type="text" class="form-control" id="text"  placeholder="Enter IMDb" value="{{ $postid->imdb }}"  name="imdb" required autofocus>
                  </div>
                </div>
                  <div class="form-group">
                    <label for="name" class="col-md-4 control-label">Trailer : </label>
                    <div class="col-md-6">
                    <input type="text" class="form-control" id="text" value="{{ $postid->trailer }}" placeholder="<iframe>youtube</iframe>" name="trailer" required autofocus>
                  </div>
                </div>
     



  
                  <div class="form-group">
                    <div class="col-md-8 col-md-offset-4">
                        <button type="submit" class="btn btn-defult">
                            Update
                        </button>
                    </div>
                </div>
              </form>
            </div>
          </div>
        </div>
  @elseif (Auth::user()->id === 1 )
<div class="panel panel-default">
    <div class="panel-heading">Edit Published</div>

    <div class="panel-body">
            <form class="form-horizontal" method="POST" action="{{ htmlspecialchars(route('post.update',$postid->id)) }}" enctype="multipart/form-data">
              {{ method_field('PUT') }}
              {{ csrf_field() }} 
                <div class="form-group">
                  <label for="name" class="col-md-4 control-label">Titel : </label>
                  <div class="col-md-6">
                  <input type="text" class="form-control" id="text" value="{{ $postid->title }}" placeholder="Enter Title" name="title" required autofocus>
                </div>
              </div>
              <div class="form-group">
                <label for="name" class="col-md-4 control-label">About : </label>
                <div class="col-md-6">
                    <textarea class="form-control" rows="5" value="{{ $postid->post }}" id="comment" name="post" required autofocus>{{ $postid->post }}</textarea>
                  </div>
                </div>

                <div class="form-group">
                  <label for="name" class="col-md-4 radio-inline"></label>
                  <div class="col-md-6">
                    <?php 
                    $var = $postid->movies_tvseries;
                    $mov = "Movies";
                        if (strcmp($mov, $var) == 0) {
                      echo'<input  type="radio" name="movies&tvseries" value="Movies" checked> MOVIES'; 
                      echo '<input  type="radio" name="movies&tvseries" value="Tv Series"> TV SERIES';
                      }else{
                      echo'<input  type="radio" name="movies&tvseries" value="Movies" > MOVIES'; 
                      echo '<input  type="radio" name="movies&tvseries" value="Tv Series" checked> TV SERIES';
                      }
                      ?>

                    </div>
                  </div>
                <div class="form-group">
                  <label for="sel1" class="col-md-4 control-label">Genres : </label>
                  <div class="col-md-6">
                    <select type="text" class="form-control" value="{{ $postid->category }}"  name="category" id="sel1" required autofocus>
                      <option>{{ $postid->category }}</option>
                    <option>Popular</option>
                    <option>Netflix</option>
                    <option>Action</option>
                    <option>Animation</option>
                    <option>Adventure</option>
                    <option>Comedy</option>
                    <option>Crime</option>
                    <option>Drama</option>
                    <option>Fantasy</option>
                    <option>Historical</option>
                    <option>Horror</option>
                    <option>Mystery</option>
                    <option>Romance</option>
                    <option>Sci-Fi</option>
                    <option>Social</option>
                    <option>Spy Film</option>
                    <option>Western</option>
                    <option>War</option>
                    <option value="Family">Children's/Family</option>
                    <option>Documentary</option>
                    <option>Arabic</option>
                    <option>Indian</option>
                    <option>Turkish</option>
                    <option>Kurdish</option>
                  </select>
                </div> 
              </div> 

              <div class="form-group">
                <label for="sel1" class="col-md-4 control-label">Year : </label>
                <div class="col-md-6">
                  <select type="text" class="form-control" value="{{ $postid->year }}" name="year" id="sel1" required autofocus>
                    <option>{{ $postid->year }}</option>
                  <?php 
                     $datay = date("Y");
                     if (isset($datay)) {
                      $x = 1950;
                        while($x <= $datay) {
                          echo "<option>$x</option>";
                          $x++;
                        } 
                      }else {
                        $x = 1950 ;
                        $s = $x + 100;
                        while($x <= $s) {
                          echo "<option>$x</option>";
                          $x++;
                        } 
                      }
               

                  ?> 

                </select>
              </div> 
            </div> 

                  <div class="form-group">
                    <label for="name" class="col-md-4 control-label">IMDb : </label>
                    <div class="col-md-6">
                    <input type="text" class="form-control" id="text"  placeholder="Enter IMDb" value="{{ $postid->imdb }}"  name="imdb" required autofocus>
                  </div>
                </div>
                  <div class="form-group">
                    <label for="name" class="col-md-4 control-label">Trailer : </label>
                    <div class="col-md-6">
                    <input type="text" class="form-control" id="text" value="{{ $postid->trailer }}" placeholder="<iframe>youtube</iframe>" name="trailer" required autofocus>
                  </div>
                </div>
     



  
                  <div class="form-group">
                    <div class="col-md-8 col-md-offset-4">
                        <button type="submit" class="btn btn-defult">
                            Update
                        </button>
                    </div>
                </div>
              </form>
            </div>
          </div>
        </div>
        @else
        <div class="content">
          <div class="title m-b-md" style="color: #c0c6c9; font-size: 50px;">
            <br>
            Error 404 Not Found 
          </div>


      </div>
      @endif
</div>

</div>{{-- row --}}
</div>{{-- container --}}

@endsection

