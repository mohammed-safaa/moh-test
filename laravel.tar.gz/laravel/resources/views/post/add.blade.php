@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">

<div class="col-md-8 col-md-offset-2">
<div class="panel panel-default">
    <div class="panel-heading">Add Published</div>

    <div class="panel-body">
            <form class="form-horizontal" method="POST" action="{{ route('post.store') }}" enctype="multipart/form-data">
                {{ csrf_field() }}
                <div class="form-group">
                  <label for="name" class="col-md-4 control-label">Titel : </label>
                  <div class="col-md-6">
                  <input type="text" class="form-control" id="text" placeholder="Enter Title" name="title" required autofocus>
                </div>
              </div>
              <div class="form-group">
                <label for="name" class="col-md-4 control-label">About : </label>
                <div class="col-md-6">
                    <textarea class="form-control" rows="3" id="comment" name="post" required autofocus></textarea>
                  </div>
                </div>

                <div class="form-group">
                  <label for="name" class="col-md-4 control-label"></label>
                  <div class="col-md-6">
                    <input  type="radio" name="movies&tvseries" value="Movies" checked> MOVIES
                    <input  type="radio" name="movies&tvseries" value="Tv Series"> TV SERIES
                    </div>
                  </div>
                <div class="form-group">
                  <label for="sel1" class="col-md-4 control-label">Genres : </label>
                  <div class="col-md-6">
                  <select type="text" class="form-control" name="category" id="sel1" required autofocus>
                    <option>Popular</option>
                    <option>Netflix</option>
                    <option>Action</option>
                    <option>Animation</option>
                    <option>Adventure</option>
                    <option>Comedy</option>
                    <option>Crime</option>
                    <option>Drama</option>
                    <option>Fantasy</option>
                    <option>Historical</option>
                    <option>Horror</option>
                    <option>Mystery</option>
                    <option>Romance</option>
                    <option>Sci-Fi</option>
                    <option>Social</option>
                    <option>Spy Film</option>
                    <option>Western</option>
                    <option>War</option>
                    <option value="Family">Children's/Family</option>
                    <option>Documentary</option>
                    <option>Arabic</option>
                    <option>Indian</option>
                    <option>Turkish</option>
                    <option>Kurdish</option>
                  </select>
                </div> 
              </div> 

              <div class="form-group">
                <label for="sel1" class="col-md-4 control-label">Year : </label>
                <div class="col-md-6">
                <select type="text" class="form-control" name="year" id="sel1" required autofocus>
                  <?php 
                     $datay = date("Y");
                     if (isset($datay)) {
                      $x = 1950;
                        while($x <= $datay) {
                          echo "<option>$x</option>";
                          $x++;
                        } 
                      }else {
                        $x = 1950 ;
                        $s = $x + 100;
                        while($x <= $s) {
                          echo "<option>$x</option>";
                          $x++;
                        } 
                      }
               

                  ?> 

                </select>
              </div> 
            </div> 

                  <div class="form-group">
                    <label for="name" class="col-md-4 control-label">IMDb : </label>
                    <div class="col-md-6">
                    <input type="text" class="form-control" id="text"  placeholder="Enter IMDb" name="imdb" required autofocus>
                  </div>
                </div>
                  <div class="form-group">
                    <label for="name" class="col-md-4 control-label">Trailer : </label>
                    <div class="col-md-6">
                    <input type="text" class="form-control" id="text"  placeholder="<iframe>youtube</iframe>" name="trailer" required autofocus>
                  </div>
                </div>
     

                <div class="form-group">
                    <label  class="col-md-4 control-label">Image File : </label>
  
                    <div class="col-md-6">
                        <input type="file"  name="image"  required>
                    </div>
                </div>
                <div class="form-group">
                    <label  class="col-md-4 control-label">Video Files :</label>
  
                    <div class="col-md-6">
                        <input type="file"  name="video[]" multiple>
                    </div>
                </div>
  
                  <div class="form-group">
                    <div class="col-md-8 col-md-offset-4">
                        <button type="submit" class="btn btn-defult">
                          Add Published
                        </button>
                    </div>
                </div>
              </form>
            </div>
          </div>
        </div>
</div>

</div>{{-- row --}}
</div>{{-- container --}}

@endsection
