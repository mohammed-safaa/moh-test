@extends('layouts.app2')

@section('content')
<div class="container">
    <div class="row">

<div class="col-md-8 col-md-offset-2">
<div class="panel panel-default">
    <div class="panel-heading">أضافة منشور</div>

    <div class="panel-body">
            <form class="form-horizontal" method="POST" action="{{ route('post.store') }}" enctype="multipart/form-data">
                {{ csrf_field() }}
                <div class="form-group">
                  <label for="name" class="col-md-4 control-label">اسم الفلم : </label>
                  <div class="col-md-6">
                  <input type="text" class="form-control" id="text" placeholder="يرجى اضافة اسم للفلم" name="title" required autofocus>
                </div>
              </div>
              <div class="form-group">
                <label for="name" class="col-md-4 control-label">قصة الفلم : </label>
                <div class="col-md-6">
                    <textarea class="form-control" rows="3" id="comment" name="post" placeholder="يرجى اضافة قصة الفلم" required autofocus></textarea>
                  </div>
                </div>

                <div class="form-group">
                  <label for="name" class="col-md-4 control-label"></label>
                  <div class="col-md-6">
                    <input  type="radio" name="movies&tvseries" value="Movies" checked> فلم
                    <input  type="radio" name="movies&tvseries" value="Tv Series"> مسلسل تلفزيوني
                    </div>
                  </div>
                <div class="form-group">
                  <label for="sel1" class="col-md-4 control-label">التصنيف الفني للفلم :</label>
                  <div class="col-md-6">
                  <select type="text" class="form-control" name="category" id="sel1" required autofocus>
                    <option value="Popular">اﻷكثر شعبية</option>
                    <option value="Netflix">نتفليكس</option>
                    <option value="Action">أكشن</option>
                    <option value="Animation"> الانيميشن / اﻷطفال</option>
                    <option value="Adventure">مغامرة</option>
                    <option value="Comedy">كوميديا</option>
                    <option value="Crime">جريمة</option>
                    <option value="Drama">دراما</option>
                    <option value="Fantasy">خيالي</option>
                    <option value="Historical">تاريخي</option>
                    <option value="Horror">رعب</option>
                    <option value="Mystery">الغموض</option>
                    <option value="Romance">رومانسي</option>
                    <option value="Sci-Fi">خيال علمي</option>
                    <option value="Social">الاجتماعية</option>
                    <option value="Spy Film">أفلام التجسس</option>
                    <option value="Western">الغربي</option>
                    <option value="War">حرب</option>
                    <option value="Family">عائلي/أطفال</option>
                    <option value="Documentary">وثائقية</option>
                    <option value="Arabic">عربية</option>
                    <option value="Indian">هندية</option>
                    <option value="Turkish">تركية</option>
                    <option value="Kurdish">كورديه</option>
                  </select>
                </div> 
              </div> 

              <div class="form-group">
                <label for="sel1" class="col-md-4 control-label">السنة :  </label>
                <div class="col-md-6">
                <select type="text" class="form-control" name="year" id="sel1" required autofocus>
                  <?php 
                     $datay = date("Y");
                     if (isset($datay)) {
                      $x = 1950;
                        while($x <= $datay) {
                          echo "<option>$x</option>";
                          $x++;
                        } 
                      }else {
                        $x = 1950 ;
                        $s = $x + 100;
                        while($x <= $s) {
                          echo "<option>$x</option>";
                          $x++;
                        } 
                      }
               

                  ?> 

                </select>
              </div> 
            </div> 

                  <div class="form-group">
                    <label for="name" class="col-md-4 control-label">IMDb : </label>
                    <div class="col-md-6">
                    <input type="text" class="form-control" id="text"  placeholder="Enter IMDb" name="imdb" required autofocus>
                  </div>
                </div>
                  <div class="form-group">
                    <label for="name" class="col-md-4 control-label">أعلان الفلم :</label>
                    <div class="col-md-6">
                    <input type="text" class="form-control" id="text"  placeholder="<iframe>youtube</iframe>" name="trailer" required autofocus>
                  </div>
                </div>
     

                <div class="form-group">
                    <label  class="col-md-4 control-label">أضافة صوره : </label>
  
                    <div class="col-md-6">
                        <input type="file"  name="image"  required>
                    </div>
                </div>
                <div class="form-group">
                    <label  class="col-md-4 control-label">اضافة فديو او مجموعة فديوات :</label>
  
                    <div class="col-md-6">
                        <input type="file"  name="video[]" multiple>
                    </div>
                </div>
  
                  <div class="form-group">
                    <div class="col-md-8 col-md-offset-4">
                        <button type="submit" class="btn btn-defult">
                          أضافة المنشور
                        </button>
                    </div>
                </div>
              </form>
            </div>
          </div>
        </div>
</div>

</div>{{-- row --}}
</div>{{-- container --}}

@endsection
