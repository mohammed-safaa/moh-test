@extends('layouts.app')

@section('content')
<div class="container">

 <div class="row">
   <section id="row1">
      <h1 class="sectionTitle">Watching</h1>
         <ul class="img-list">
               

          @if (count($allpost) > 0)
         
          @foreach ($allpost as $allpost_item)

   <div class="col-xs-12 col-sm-4 col-md-2 col-lg-2 col-xl-2">
   <li class="image"> 
   <a href="post/{{ $allpost_item->id }}">
   <img id="box1" src="../storage/upload/{{ $allpost_item->image }}" width="185" height="130" />
   <span class="text-content"><span>{{ $allpost_item->title }}.</span></span>
</a>

   
   </li>


   @endforeach
                   <!--START NO Post في حالة لا توجد منشورات  -->
                   @else
                   <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">


                    <div class="alert alert-dark">
                      <strong>Error !</strong> No Database‎ .
                    </div>

                    </div> 
                    <!--END NO Post -->
   
                   @endif


</ul>
 </section>





</div><!-- row-->

{{-- <ul class="pagination pagination-sm">
  <li></li>
</ul> --}}


<br><br>


<div class="row">
   <section id="row1">
      <h1 class="sectionTitle">Trending</h1>
         <ul class="img-list">
          <section id="row1">


          </section>
</ul>

</div><!-- row-->


<br><br>


<div class="row">
   <section id="row1">
      <h1 class="sectionTitle">Popular on Media Pro</h1>
         <ul class="img-list">
               
   <div class="col-xs-12 col-sm-4 col-md-2 col-lg-2">
   <li class="image"> 
   <a href="#">
   <img id="box1" src="../storage/test/lasa.jpg" width="185" height="130" />
   <span class="text-content"><span>Title Here...</span></span>
   </a>
   </li>
   </div>

   <div class="col-xs-12 col-sm-4 col-md-2 col-lg-2">
      <li class="image"> 
      <a href="#">
      <img id="box1" src="../storage/test/lasa.jpg" width="185" height="130" />
      <span class="text-content"><span>Title Here...</span></span>
      </a>
      </li>
      </div>
   
      <div class="col-xs-12 col-sm-4 col-md-2 col-lg-2">
         <li class="image"> 
         <a href="#">
         <img id="box1" src="../storage/test/lasa.jpg" width="185" height="130" />
         <span class="text-content"><span>Title Here...</span></span>
         </a>
         </li>
         </div>
      
                     
   <div class="col-xs-12 col-sm-4 col-md-2 col-lg-2">
      <li class="image"> 
      <a href="#">
      <img id="box1" src="../storage/test/lasa.jpg" width="185" height="130" />
      <span class="text-content"><span>Title Here...</span></span>
      </a>
      </li>
      </div>
   
      <div class="col-xs-12 col-sm-4 col-md-2 col-lg-2">
         <li class="image"> 
         <a href="#">
         <img id="box1" src="https://github.com/carlosavilae/Netflix-Clone/blob/master/img/p6.PNG?raw=trueg" width="185" height="130" />
         <span class="text-content"><span>Title Here...</span></span>
         </a>
         </li>
         </div>
      
         <div class="col-xs-12 col-sm-4 col-md-2 col-lg-2">
            <li class="image"> 
            <a href="#">
            <img id="box1" src="../storage/test/lasa.jpg" width="185" height="130" />
            <span class="text-content"><span>Title Here...</span></span>
            </a>
            </li>
            </div>
         
            <div class="col-xs-12 col-sm-4 col-md-2 col-lg-2">
               <li class="image"> 
               <a href="#">
               <img id="box1" src="../storage/test/lasa.jpg" width="185" height="130" />
               <span class="text-content"><span>Title Here...</span></span>
               </a>
               </li>
               </div>
            
               <div class="col-xs-12 col-sm-4 col-md-2 col-lg-2">
                  <li class="image"> 
                  <a href="#">
                  <img id="box1" src="../storage/test/lasa.jpg" width="185" height="130" />
                  <span class="text-content"><span>Title Here...</span></span>
                  </a>
                  </li>
                  </div>   
                  <div class="col-xs-12 col-sm-4 col-md-2 col-lg-2">
                     <li class="image"> 
                     <a href="#">
                     <img id="box1" src="https://github.com/carlosavilae/Netflix-Clone/blob/master/img/p6.PNG?raw=true" width="185" height="130" />
                     <span class="text-content"><span>Title Here...</span></span>
                     </a>
                     </li>
                     </div>
                  
                     <div class="col-xs-12 col-sm-4 col-md-2 col-lg-2">
                        <li class="image"> 
                        <a href="#">
                        <img id="box1" src="../storage/test/lasa.jpg" width="185" height="130" />
                        <span class="text-content"><span>Title Here...</span></span>
                        </a>
                        </li>
                        </div>
                     
                        <div class="col-xs-12 col-sm-4 col-md-2 col-lg-2">
                           <li class="image"> 
                           <a href="#">
                           <img id="box1" src="https://github.com/carlosavilae/Netflix-Clone/blob/master/img/p6.PNG?raw=true" width="185" height="130" />
                           <span class="text-content"><span>Title Here...</span></span>
                           </a>
                           </li>
                           </div>
                        
                           <div class="col-xs-12 col-sm-4 col-md-2 col-lg-2">
                              <li class="image"> 
                              <a href="#">
                              <img id="box1" src="../storage/test/lasa.jpg" width="185" height="130" />
                              <span class="text-content"><span>Title Here...</span></span>
                              </a>
                              </li>
                              </div>         
</ul>
 </section>
</div><!-- row-->



<br><br>


<div class="row">
   <section id="row1">
      <h1 class="sectionTitle">Movies</h1>
         <ul class="img-list">
               
   <div class="col-xs-12 col-sm-4 col-md-2 col-lg-2">
   <li class="image"> 
   <a href="#">
   <img id="box1" src="../storage/test/lasa.jpg" width="185" height="130" />
   <span class="text-content"><span>Title Here...</span></span>
   </a>
   </li>
   </div>

   <div class="col-xs-12 col-sm-4 col-md-2 col-lg-2">
      <li class="image"> 
      <a href="#">
      <img id="box1" src="../storage/test/lasa.jpg" width="185" height="130" />
      <span class="text-content"><span>Title Here...</span></span>
      </a>
      </li>
      </div>
   
      <div class="col-xs-12 col-sm-4 col-md-2 col-lg-2">
         <li class="image"> 
         <a href="#">
         <img id="box1" src="../storage/test/lasa.jpg" width="185" height="130" />
         <span class="text-content"><span>Title Here...</span></span>
         </a>
         </li>
         </div>
      
                     
   <div class="col-xs-12 col-sm-4 col-md-2 col-lg-2">
      <li class="image"> 
      <a href="#">
      <img id="box1" src="../storage/test/lasa.jpg" width="185" height="130" />
      <span class="text-content"><span>Title Here...</span></span>
      </a>
      </li>
      </div>
   
      <div class="col-xs-12 col-sm-4 col-md-2 col-lg-2">
         <li class="image"> 
         <a href="#">
         <img id="box1" src="https://github.com/carlosavilae/Netflix-Clone/blob/master/img/p6.PNG?raw=trueg" width="185" height="130" />
         <span class="text-content"><span>Title Here...</span></span>
         </a>
         </li>
         </div>
      
         <div class="col-xs-12 col-sm-4 col-md-2 col-lg-2">
            <li class="image"> 
            <a href="#">
            <img id="box1" src="../storage/test/lasa.jpg" width="185" height="130" />
            <span class="text-content"><span>Title Here...</span></span>
            </a>
            </li>
            </div>
         
            <div class="col-xs-12 col-sm-4 col-md-2 col-lg-2">
               <li class="image"> 
               <a href="#">
               <img id="box1" src="../storage/test/lasa.jpg" width="185" height="130" />
               <span class="text-content"><span>Title Here...</span></span>
               </a>
               </li>
               </div>
            
               <div class="col-xs-12 col-sm-4 col-md-2 col-lg-2">
                  <li class="image"> 
                  <a href="#">
                  <img id="box1" src="../storage/test/lasa.jpg" width="185" height="130" />
                  <span class="text-content"><span>Title Here...</span></span>
                  </a>
                  </li>
                  </div>   
                  <div class="col-xs-12 col-sm-4 col-md-2 col-lg-2">
                     <li class="image"> 
                     <a href="#">
                     <img id="box1" src="https://github.com/carlosavilae/Netflix-Clone/blob/master/img/p6.PNG?raw=true" width="185" height="130" />
                     <span class="text-content"><span>Title Here...</span></span>
                     </a>
                     </li>
                     </div>
                  
                     <div class="col-xs-12 col-sm-4 col-md-2 col-lg-2">
                        <li class="image"> 
                        <a href="#">
                        <img id="box1" src="../storage/test/lasa.jpg" width="185" height="130" />
                        <span class="text-content"><span>Title Here...</span></span>
                        </a>
                        </li>
                        </div>
                     
                        <div class="col-xs-12 col-sm-4 col-md-2 col-lg-2">
                           <li class="image"> 
                           <a href="#">
                           <img id="box1" src="https://github.com/carlosavilae/Netflix-Clone/blob/master/img/p6.PNG?raw=true" width="185" height="130" />
                           <span class="text-content"><span>Title Here...</span></span>
                           </a>
                           </li>
                           </div>
                        
                           <div class="col-xs-12 col-sm-4 col-md-2 col-lg-2">
                              <li class="image"> 
                              <a href="#">
                              <img id="box1" src="../storage/test/lasa.jpg" width="185" height="130" />
                              <span class="text-content"><span>Title Here...</span></span>
                              </a>
                              </li>
                              </div>         
</ul>
 </section>
</div><!-- row-->



<br><br>


<div class="row">
   <section id="row1">
      <h1 class="sectionTitle">TV Shows</h1>
         <ul class="img-list">
               
   <div class="col-xs-12 col-sm-4 col-md-2 col-lg-2">
   <li class="image"> 
   <a href="#">
   <img id="box1" src="../storage/test/lasa.jpg" width="185" height="130" />
   <span class="text-content"><span>Title Here...</span></span>
   </a>
   </li>
   </div>

   <div class="col-xs-12 col-sm-4 col-md-2 col-lg-2">
      <li class="image"> 
      <a href="#">
      <img id="box1" src="../storage/test/lasa.jpg" width="185" height="130" />
      <span class="text-content"><span>Title Here...</span></span>
      </a>
      </li>
      </div>
   
      <div class="col-xs-12 col-sm-4 col-md-2 col-lg-2">
         <li class="image"> 
         <a href="#">
         <img id="box1" src="../storage/test/lasa.jpg" width="185" height="130" />
         <span class="text-content"><span>Title Here...</span></span>
         </a>
         </li>
         </div>
      
                     
   <div class="col-xs-12 col-sm-4 col-md-2 col-lg-2">
      <li class="image"> 
      <a href="#">
      <img id="box1" src="../storage/test/lasa.jpg" width="185" height="130" />
      <span class="text-content"><span>Title Here...</span></span>
      </a>
      </li>
      </div>
   
      <div class="col-xs-12 col-sm-4 col-md-2 col-lg-2">
         <li class="image"> 
         <a href="#">
         <img id="box1" src="https://github.com/carlosavilae/Netflix-Clone/blob/master/img/p6.PNG?raw=trueg" width="185" height="130" />
         <span class="text-content"><span>Title Here...</span></span>
         </a>
         </li>
         </div>
      
         <div class="col-xs-12 col-sm-4 col-md-2 col-lg-2">
            <li class="image"> 
            <a href="#">
            <img id="box1" src="../storage/test/lasa.jpg" width="185" height="130" />
            <span class="text-content"><span>Title Here...</span></span>
            </a>
            </li>
            </div>
         
            <div class="col-xs-12 col-sm-4 col-md-2 col-lg-2">
               <li class="image"> 
               <a href="#">
               <img id="box1" src="../storage/test/lasa.jpg" width="185" height="130" />
               <span class="text-content"><span>Title Here...</span></span>
               </a>
               </li>
               </div>
            
               <div class="col-xs-12 col-sm-4 col-md-2 col-lg-2">
                  <li class="image"> 
                  <a href="#">
                  <img id="box1" src="../storage/test/lasa.jpg" width="185" height="130" />
                  <span class="text-content"><span>Title Here...</span></span>
                  </a>
                  </li>
                  </div>   
                  <div class="col-xs-12 col-sm-4 col-md-2 col-lg-2">
                     <li class="image"> 
                     <a href="#">
                     <img id="box1" src="https://github.com/carlosavilae/Netflix-Clone/blob/master/img/p6.PNG?raw=true" width="185" height="130" />
                     <span class="text-content"><span>Title Here...</span></span>
                     </a>
                     </li>
                     </div>
                  
                     <div class="col-xs-12 col-sm-4 col-md-2 col-lg-2">
                        <li class="image"> 
                        <a href="#">
                        <img id="box1" src="../storage/test/lasa.jpg" width="185" height="130" />
                        <span class="text-content"><span>Title Here...</span></span>
                        </a>
                        </li>
                        </div>
                     
                        <div class="col-xs-12 col-sm-4 col-md-2 col-lg-2">
                           <li class="image"> 
                           <a href="#">
                           <img id="box1" src="https://github.com/carlosavilae/Netflix-Clone/blob/master/img/p6.PNG?raw=true" width="185" height="130" />
                           <span class="text-content"><span>Title Here...</span></span>
                           </a>
                           </li>
                           </div>
                        
                           <div class="col-xs-12 col-sm-4 col-md-2 col-lg-2">
                              <li class="image"> 
                              <a href="#">
                              <img id="box1" src="../storage/test/lasa.jpg" width="185" height="130" />
                              <span class="text-content"><span>Title Here...</span></span>
                              </a>
                              </li>
                              </div>         
</ul>
 </section>
</div><!-- row-->




<br><br>


<div class="row">
   <section id="row1">
      <h1 class="sectionTitle">Recommended for you</h1>
         <ul class="img-list">
               
   <div class="col-xs-12 col-sm-4 col-md-2 col-lg-2">
   <li class="image"> 
   <a href="home">
   <img id="box1" src="../storage/test/lasa.jpg" width="185" height="130" />
   <span class="text-content"><span>Title Here...</span></span>
   </a>
   </li>
   </div>

   <div class="col-xs-12 col-sm-4 col-md-2 col-lg-2">
      <li class="image"> 
      <a href="#">
      <img id="box1" src="../storage/test/lasa.jpg" width="185" height="130" />
      <span class="text-content"><span>Title Here...</span></span>
      </a>
      </li>
      </div>
   
      <div class="col-xs-12 col-sm-4 col-md-2 col-lg-2">
         <li class="image"> 
         <a href="#">
         <img id="box1" src="../storage/test/lasa.jpg" width="185" height="130" />
         <span class="text-content"><span>Title Here...</span></span>
         </a>
         </li>
         </div>
      
                     
   <div class="col-xs-12 col-sm-4 col-md-2 col-lg-2">
      <li class="image"> 
      <a href="#">
      <img id="box1" src="../storage/test/lasa.jpg" width="185" height="130" />
      <span class="text-content"><span>Title Here...</span></span>
      </a>
      </li>
      </div>
   
      <div class="col-xs-12 col-sm-4 col-md-2 col-lg-2">
         <li class="image"> 
         <a href="#">
         <img id="box1" src="https://github.com/carlosavilae/Netflix-Clone/blob/master/img/p6.PNG?raw=trueg" width="185" height="130" />
         <span class="text-content"><span>Title Here...</span></span>
         </a>
         </li>
         </div>
      
         <div class="col-xs-12 col-sm-4 col-md-2 col-lg-2">
            <li class="image"> 
            <a href="#">
            <img id="box1" src="../storage/test/lasa.jpg" width="185" height="130" />
            <span class="text-content"><span>Title Here...</span></span>
            </a>
            </li>
            </div>
         
            <div class="col-xs-12 col-sm-4 col-md-2 col-lg-2">
               <li class="image"> 
               <a href="#">
               <img id="box1" src="../storage/test/lasa.jpg" width="185" height="130" />
               <span class="text-content"><span>Title Here...</span></span>
               </a>
               </li>
               </div>
            
               <div class="col-xs-12 col-sm-4 col-md-2 col-lg-2">
                  <li class="image"> 
                  <a href="#">
                  <img id="box1" src="../storage/test/lasa.jpg" width="185" height="130" />
                  <span class="text-content"><span>Title Here...</span></span>
                  </a>
                  </li>
                  </div>   
                  <div class="col-xs-12 col-sm-4 col-md-2 col-lg-2">
                     <li class="image"> 
                     <a href="#">
                     <img id="box1" src="https://github.com/carlosavilae/Netflix-Clone/blob/master/img/p6.PNG?raw=true" width="185" height="130" />
                     <span class="text-content"><span>Title Here...</span></span>
                     </a>
                     </li>
                     </div>
                  
                     <div class="col-xs-12 col-sm-4 col-md-2 col-lg-2">
                        <li class="image"> 
                        <a href="#">
                        <img id="box1" src="../storage/test/lasa.jpg" width="185" height="130" />
                        <span class="text-content"><span>Title Here...</span></span>
                        </a>
                        </li>
                        </div>
                     
                        <div class="col-xs-12 col-sm-4 col-md-2 col-lg-2">
                           <li class="image"> 
                           <a href="#">
                           <img id="box1" src="https://github.com/carlosavilae/Netflix-Clone/blob/master/img/p6.PNG?raw=true" width="185" height="130" />
                           <span class="text-content"><span>Title Here...</span></span>
                           </a>
                           </li>
                           </div>
                        
                           <div class="col-xs-12 col-sm-4 col-md-2 col-lg-2">
                              <li class="image"> 
                              <a href="#">
                              <img id="box1" src="../storage/test/lasa.jpg" width="185" height="130" />
                              <span class="text-content"><span>Title Here...</span></span>
                              </a>
                              </li>
                              </div>         
</ul>
 </section>



</div><!-- row-->
</div> <!-- container -->
 {{-- botton up --}}
 <div class="text-right">
  
   <button class="btn btn-outline-light" onclick="topFunction()" id="myBtn" title="Go to top"> <i class="fas fa-chevron-up"></i></button>
   
   </div>
   <script>
   //Get the button
   var mybutton = document.getElementById("myBtn");
   
   // When the user scrolls down 20px from the top of the document, show the button
   window.onscroll = function() {scrollFunction()};
   
   function scrollFunction() {
     if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
       mybutton.style.display = "block";
     } else {
       mybutton.style.display = "none";
     }
   }
   
   // When the user clicks on the button, scroll to the top of the document
   function topFunction() {
     document.body.scrollTop = 0;
     document.documentElement.scrollTop = 0;
   }
   </script>

@endsection



