@extends('layouts.app')

@section('content')

<div class="container">
    @if(isset($query))
        <p> The Search results for your query <b> {{ $query }} </b> are :</p>
    <h2>Sample User details</h2>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>title</th>
                <th>post</th>
            </tr>
        </thead>
        <tbody>
no post
        </tbody>
    </table>
    @endif
</div>






@endsection

