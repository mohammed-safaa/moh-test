@extends('layouts.app')

@section('content')

<div class="container">

        <div class="row">
            <section id="row1">
              <h1 class="sectionTitle">The Search Results For Your Query  <b> {{ $query }} </b> Are : </h1>
              <ul class="img-list">
                @if (count($details) > 0)
                @foreach($details as $item)
                <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2" >
                   <li class="image"> 
                      <a href="post/{{ $item->id }}">
                      <img id="box1" src="../storage/upload/{{ $item->image }}" width="185" height="130" />
                      <span class="text-content"><span>{{ $item->title }}</span></span>
                       </a>
                   </li>
                </div>
         
                @endforeach
           
          <!--START NO Post في حالة لا توجد منشورات  -->
               @else
                <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2">
                      <div class="alert alert-dark">
                         <strong>Error ! </strong> No Database‎ .
                      </div>
               </div> 
               <!--END NO Post -->
                   
         @endif
              </ul>
             
              </section>
            




</div>





</div>
@endsection



