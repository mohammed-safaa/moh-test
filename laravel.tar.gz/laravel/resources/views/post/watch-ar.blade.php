        @extends('layouts.app2')

        @section('content')
        <div class="container">
        {{-- -------------------------------------------------}}
  

        <div class="row">{{-- row 1 --}}
          <br>
          <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 col-xl-6"> {{-- col-xs-12 col-sm-6 col-md-6 col-lg-6 col-xl-6 --}}
          
            <div class="panel panel-default"> {{-- panel panel-default --}}
              
              <div class="panel-body" >
                
                <img  src="../storage/upload/{{ $post->image }}" width="100%" height="430" />
              </div>
            
            </div> {{-- panel panel-default --}}

          </div> {{-- col-xs-12 col-sm-6 col-md-6 col-lg-6 col-xl-6 --}}

          {{-- -------------------------------------------------}}





          {{-- -------------------------------------------------}}


          <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 col-xl-6">{{-- col-xs-12 col-sm-6 col-md-6 col-lg-6 col-xl-6 --}}
            
            <div class="panel panel-default"> {{-- panel panel-default --}}
              <div class="panel-heading">
                {{ $post->title }} | {{ $post->year }} 
                @if (Auth::user()->id === $post->user_id)
                <div style="float: left;" class="dropdown">
                  <span data-toggle="dropdown" class="glyphicon glyphicon-option-vertical"></span>
                  <ul class="dropdown-menu">
                <div class="btn-group-vertical">
                  <a href="{{ route('post.edit',$post->id) }}" style="width: 100%; font-size: 12px; border: 1px solid rgba(47, 46, 46, 0.15);  border-radius: 0px;" class="btn default" role="button">تعديل</a>
                              <!-- start delete Post حذف المنشور -->
                              <form action="{{ route('post.destroy',$post->id) }}" method="POST">
                                {{ csrf_field() }}
                  
                                {{method_field('DELETE')}}
                          
                            <button style="width: 100%; font-size: 12px; border: 1px solid rgba(47, 46, 46, 0.15);  border-radius: 0px;" type="submit" class="btn default">حذف</button>
                            </form>
                  <!-- end delete Post حذف المنشور -->
                </div>

              </ul>
            </div>
            @elseif (Auth::user()->id === 1 )
            <div style="float: left;" class="dropdown">
              <span data-toggle="dropdown" class="glyphicon glyphicon-option-vertical"></span>
              <ul class="dropdown-menu">
            <div class="btn-group-vertical">
              <a href="{{ route('post.edit',$post->id) }}" style="width: 100%; font-size: 12px; border: 1px solid rgba(47, 46, 46, 0.15);  border-radius: 0px;" class="btn default" role="button">تعديل</a>
                          <!-- start delete Post حذف المنشور -->
                          <form action="{{ route('post.destroy',$post->id) }}" method="POST">
                            {{ csrf_field() }}
              
                            {{method_field('DELETE')}}
                      
                        <button style="width: 100%; font-size: 12px; border: 1px solid rgba(47, 46, 46, 0.15);  border-radius: 0px;" type="submit" class="btn default">حذف</button>
                        </form>
              <!-- end delete Post حذف المنشور -->
            </div>

          </ul>
        </div>
        @endif
              </div>
              <div class="panel-body">
                <p class="text-right">
                  @php
                     $tvm = $post->movies_tvseries;

                     switch ($tvm) {
                      case "Movies":
                        echo "فلم";
                        break;
                      case "Tv Series":
                        echo "مسلسل تلفزيوني";
                        break;
 
                      default:
                        
                    }
                  @endphp
                  
                  
                  | 
                  @php
                   $category = $post->category;
                    switch ($category) {

                    case "Popular":
                      echo "اﻷكثر شعبية";
                      break;
                    case "Netflix":
                      echo "نتفليكس";
                      break;
                    case "Action":
                      echo "أكشن";
                      break;

                      case "Animation":
                      echo "الانيميشن / اﻷطفال";
                      break;

                      case "Adventure":
                      echo "مغامرة";
                      break;

                      case "Comedy":
                      echo "كوميديا";
                      break;

                      case "Crime":
                      echo "جريمة";
                      break;

                      case "Drama":
                      echo "دراما";
                      break;

                      case "Fantasy":
                      echo "خيالي";
                      break;

                      case "Historical":
                      echo "تاريخي";
                      break;

                      case "Horror":
                      echo "رعب";
                      break;

                      case "Mystery":
                      echo "الغموض";
                      break;

                      case "Romance":
                      echo "رومانسي";
                      break;

                      case "Sci-Fi":
                      echo "خيال علمي";
                      break;

                      case "Social":
                      echo "الاجتماعية";
                      break;

                      case "Spy Film":
                      echo "أفلام التجسس";
                      break;

                      case "Western":
                      echo "الغربي";
                      break;

                      case "War":
                      echo "حرب";
                      break;

                      case "Family":
                      echo "عائلي/أطفال";
                      break;

                      case "Documentary":
                      echo "وثائقية";
                      break;

                      case "Arabic":
                      echo "عربية";
                      break;

                      case "Indian":
                      echo "هندية";
                      break;

                      case "Turkish":
                      echo "تركية";
                      break;

                      case "Kurdish":
                      echo "كورديه";
                      break;

                    default:
                      
                  }
                @endphp | {{ $post->imdb }}/10 IMDb</p>
                
                <p class="text-capitalize" style="padding: 12px; height: 244px;">{{ $post->post }}.</p>

                
                <p class="text-right">
                  <!-- Button Trailers trigger modal -->
          <button type="button" class="btn btn-default" data-toggle="modal"  data-target="#exampleModal">
            مشاهدة اعلان الفيلم 
          </button>
          </p>
          <!-- Trailers Modal -->
          <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            
            <div class="modal-dialog" role="document">
              <div class="col-xs-8 col-xs-offset-2 col-sm-8 col-sm-offset-2 col-md-8 col-md-offset-2 col-lg-8 col-lg-offset-2 col-xl-8 col-xl-offset-2">
               <?php 
               echo $post->trailer ;
               ?>
                {{-- {{ $post->trailer }} --}}
            </div>
            </div>
          </div>

          {{-- -------- Trailers -------- --}}
        </div>
              <div class="panel-footer">
                <a href="{{ url('profile') }}/{{ $post->user->id}}">
                  <!-- Comment Avatar -->
                  <div style="border: 0px solid #fff;
                  border-radius: 50%;
                  overflow: hidden;
                  position: absolute; 
                  height: 30px;
                  width: 30px;
                  font-size: 9px;
                left: 42px;
                  ">
                    <img style="display: block;
                    height: 100%;
                    width: 100%;"  src="../storage/upload/{{ $post->user->img_avatar }}" >
                  </div>
                  <p style="font-size: 13px; margin-left: 53px;" class="text-left">
                    {{ $post->user->name }} </a> 
                  </p>
                  <p style="font-size: 11px; margin-right: 5px;" class="text-right">
                
                    &nbsp; &nbsp;  {{ $post->created_at->format('D d , F, m.Y H:i:s A') }} | 
                  @php
                $datat =$post->created_at;
                $date1=date_create($datat);
                $date2=date_create(date("Y-m-d"));
                $diff=date_diff($date1,$date2);
                $ago = $diff->format("%a");
            
                if ($ago == 0) {
                  echo "اليوم";
                } elseif ($ago == 1){
                  echo "منذ يوم واحد";
                } elseif ($ago == 2) {
                  echo "منذ يومين";
                } elseif ($ago == 3){
                  echo "منذ ثلاثة أيام";
                } elseif ($ago == 4){
                  echo "منذ اربعة أيام";
                } elseif ($ago == 5){
                  echo "منذ خمسة أيام";
                } elseif ($ago == 6){
                  echo "منذ ستة ايام";
                }elseif ($ago < 6){
                  echo "منذ اسبوع واحد";
                } elseif ($ago < 13){
                echo "منذ أسبوعين";
                } elseif ($ago < 20){
                  echo "منذ ثلاثة أسابيع";
                } elseif ($ago < 30){
                  echo "منذ شهر واحد";
                } elseif ($ago < 60){
                  echo "منذ شهرين";
                } elseif ($ago < 90){
                  echo "منذ ثلاثة أشهر";
                } elseif ($ago < 120){
                  echo "منذ أربعة أشهر";
                } elseif ($ago < 150){
                  echo "منذ خمسة أشهر";
                } elseif ($ago < 180){
                  echo "منذ ستة أشهر";
                } elseif ($ago < 365){
                  echo "منذ سنة واحدة";
                } elseif ($ago < 720){
                  echo "منذ سنتين";
                } elseif ($ago < 1095){
                  echo "منذ ثلاثة سنين";
                } else {
                  echo $ago;
                }
                @endphp
            
                </p>
              </div>
            </div> {{-- panel panel-default --}}

          </div>{{-- col-xs-12 col-sm-6 col-md-6 col-lg-6 col-xl-6 --}}


        {{-- -------------------------------------------------}}


        {{-- -------------------------------------------------}}



        </div>{{-- row 1 --}}
        <div class="row">{{-- row 2 --}}
          <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 col-xl-6">{{-- col-xs-12 col-sm-6 col-md-6 col-lg-6 col-xl-6 --}}
          
            <div class="panel panel-default"> {{-- panel panel-default --}}
              <div class="panel-heading">

  
        <p class="text-right" style='font-size:12px; color: #7c8081;'>

          @php       
          $views1 = $post->viewpost->count();
          $price = number_format($views1);
          $price = (int)str_replace(",","",$price);
          $thousands = $price % 1000000;
          $millions = ($price - $thousands)/1000000;
          $thousands = $thousands / 1000;
          
          if($millions == 0 && $thousands >= 1 ){
            echo $thousands =  $thousands." K";
          }elseif ( $millions > 0 && $thousands > 0){
            echo $millions = $millions." M ";
            echo $thousands = $thousands." K ";
          }elseif ( $millions > 0 && $thousands < 0){
            echo $millions = $millions." M "; 
          }elseif( $views1 == 0){
            echo "0";
          }else{
            echo $price;
          }
          echo "<i class='glyphicon glyphicon-eye-open' style='font-weight: 500; color: #7c8081; margin-bottom: 13px; font-size:14px; margin-right: 10px; margin-left: 10px;'> </i>";

          @endphp
          
          @php       
          $views1 = $post->comments->count();
          $price = number_format($views1);
          $price = (int)str_replace(",","",$price);
          $thousands = $price % 1000000;
          $millions = ($price - $thousands)/1000000;
          $thousands = $thousands / 1000;
          
          if($millions == 0 && $thousands >= 1 ){
            echo $thousands =  $thousands." K";
          }elseif ( $millions > 0 && $thousands > 0){
            echo $millions = $millions." M ";
            echo $thousands = $thousands." K ";
          }elseif ( $millions > 0 && $thousands < 0){
            echo $millions = $millions." M "; 
          }elseif( $views1 == 0){
            echo "0";
          }else{
            echo $price;
          }
          echo "<i class='glyphicon glyphicon-comment' style='font-weight: 500; color: #7c8081; margin-bottom: 13px; font-size:14px; margin-right: 7px; margin-left: 20px;'> </i>";

          @endphp




        @php
        $like_count=0;
        $dislike_count=0;
        $like_status = "glyphicon glyphicon-heart";
        $dislike_status = "glyphicon glyphicon-flag";
        $likeColor = "color : #7c8081";
        $dlikeColor = "color : #7c8081";

        @endphp

        @foreach($post->likes as $like)

        @php

        if($like->like == 1){
        $like_count++;
        }

        if($like->like == 0){
        $dislike_count++;
        }

        if($like->like == 1 && $like->user_id == Auth::user()->id){
          $like_status = "glyphicon glyphicon-heart";
       $likeColor = "color : #fff";
        }else{
        $likeColor = "color : #7c8081";
      }

        if($like->like == 0 && $like->user_id == Auth::user()->id){
          $dislike_status = "glyphicon glyphicon-flag";
        $dlikeColor = "color : #fff";

        }else {
          $dlikeColor = "color : #7c8081";
        }

        @endphp

        @endforeach


        <i id="like" data-postid="{{ $post->id }}_l" data-like="{{ $like_status }}"  class="{{ $like_status }}" style='font-size:16px; {{ $likeColor }}'><span style='margin-left: 3px; margin-right: 3px; ' class="like_count"></span></i>
          
        @php       
        $views1 = $like_count;
        $price = number_format($views1);
        $price = (int)str_replace(",","",$price);
        $thousands = $price % 1000000;
        $millions = ($price - $thousands)/1000000;
        $thousands = $thousands / 1000;

        if($millions == 0 && $thousands >= 1 ){
          echo $thousands =  $thousands." K";
        }elseif ( $millions > 0 && $thousands > 0){
          echo $millions = $millions." M ";
          echo $thousands = $thousands." K ";
        }elseif ( $millions > 0 && $thousands < 0){
          echo $millions = $millions." M "; 
        }elseif( $views1 == 0){
          echo "0";
        }else{
          echo $price;
        }

        @endphp

<i id="dislike" data-postid="{{ $post->id }}_d" data-like="{{ $like_status }}"  class='{{ $dislike_status }}' style='font-size:16px; margin-left: 5px; margin-right: 3px;{{ $dlikeColor }}'><span style='margin-bottom: 15px; margin-left: 3px;' class="dislike_count"></span></i>
      
        @php       
        $views1 = $dislike_count;
        $price = number_format($views1);
        $price = (int)str_replace(",","",$price);
        $thousands = $price % 1000000;
        $millions = ($price - $thousands)/1000000;
        $thousands = $thousands / 1000;

        if($millions == 0 && $thousands >= 1 ){
          echo $thousands =  $thousands." K";
        }elseif ( $millions > 0 && $thousands > 0){
          echo $millions = $millions." M ";
          echo $thousands = $thousands." K ";
        }elseif ( $millions > 0 && $thousands < 0){
          echo $millions = $millions." M "; 
        }elseif( $views1 == 0){
          echo "0";
        }else{
          echo $price;
        }

        @endphp


        </p>

        </div>
              <div class="panel-body">
        <div style="float: right">

          <div class="avatars">



            

            @foreach($post->comments->slice(0, 4) as  $comments_itme )
         
              <!-- Comment Avatar -->

              <a href="{{ url('profile') }}/{{ $comments_itme->user->id }}" >
              
              <span class="avatar">
                <img  src="../storage/upload/{{ $comments_itme->user->img_avatar }}" >
              </a>  

        <!-- Variable amount more avatars -->
            @endforeach
            @foreach($post->comments as $comments_itme)
            
              <!-- Comment Avatar -->
              @if($loop->last)
              <a href="{{ url('profile') }}/{{ $comments_itme->user->id}}" >
              
                <span class="avatar">
                  <img  src="../storage/upload/{{ $comments_itme->user->img_avatar }}">
                </a>  
              @endif


        <!-- Variable amount more avatars -->
            @endforeach

          </span>
          </div>

        </div>
                <br><br>
                <!-- From -->
                <div  class="comment-form">
                  <!-- Comment Avatar -->
                  <div style="border: 1px solid rgba(165, 169, 172, 0.835);
                  border-radius: 50%;
                  box-shadow: rgba(255, 253, 253, 0.2) 0px 1px 2px;
                  left: 0;
                  overflow: hidden;
                  position: absolute;
                  margin-left: 34px;
                  top: 110;
                  height: 60px;
                  width: 60px;

                  ">
                    <img style="display: block;
                    height: 100%;
                    width: 100%;"  src="../storage/upload/{{ Auth::user()->img_avatar }}" >
                  </div>
                
                  <form  style="margin-left: 85px;" class="form">
                    
                    {{ csrf_field() }}
                    <div class="form-row">
                      <textarea id="inpcomme" style="background-color: #fcfcfc;
                      border: none;
                      border-radius: 4px;
                      box-shadow: 0 1px 1px rgba(0, 0, 0, .15);
                      color: #0a0a0a;
                      font-family: inherit;
                      font-size: 14px;
                      padding: 5px 10px;
                      outline: none;
                      width: 100%;
                      font-weight: 600;
                      -webkit-transition: 350ms box-shadow;
                      -moz-transition: 350ms box-shadow;
                      -ms-transition: 350ms box-shadow;
                      -o-transition: 350ms box-shadow;
                      transition: 350ms box-shadow;"
                      class="input"
                      ng-model="cmntCtrl.comment.text"
                      placeholder="{{ Auth::user()->name }}  يرجى أضافة تعليق"
                      name="comment"
                      required></textarea>
                      <input id="postid" type="hidden" name="post_id" value="{{ $post->id }}">
                    </div>
                    <br> 
                    <div class="form-row" style="float: right;">
                      <a id="commsubm" class="btn btn-default" style="padding: 5px 10px;
                      font-size: 12px;
                      line-height: 1.5;
                      border-radius: 3px;" >اضافة تعليق</a>
                     
                    </div>

                    
                  </form>

                </div>
                
              </div>
              <div class="panel-footer">
                  
                <div class="table-wrapper-scroll-y-comm my-custom-scrollbar-comm">{{-- table-wrapper-scroll-y-comm my-custom-scrollbar-comm --}}

                  <div class="comment" style=" position: absolute;  padding: 18px; z-index: 0;"> <!-- Comment - start -->
                  @if (count($post->comments) > 0)
                    @foreach($post->comments as $itme)
                    <ul class="list-group" >
                      <li class="list-group-item1">
                        <a href="{{ url('profile') }}/{{ $itme->user->id }}">
                      <!-- Comment Avatar -->
                      <div class="comment-avatar" style="border: 1px solid #a5a9acd5;
                      border-radius: 50%;
                      box-shadow: 0 1px 2px rgba(255, 253, 253, 0.2);
                    
                      overflow: hidden;
                      top: 0;
                      height: 60px;
                      float: right;
                      width: 60px;">
                        <img style="

                        height: 100%;
                        width: 100%;" src="../storage/upload/{{ $itme->user->img_avatar }}">
                      
                      </div> <!-- Comment Avatar -->
                                
                        
                      </li>
                
                    </ul> 

                              

                              <!-- Comment Box  بداية الكارت-->
                              <div class="comment-box" style="background-color: #fcfcfc;

                              border-radius: 8px;
                              box-shadow: 0 1px 1px rgba(255, 253, 253, 0.2);
                              margin-right: 70px;
                              min-height: 30px;
                              padding: 10px;
                              width: 390px;
                              text-align: right;
                              ">
                              {{-- username --}}
                              <div class="comment-text" style="color: #1a1b1b; text-align: right;
                              font-size: 15px; font-weight: 700; text-transform: capitalize;">{{ $itme->user->name }}
                              </div>{{--end username --}}
                              {{-- ago time  --}}
                              <small style="color: #747777; font-weight: 500; ">
                                @php
                                $datat =$itme->created_at;
                                $date1=date_create($datat);
                                $date2=date_create(date("Y-m-d"));
                                $diff=date_diff($date1,$date2);
                                $ago = $diff->format("%a");
                    
                                if ($ago == 0) {
                                  echo "اليوم";
                                } elseif ($ago == 1){
                                  echo "منذ يوم واحد";
                                } elseif ($ago == 2) {
                                  echo "منذ يومين";
                                } elseif ($ago == 3){
                                  echo "منذ ثلاثة أيام";
                                } elseif ($ago == 4){
                                  echo "منذ أربعة أيام";
                                } elseif ($ago == 5){
                                  echo "منذ خمسة أيام";
                                } elseif ($ago == 6){
                                  echo "منذ ستة أيام";
                                }elseif ($ago < 6){
                                  echo "منذ أسبوع";
                                } elseif ($ago < 13){
                                echo "منذ أسبوعين";
                                } elseif ($ago < 20){
                                  echo "منذ ثلاثة أسابيع";
                                } elseif ($ago < 30){
                                  echo "منذ شهر واحد";
                                } elseif ($ago < 60){
                                  echo "منذ شهرين";
                                } elseif ($ago < 90){
                                  echo "منذ ثلاثة أشهر";
                                } elseif ($ago < 120){
                                  echo "منذ اربعة أشهر ";
                                } elseif ($ago < 150){
                                  echo "منذ خمسة أشهر";
                                } elseif ($ago < 180){
                                  echo "منذ ستة اشهر";
                                } elseif ($ago < 365){
                                  echo "منذ سنة واحده";
                                } elseif ($ago < 720){
                                  echo "منذ سنتين";
                                } elseif ($ago < 1095){
                                  echo "منذ ثلاثة سنوات";
                                } else {
                                  echo $ago;
                                }
                                @endphp
                              
                              </small>   
                              {{-- ago end --}}
                            </a>
                      {{-- comment text  --}}
                      <div class="some-list">
                        <!-- 1 -->
                        <div class="some-item">
            
                            <div class="item-message">
              <div class="my-message" style="color: #1a1b1b; font-size: 13px; margin-bottom: 25px; font-weight: 300;">{{ $itme->comment }} .</div>
                      {{-- comment text end --}}

                            </div>
                        </div>
                      </div>
                      {{-- comment-footer --}}
                      <div class="comment-footer" style="color: #1a1b1b; font-size: 10px;">

                      


                      {{-- comment-info --}}
                      <div class="comment-info" style="float: right; width: 85%;">
                      <span class="comment-author" style="float: right; text-align: right; width: 15%;"></span>
                      <span class="comment-date" style="color: #1a1b1b; font-weight: 400;"> {{ $itme->created_at->format('D d , F, m.Y H:i:s A') }}</span>
                      </div>{{-- comment-info END --}}

                  
                      {{-- comment-actions --}}
                      <div class="comment-actions">
                        {{-- form --}}
                        @if (Auth::user()->id === $itme->user_id)
                        
                        <!-- start delete Post حذف المنشور -->
                        <form action="{{ route('comm.destroy',$itme->id) }}" method="POST">
                        {{ csrf_field() }}

                        {{method_field('DELETE')}}
                        <button type="submit" class="light" style="font-weight: 300; border: #fcfcfc; background-color: #fcfcfc;">حذف</button>
                        </form>
                        <!-- end delete Post حذف المنشور -->
                        @endif
                      <br>
                      </div>{{-- comment-actions end --}}

                    </div> {{-- comment-footer END --}}
                  
                    </div>
                    <!-- Comment Box end نهاية الكارت-->   
              
                        <br>

                    @endforeach
                    @else
                    <ul class="list-group" >
                      <li class="list-group-item1">

                                
                        
                      </li>
                
                    </ul> 

                              
        
                                <!-- Comment Box  بداية الكارت-->
                                <div class="comment-box" style="background-color: #fcfcfc;
                                  
                                border-radius: 8px;
                                box-shadow: 0 1px 1px rgba(255, 253, 253, 0.2);
                                margin-left: 70px;
                                min-height: 30px;
                                padding: 10px;
                                width: 390px;
                                ">
                {{-- username --}}
                <div class="comment-text" style="color: #1a1b1b; 
                font-size: 15px; font-weight: 700; text-transform: capitalize;">أهلاً {{ Auth::user()->name }} 
                </div>{{--end username --}}
              {{-- ago time  --}}

                      {{-- comment text  --}}
                      <div class="some-list">
                        <!-- 1 -->
                        <div class="some-item">
            
                            <div class="item-message">
              <div class="my-message" style="color: #1a1b1b; font-size: 13px; margin-bottom: 25px; font-weight: 300;">عذراً لا توجد اي تعليقات</div>
                      {{-- comment text end --}}

                            </div>
                        </div>
                      </div>
                      {{-- comment-footer --}}
                      <div class="comment-footer" style="color: #1a1b1b; font-size: 10px;">

                      


                      {{-- comment-info --}}
                      <div class="comment-info" style="float: left; width: 85%;">
                      <span class="comment-author" style="float: left; text-align: right; width: 15%;"></span>
                     
                      </div>{{-- comment-info END --}}

                  
                      {{-- comment-actions --}}
                      <div class="comment-actions">

                      </div>{{-- comment-actions end --}}

                    </div> {{-- comment-footer END --}}
                  
                    </div>
                    <!-- Comment Box end نهاية الكارت-->   
              
                        <br>
                    @endif

                  </div><!-- Comment - start -->
                </div>{{-- table-wrapper-scroll-y-comm my-custom-scrollbar-comm --}}
          
              </div>
            </div> {{-- panel panel-default --}}

          </div>{{-- col-xs-12 col-sm-6 col-md-6 col-lg-6 col-xl-6 --}}


          {{-- -------------------------------------------------}}










          {{-- -------------------------------------------------}}


          <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 col-xl-6">{{-- col-xs-12 col-sm-6 col-md-6 col-lg-6 col-xl-6 --}}
          
            <div class="panel panel-default"> {{-- panel panel-default --}}
              <div class="panel-heading" style='font-size:13px'> 
               <i class='glyphicon glyphicon-align-right' > </i>  قائمة التشغيل
               
              </div>
              <div class="panel-body">
                
                <div class="table-wrapper-scroll-y my-custom-scrollbar">
                  <ul class="list-group">
                    <?php $i = 1; ?>
                    <?php foreach ( json_decode( $post->video ) as $vidlist ) { ?>
                    {{-- list item start --}}
                      <li class="list-group-item">
                      <?php 
                        switch ($i) {
                          case "1":
                            echo "01 . ";
                            break;
                          case "2":
                            echo "02 . ";
                            break;
                          case "3":
                            echo "03 . ";
                            break;
                            case "4":
                            echo "04 . ";
                            break;
                          case "5":
                            echo "05 . ";
                            break;
                          case "6":
                            echo "06 . ";
                            break;
                            case "7":
                            echo "07 . ";
                            break;
                          case "8":
                            echo "08 . ";
                            break;
                          case "9":
                            echo "09 . ";
                            break;
                          default:
                            echo  $i . ' . ';
                        }; ?>
                        {{ $post->title }}
                      
                        <div style="margin-top: -22px;" class="text-left">
                
                                <!-- Button  Watch Now trigger modal -->
                                <a href="../storage/upload/{{ $vidlist->video }}" download>
                                <div class="btn-group btn-group-sm">
                                  <button type="button" class="btn btn-default">تنزيل </button>
                                </div>
                              </a>
                                <div class="btn-group btn-group-sm">
                                  <button type="button" class="btn btn-default" data-toggle="modal"  data-target="#play<?php echo $i; ?>">تشغيل</button>
                                </div>
                                <!--  Watch Now Modal -->
                                <div class="modal fade" id="play<?php echo $i; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                  <div class="modal-dialog" role="document">
                
                
                                    <video
                                    id="my-video"
                                    class="video-js"
                                    controls
                                    preload="auto"
                                    width="580"
                                    height="315"
                                    poster="../storage/upload/{{ $post->image }}"
                                    data-setup="{controls: true,}"
                                  >
                                    <source src="../storage/upload/{{ $vidlist->video }}" type="video/mp4" /></video>
                                  </div>
                                </div>
                                {{-- --------  Watch Now -------- --}}
                               
                        </div>
                      </li>
                      {{-- list item end --}}
                      <?php $i++; } ?>
                   
                  </ul>
        

            </div>


              </div>
              <div class="panel-footer">
                <div class="avatars">
            
                  @foreach($post->likes->slice(0, 7) as $like)
  
              <a href="{{ url('profile') }}/{{ $like->user->id}}">
                <!-- Comment Avatar -->
                <span class="avatar">
                      <img   src="../storage/upload/{{ $like->user->img_avatar }}">
                  </span>
                <!-- Variable amount more avatars -->
              </a>  
  
                  @endforeach
                </div> 
              </div>{{-- panel-footer --}}
              <div class="panel-footer">
                  @foreach ( $ads as $ads_item )
                           <!--- \\\\\\\Post مشورات -->
                         <span style="background-color: #f00c0c;float: right; font-weight: 400;border-radius: 0px;" class="label label-default" >أعلان</span>
                        <a class="card-link" href="ads/{{ $ads_item->id }}"> 
                       
                        <img  src="../storage/upload/{{ $ads_item->ads_image }}" width="525" height="200" />
                        <br>
                       <p class="text-left">{{ $ads_item->ads_title }} </p>
                        </a>
                       <p class="text-left" style="font-size: 10px">{{ $ads_item->ads_about }}</p>
                        <!-- Post /////-->

                @endforeach
          
              </div>{{-- panel-footer --}}
            </div> {{-- panel panel-default --}}

          </div>{{-- col-xs-12 col-sm-6 col-md-6 col-lg-6 col-xl-6 --}}


          {{-- -------------------------------------------------}}





          {{-- -------------------------------------------------}}




          <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">{{-- col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 --}}
         

               {{-- --------------------------------- --}}
     @if (count($recommendations) > 0)
     <div class="row">
       <section id="row1">
         <h1 class="sectionTitlear">اﻷفلام والمسلسلات موصى به لك</h1>
         <ul class="img-list">
           @foreach ($recommendations as $item)


           <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2">
              <li class="image"> 
              
                 <a href="/post/{{ $item->id }}">
                  
                 <img id="box1" src="../storage/upload/{{ $item->image }}" width="185" height="130" />
                 <span class="text-content"><span>{{ $item->title }}</span></span>
                  </a>
              </li>
           </div>
           @endforeach

           
         </ul>
         </section>
     
         </div><!-- row-->
          <br>
         <br><br>
         @endif
     {{-- ------------------------------------------ --}}

  

            </div> {{-- tab-content --}}
            </div>{{-- row --}}
            </div> <!-- container -->
            
            
            
          </div>{{-- col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 --}}
        </div>{{-- row 2 --}}











        {{-- ----------------------------------------------- --}}
        </div> <!-- container -->

        <script src="{{ asset('js/like.js') }}"></script>

        <script type="text/javascript">
          var url = "{{ route('like') }}";
          var url_dis = "{{ route('dislike') }}";
          var token = "{{ Session::token() }}";
          </script>
        
          <script type="text/javascript"></script>



        @endsection


