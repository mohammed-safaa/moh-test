@extends('layouts.app')

@section('content')
<div class="container">
<br>

 <div class="row">

  <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 col-xl-6"> {{-- col-xs-12 col-sm-6 col-md-6 col-lg-6 col-xl-6 --}}
          
    <div class="panel panel-default" style="width: 560px; height: 315px; padding: 1px;"> {{-- panel panel-default --}}
      
      
        
        <?php echo  $ads->ads_trailer ; ?>

    
    </div> {{-- panel panel-default --}}

  </div> {{-- col-xs-12 col-sm-6 col-md-6 col-lg-6 col-xl-6 --}}


  {{-- --------------------------------------------- --}}



   <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
    <div class="panel panel-default"> {{-- panel panel-default --}}
        <div class="panel-heading"> <h1 class="text-capitalize">{{ $ads->ads_title }}</h1> </div>
        <div class="panel-body" style="padding-bottom: 90px;"><p style="font-size: 12px" class="text-left">{{ $ads->ads_about }}</p></div>
        <div class="panel-footer">
          <p class="text-center">      
        
            {{ $ads->created_at->format('D d , F , m . Y H:i:s  A') }}  &nbsp;  |    &nbsp;   @php
            $datat =$ads->created_at;
            $date1=date_create($datat);
            $date2=date_create(date("Y-m-d"));
            $diff=date_diff($date1,$date2);
            $ago = $diff->format("%a");
            
            if ($ago == 0) {
              echo "today ago";
            } elseif ($ago == 1){
              echo "1 day ago";
            } elseif ($ago == 2) {
              echo "2 day ago";
            } elseif ($ago == 3){
              echo "3 day ago";
            } elseif ($ago == 4){
              echo "4 day ago";
            } elseif ($ago == 5){
              echo "5 day ago";
            } elseif ($ago == 6){
              echo "6 day ago";
            }elseif ($ago < 6){
              echo "1 week ago";
            } elseif ($ago < 13){
            echo "2 week ago";
            } elseif ($ago < 20){
              echo "3 week ago";
            } elseif ($ago < 30){
              echo "1 month ago";
            } elseif ($ago < 60){
              echo "2 months ago";
            } elseif ($ago < 90){
              echo "3 months ago";
            } elseif ($ago < 120){
              echo "4 months ago";
            } elseif ($ago < 150){
              echo "5 months ago";
            } elseif ($ago < 180){
              echo "6 months ago";
            } elseif ($ago < 365){
              echo "1 years ago";
            } elseif ($ago < 720){
              echo "2 years ago";
            } elseif ($ago < 1095){
              echo "3 years ago";
            } else {
              echo $ago;
            }
            @endphp
            </p>
        </div>
      </div>{{-- panel panel-default --}}

</div>{{-- col-xs-12 col-sm-6 col-md-6 col-lg-6 col-xl-6 --}}
</div>
</div> <!-- container -->

@endsection

