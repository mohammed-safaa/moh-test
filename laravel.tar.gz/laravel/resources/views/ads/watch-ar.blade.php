@extends('layouts.app2')

@section('content')
<div class="container">
<br>

 <div class="row">

  <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 col-xl-6"> {{-- col-xs-12 col-sm-6 col-md-6 col-lg-6 col-xl-6 --}}
          
    <div class="panel panel-default" style="width: 560px; height: 315px; padding: 1px;"> {{-- panel panel-default --}}
      
      
        
        <?php echo  $ads->ads_trailer ; ?>

    
    </div> {{-- panel panel-default --}}

  </div> {{-- col-xs-12 col-sm-6 col-md-6 col-lg-6 col-xl-6 --}}


  {{-- --------------------------------------------- --}}



   <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
    <div class="panel panel-default"> {{-- panel panel-default --}}
        <div class="panel-heading"> <h1 class="text-capitalize">{{ $ads->ads_title }}</h1> </div>
        <div class="panel-body" style="padding-bottom: 90px;"><p style="font-size: 12px" class="text-left">{{ $ads->ads_about }}</p></div>
        <div class="panel-footer">
          <p class="text-center">      
        
            {{ $ads->created_at->format('D d , F , m . Y H:i:s  A') }}  &nbsp;  |    &nbsp;   @php
            $datat =$ads->created_at;
            $date1=date_create($datat);
            $date2=date_create(date("Y-m-d"));
            $diff=date_diff($date1,$date2);
            $ago = $diff->format("%a");
            
            if ($ago == 0) {
              echo "اليوم";
            } elseif ($ago == 1){
              echo "منذ يوم واحد";
            } elseif ($ago == 2) {
              echo "منذ يومين";
            } elseif ($ago == 3){
              echo "منذ ثلاثة أيام";
            } elseif ($ago == 4){
              echo "منذ أربعة أيام";
            } elseif ($ago == 5){
              echo "منذ خمسة أيام";
            } elseif ($ago == 6){
              echo "منذ ستة أيام";
            }elseif ($ago < 6){
              echo "منذ أسبوع";
            } elseif ($ago < 13){
            echo "منذ أسبوعيين";
            } elseif ($ago < 20){
              echo "منذ ثلاثة أسابيع";
            } elseif ($ago < 30){
              echo "منذ شهر واحد";
            } elseif ($ago < 60){
              echo "منذ شهرين";
            } elseif ($ago < 90){
              echo "منذ ثلاثة أشهر";
            } elseif ($ago < 120){
              echo "منذ أربعة أشهر";
            } elseif ($ago < 150){
              echo "منذ خمسة أشهر";
            } elseif ($ago < 180){
              echo "منذ ستة أشهر";
            } elseif ($ago < 365){
              echo "منذ سنة واحدة";
            } elseif ($ago < 720){
              echo "منذ سنتين";
            } elseif ($ago < 1095){
              echo "منذ ثلاث سنيين";
            } else {
              echo $ago;
            }
            @endphp
            </p>
        </div>
      </div>{{-- panel panel-default --}}

</div>{{-- col-xs-12 col-sm-6 col-md-6 col-lg-6 col-xl-6 --}}
</div>
</div> <!-- container -->

@endsection

