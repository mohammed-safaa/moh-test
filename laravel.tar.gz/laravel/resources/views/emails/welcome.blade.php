<!DOCTYPE html>
<html lang="en-US">
<head>
    <meta charset="utf-8">
</head>
<body>
<h2>License Media Pro Server license number 252!</h2>

<div>
   {!! $name !!} 
</div>

</body>
</html>