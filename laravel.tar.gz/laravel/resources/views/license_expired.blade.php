<!doctype html>
<html lang="{{ app()->getLocale() }}">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>License expired</title>

        <!-- Fonts -->
       
        <link href="{{ asset('css/style.css') }}" rel="stylesheet">

    </head>
    <body>
        <div class="flex-center position-ref full-height">
            @if (Route::has('login'))
                <div class="top-right links">
                    @auth
                        <a href="{{ url('/home') }}">Home</a>
                    @else
                        <a href="{{ route('login') }}">Login</a>
                        <a href="{{ route('register') }}">Register</a>
                    @endauth
                </div>
            @endif

            <div class="content">
                <div class="title m-b-md" style="color: #c0c6c9; font-size: 50px;">
                    License Expired
                    <br>
                    <small> أنتهاء فترة الترخيص</small>
                   
                </div>
                @if ( Auth::user()->id === 1)
                <div class="links">
                    <a href="/dashboard">Welcome Admin let's go Dashboard !</a>
                </div>
                @else

                <div class="links">
                    <a href="{{ route('logout') }}"
                        onclick="event.preventDefault();
                        document.getElementById('logout-form').submit();" style="padding: 5px; margin-left: 40px;">
                      
                        Logout 
                    
                    </a>
                    <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                        {{ csrf_field() }}
                    </form>
                </div>




                @endif
            </div>
        </div>
    </body>
</html>




