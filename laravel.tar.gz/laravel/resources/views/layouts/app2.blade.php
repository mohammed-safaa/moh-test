<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Laravel') }}</title>

    <!-- Styles -->
 <!-- Bootstrap core CSS -->
 <link href="{{ asset('css/video-js.css') }}" rel="stylesheet">

    <link href="{{ asset('css/bootstrap.min.css') }}" rel="stylesheet">
 

    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <link href="{{ asset('css/style.css') }}" rel="stylesheet">
    <link href="{{ asset('css/bootstrap-rtl.min.css') }}" rel="stylesheet">
      {{-- icon --}}
  <script src='{{ asset('js/fontawesome.js') }}'></script>
    <!-- If you'd like to support IE8 (for Video.js versions prior to v7) -->
   
    <script src="{{ asset('js/videojs-ie8.min.js') }}"></script>
    <script src="{{ asset('js/icon.js') }}"></script>
    
   
    <!-- Style -->
   
    <link href="{{ asset('css/show-hide-text.min.css') }}" rel="stylesheet">


    <style>
        span.text-content span {
    display: table-cell;
    text-align: center;
    vertical-align: middle;
    text-transform: capitalize;
}
.snip1336 h2 {
    margin: 0 0 5px;
    font-weight: 300;
    font-size: 1.0em;
    text-transform: capitalize;
}
    </style>
</head>
<body>

   
  <div id="app">
    <nav class="navbar navbar-default">
        <div class="container-fluid">
          <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar1">
              <span class="sr-only">Toggle navigation</span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>

            
            <a class="navbar-brand" href="/home"><img src="../../storage/upload/{{ config('app.logo') }}" alt="" width="30" height="30" style="margin-left: -20px;  right: 5px; margin-top: -2px;">
            </a>
          </div>
          <div id="navbar1" class="navbar-collapse collapse">
            <ul class="nav navbar-nav">
              <li ><a href="/home"> {{ config('app.name') }} </a></li>
              <li ><a href="/occ/{{ config('app.occasionid') }}">

              @php
              $a = config('app.occasionid');
              if (isset($a)) {
               echo '<img src="../../storage/upload/'.config('app.occasion').'" alt="" height="30" width="70" style="margin-right: -23px">';
              }
          @endphp
               
</a></li>
            </ul>

                <!-- Right Side Of Navbar -->
                <ul class="nav navbar-nav navbar-left">
                    <!-- Sidebar Widgets Column -->
                    <li>
                        @auth
                        <form class="search-container" action="/searchpost" method="POST" role="search">
                            {{ csrf_field() }}
                            <input type="text" id="search-bar" name="search" placeholder="Search.." required>
                               <button class="search-iconar" type="submit"><i class="glyphicon glyphicon-search" aria-hidden="true" style="color: #494949cc;"></i></button>
                          </form>      
                        @endauth
                    </li> 


            <!-- Authentication Links -->
            @guest
                <li><a href="{{ route('login') }}">Login</a></li>
                <li><a href="{{ route('register') }}">Register</a></li>
            @else



                <li class="dropdown">
                   
                    <a href="{{ url('profile') }}/{{ Auth::user()->id }}" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false" aria-haspopup="true" v-pre>
                        <img class="d-flex" style="box-shadow: rgba(255, 253, 253, 0.2) 0px 1px 2px; padding: 1px; margin-left: 5px; margin-right: 50px; margin-top: -6px; border: 1px solid rgba(165, 169, 172, 0.835); "  src="../../storage/upload/{{ Auth::user()->img_avatar }}" alt="" width="35" height="35" > {{ ucfirst(Auth::user()->name) }}<span class="caret"></span>
                    </a>

                    <ul class="dropdown-menu">
                        <li><a href="{{ url('profile') }}/{{ Auth::user()->id }}"> <i class="glyphicon glyphicon-user" aria-hidden="true" style="padding: 5px; font-size: 13px;"> </i> الصفحة الشخصية</a></li>
                            <li><a href="{{ route('post.create') }}"> <i class="glyphicon glyphicon-cloud-upload" aria-hidden="true" style="padding: 5px; font-size: 13px;"> </i> ارفع أفلامك </a></li>
                            @if (Auth::user()->id === 1)
                            <li><a href="/dashboard"> <i class="glyphicon glyphicon-cog" aria-hidden="true" style="padding: 5px; font-size: 13px;"> </i> لوحة المدير</a></li>
                       @endif
                        <li>
                            
                          <a href="{{ route('logout') }}"
                          onclick="event.preventDefault();
                          document.getElementById('logout-form').submit();" style="padding: 5px; margin-right: 13px;">
                          <i class="glyphicon glyphicon-log-out" aria-hidden="true" style="padding: 5px; font-size: 15px;"> </i> 
                                الخروج 
                            </a>

                            <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                {{ csrf_field() }}
                            </form>
                        </li>
                    </ul>
                </li>
            @endguest
        </ul>

          </div>
          <!--/.nav-collapse -->
        </div>
        <!--/.container-fluid -->
      </nav>


    @yield('content')

</div>
{{-- button up --}}
<script>
//Get the button
var mybutton = document.getElementById("myBtn");

// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    mybutton.style.display = "block";
  } else {
    mybutton.style.display = "none";
  }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
}
</script>
{{-- button up --}}

<!-- Scripts -->
<script src="{{ asset('js/app.js') }}"></script>
<script src="{{ asset('js/video.js') }}"></script>
    {{-- script comment long --}}
<script type="text/javascript" src="{{ url('/js/commentlong.js') }}"></script>
<script type="text/javascript" src="{{ url('/js/jquery-3.4.1.min.js') }}"></script>
{{-- script ajax --}}
<script src="{{ url('/js/ajax.js') }}"></script>
<script src="{{ asset('js/like.js') }}"></script>


<!-- ================ our javascript ================== -->

<script src="{{ asset('js/show-hide-text.js') }}"></script>
<script>
var th = new showHideText('.my-message', {
    charQty     : 90,
    ellipseText : "...",
});
</script>

<div class="footer">
    
    <a href="/setting/1">  {{ config('app.name') }} &copy; Copyright 2020 &nbsp; <img src="../../storage/upload/{{ config('app.logo') }}" width="15" height="15"  style=" margin-top: 4px; position: absolute;"></a>
  </div>
</body>
</html>