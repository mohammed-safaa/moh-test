@extends('layouts.app2')

@section('content')
<div class="container">
    <div class="row">

      
      <div class="panel panel-default">
        <div class="panel-heading" style="border-color: #191919;">
          
          <div class="fb-profile">
            <img align="right" class="fb-image-lg" src="../storage/upload/{{ $profile->img_backround }}" alt="Profile image example" height="300"/>
            <img align="right" class="fb-image-profile thumbnail" style="width: 170px;" src="../storage/upload/{{ $profile->img_avatar }}" alt="Profile image example"/>
        </div>
        </div> {{-- panel-heading --}}

        <div class="panel-body">
          <h1 style="font-size: 24px; font-weight: 600;
          text-transform: capitalize;">{{ $profile->name }} <small>  {{ $profile->gender }} | {{ 	$profile->status }} </small></h1>
            <small style="font-size: 10px; font-weight: 300;
            text-transform: capitalize;">{{ $profile->created_at->format('D d , F, m.Y H:i:s A') }}</small>
            <p class="text-right">{{ $profile->country }} | {{ $profile->city }}</p>
            @if (Auth::user()->id === $profile->id)
            <a href="{{ route('profile.edit',$profile->id ) }}" style="width: 150px; font-size: 12px; border: 1px solid rgba(47, 46, 46, 0.15);  border-radius: 0px;" class="btn default" role="button">تعديل المعلومات</a>
            @endif
            <p class="text-right" style="padding: 55px;">{{ $profile->description }}</p>
            <p class="text-right" style="padding-left: 55px;"> {{ $profile->birthday }} : عيد ميلاد  </p>
        </div>{{-- panel-body --}}
        <div class="panel-footer">
          
          <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xl-12">
            <div class="row">
            <ul class="nav nav-tabs nav-justified">
              <li class="active"><a data-toggle="pill" href="#home">الافلام المضافة</a></li>
              <li><a data-toggle="pill" href="#menu1">المسلسلات المضافة</a></li>
              <li><a data-toggle="pill" href="#menu2">التي تم مشاهدتها</a></li>
              {{-- <li><a data-toggle="pill" href="#menu3">History</a></li> --}}
            </ul>
            <br>
          </div>
          </div>
          
   
            <div class="tab-content">

              <div id="home" class="tab-pane fade in active">
                <h3>الافلام المضافة</h3>
                <p> الأفلام التي تم اضافتها.</p>
             
             
                <section id="row1">
                 
              <ul class="img-list">
                @if (count($addedmovie) > 0)
              
                @foreach ($addedmovie as $item)
                                  {{-- card movies --}} 
               <div style="padding-left: 0px;" class="col-xs-12 col-sm-4 col-md-3 col-lg-2 col-xl-2">
                <br>
                <li class="image" style="margin-top: -10px;"> 
                <a href="/post/{{$item->id}}">
                <img id="box1" src="../storage/upload/{{ $item->image }}" width="185" height="130" />
                <span class="text-content"><span>{{ $item->title }}</span></span>
                </a>
                </li>
                </div>{{-- col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2 --}}
                  {{-- card movies --}}  
                @endforeach
                @else
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                  <div class="alert alert-dark">
                    <br>
                    <strong>عذراً ! </strong> لا توجد بيانات
                  </div>
           </div> 
           <!--END NO Post -->
            @endif
              </ul>
             </section>
            
           </div> {{-- tab-pane fade in active --}}
          
          
              <div id="menu1" class="tab-pane fade">
                <h3>المسلسلات المضافة</h3>
                <p> المسلسلات التلفزيونية التي تم اضافتها.</p>
                <section id="row1">
            
                  <ul class="img-list">
                    @if (count($addedtvseries) > 0)
              
                    @foreach ($addedtvseries as $item)
                                      {{-- card movies --}} 
                   <div style="padding-left: 0px;" class="col-xs-12 col-sm-4 col-md-3 col-lg-2 col-xl-2">
                    <br>
                    <li class="image" style="margin-top: -10px;"> 
                    <a href="/post/{{$item->id}}">
                    <img id="box1" src="../storage/upload/{{ $item->image }}" width="185" height="130" />
                    <span class="text-content"><span>{{ $item->title }}</span></span>
                    </a>
                    </li>
                    </div>{{-- col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2 --}}
                      {{-- card movies --}}  
                    @endforeach
                    @else
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                      <div class="alert alert-dark">
                        <br>
                        <strong>عذراً ! </strong> لا توجد بيانات
                      </div>
               </div> 
               <!--END NO Post -->
                @endif
                  </ul>
                 </section>
              </div>
              <div id="menu2" class="tab-pane fade">
                <h3>التي تم مشاهدتها</h3>
                <p> اﻹفلام و المسلسلات التلفزيونية التي تم مشاهدتها.</p>
         
                <section id="row1">
            
                  <ul class="img-list">
         
                    @if (count($watching) > 0)
         
                @foreach ($watching  as $item)
                                {{-- card movies --}} 
                                <div style="padding-left: 0px;" class="col-xs-12 col-sm-4 col-md-3 col-lg-2 col-xl-2">
                                  <br>
                                  <li class="image" style="margin-top: -10px;"> 
                                  <a href="/post/{{$item->postid}}">
                                  <img id="box1" src="../storage/upload/{{$item->image}}" width="185" height="130" />
                                  <span class="text-content"><span> {{$item->title}}</span></span>
                                  </a>
                                  </li>
                                  </div>{{-- col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2 --}}
                                    {{-- card movies --}}  
                
          @endforeach
 
                  @else
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                      <div class="alert alert-dark">
                        <br>
                        <strong>عذراً ! </strong> لا توجد بيانات
                      </div>
               </div> 
               <!--END NO Post -->
                @endif
              
                  </ul>
                 </section>
              </div>

              {{-- <div id="menu3" class="tab-pane fade">
                <h3>History</h3>
                <p>Eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.</p>
           

              </div>
           --}}

          
          </div> {{-- tab-content --}}
          
 
   
        </div>  {{-- panel-footer --}}
      </div>{{-- panel panel-default --}}



       
        {{-- botton up --}}
        <!-- <div class="text-left">
         <br><br>
         <button class="btn btn-outline-left" onclick="topFunction()" id="myBtn" title="Go to top"> <i class="fas fa-chevron-up"></i></button>
         
         </div> -->
         <script>
         //Get the button
         var mybutton = document.getElementById("myBtn");
         
         // When the user scrolls down 20px from the top of the document, show the button
         window.onscroll = function() {scrollFunction()};
         
         function scrollFunction() {
           if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
             mybutton.style.display = "block";
           } else {
             mybutton.style.display = "none";
           }
         }
         
         // When the user clicks on the button, scroll to the top of the document
         function topFunction() {
           document.body.scrollTop = 0;
           document.documentElement.scrollTop = 0;
         }
         </script>
          </div>
</div>
@endsection



