@extends('layouts.app')

@section('content')

<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
          @if (Auth::user()->id === $profileid->id)
            <div class="panel panel-default">
             
                <div class="panel-heading">Edit Profile</div>

                <div class="panel-body">
                    <form class="form-horizontal" method="POST" action="{{ route('profile.update',$profileid->id) }}" enctype="multipart/form-data">
                      {{ method_field('PUT') }}
                      {{ csrf_field() }}
                        <div class="form-group">
                            <label for="name" class="col-md-4 control-label">Name : </label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control" value="{{ $profileid->name }}" name="name" required autofocus>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="email" class="col-md-4 control-label">E-Mail Address : </label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control" name="email" value="{{ $profileid->email }}" required>


                            </div>
                        </div>



                        <div class="form-group">
                            <label for="text" class="col-md-4 control-label">Description : </label>

                            <div class="col-md-6">
                        <textarea class="form-control" name="description" value="{{ $profileid->description }}" id="text" cols="30" rows="2" required>{{ $profileid->description }}</textarea>
                            </div>
                        </div>



                        <div class="form-group">
                            <label for="sel1" class="col-md-4 control-label">Status : </label>
                            <div class="col-md-6">
                              
                            <select type="text" class="form-control" value="{{ $profileid->status }}" name="status" id="sel1" required autofocus>
                            @php
                              $favcolor = $profileid->status;
                              switch ($favcolor) {
                              case "Married":
                                  echo '<option value="Married">Married</option>';
                                  echo '<option value="Single">Single</option>';
                                  break;
                              case "Single":
                                  echo '<option value="Single">Single</option>';
                                  echo '<option value="Married">Married</option>';
                                  break;
                              default:
                                  echo '<option value="Married">Married</option>';
                                  echo '<option value="Single">Single</option>';
                              }
                          @endphp
                          
                          
                            </select>
                          </div> 
                        </div> 
                        <div class="form-group">
                            <label for="sel1" class="col-md-4 control-label">Gender : </label>
                            <div class="col-md-6">
                            <select type="text" class="form-control" value="{{ $profileid->gender }}" name="gender" id="sel1" required autofocus>
                            
                            @php
                              $favcolor = $profileid->gender;
                              switch ($favcolor) {
                              case "Male":
                                  echo '<option value="Male">Male</option>';
                                  echo '<option value="Female">Female</option>';
                                  break;
                              case "Female":
                                  echo '<option value="Female">Female</option>';
                                  echo '<option value="Male">Male</option>';
                                  break;
                              default:
                                  echo '<option value="Male">Male</option>>';
                                  echo '<option value="Female">Female</option>';
                              }
                          @endphp
                            </select>
                          </div> 
                        </div> 

                        <div class="form-group">
                            <label for="name" class="col-md-4 control-label"> Birthday : </label>
                            <div class="col-md-6">
                                <input id="birthday" type="text" class="form-control" value="{{ $profileid->birthday }}" name="birthday"  required autofocus>
                            </div>
                        </div>
                        <div class="form-group">
                          <label for="name" class="col-md-4 control-label">Country : </label>
                          <div class="col-md-6">
                              <input id="birthday" type="text" class="form-control" value="{{ $profileid->country }}" name="country" required autofocus>
                          </div>
                      </div>
                      <div class="form-group">
                        <label for="name" class="col-md-4 control-label">City : </label>
                        <div class="col-md-6">
                            <input id="birthday" type="text" class="form-control" value="{{ $profileid->city }}" name="city"  required autofocus>
                        </div>
                    </div>


                    <div class="form-group">
                        <label for="sel1" class="col-md-4 control-label">Language : </label>
                        <div class="col-md-6">
                        <select type="text" class="form-control" value="{{ $profileid->lang }}" name="lang" id="sel1" required autofocus>
                          <option value="1">English</option>
                          <option value="2">العربية</option>
                        </select>
                      </div> 
                    </div> 

                    <input type="hidden" id="custId" name="img_avatar_no" value="{{ $profileid->img_avatar }}">
                    <input type="hidden" id="custId3" name="img_backround_no" value="{{ $profileid->img_backround }}">

                    <div class="form-group">
                      <label for="text" class="col-md-4 control-label">Avatar : </label>
                      <div class="col-md-6">
                      <input type="file"  id="text"  name="img_avatar">
                    </div>
                  </div>
                    <div class="form-group">
                      <label for="text" class="col-md-4 control-label">Backround : </label>
                      <div class="col-md-6">
                      <input type="file"  id="text"  name="img_backround">
                    </div>
                  </div>
                        <div class="form-group">
                            <div class="col-md-8 col-md-offset-4">
                                <button type="submit" class="btn btn-default">
                                    Update
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>


            @else
            <div class="content">
              <div class="title m-b-md" style="color: #c0c6c9; font-size: 50px;">
                <br>
                Error 404 Not Found 
              </div>


          </div>
          @endif
        </div>
    </div>
</div>
@endsection
