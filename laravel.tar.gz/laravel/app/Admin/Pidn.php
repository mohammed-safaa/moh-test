<?php

namespace App\Admin;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Model;

class Pidn extends Model
{
    //
    use Notifiable;

}
