<?php

namespace App\Admin;

use Illuminate\Database\Eloquent\Model;

class Licensecard extends Model
{
    //
}
