<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Post extends Model
{
    //
    public $table = "posts";

    public function comments()
    {
        return $this->hasMany('App\Comment');
    }

    public function ads()
    {
        return $this->hasMany('App\Ads');
    }

    public function likes()
    {
        return $this->hasMany('App\Like');
    }

    public function viewpost()
    {
        return $this->hasMany('App\Viewpost');
    }

    public function watching()
    {
        return $this->hasMany('App\Watching');
    }


    public function occasion()
    {
        return $this->hasMany('App\Occasion');
    }

    public function user()
    {
        return $this->belongsTo('App\User');
    }

}
