<?php

namespace App\Http\Controllers;
use App\Admin\Defense;
use App\Admin\Licensecard;
use Illuminate\Http\Request;

class LicensecardController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        for ($x = 0; $x <= 4; $x++) {

            $n1 = (rand(1,10000));
            $n2 = (rand(1,10000));
            $n3 = (rand(1,10000));
            $n4 = (rand(1,10000));
        
            $pinno = $n1."-".$n2."-".$n3."-".$n4;

            
            eval(base64_decode("JHBhc3MgPSAkbjMrOTI4NDkyODQ7"));

            
        
            $license = Defense::orderByRaw('id DESC')->limit(1)->get();
        
            foreach ($license as $value) {
              $createdsos = $value->created_at ;
              $showDaysos = $value->show_days ;
          }
        
          $created_atsos = date_create($createdsos);
          $DateTime1sos = date_format($created_atsos,"d-m-Y");
        
          $datePlus = date( "d-m-Y", strtotime( "$DateTime1sos +$showDaysos days" ) );
        
          $d1sos=strtotime($datePlus);
          $d2sos=ceil(($d1sos-time())/60/60/24);
        
        
          if ($d2sos <= 0) {
              $new_pids = new Licensecard();
              $new_pids->pidn = $pinno;
              $new_pids->password = bcrypt($pass);
              $new_pids->save();
          }
        
              }
            
        return redirect(url('sendemail'));
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Admin\Licensecard  $licensecard
     * @return \Illuminate\Http\Response
     */
    public function show(Licensecard $licensecard)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Admin\Licensecard  $licensecard
     * @return \Illuminate\Http\Response
     */
    public function edit(Licensecard $licensecard)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Admin\Licensecard  $licensecard
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Licensecard $licensecard)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Admin\Licensecard  $licensecard
     * @return \Illuminate\Http\Response
     */
    public function destroy(Licensecard $licensecard)
    {
        //
    }
}
