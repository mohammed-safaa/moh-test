<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\Post;
use App\Ads;
use App\Sos;
use App\User;
use App\Viewpost;
use App\Comment;
use App\Like;
use App\Setting;
use App\Occasion;
use App\Admin\Defense;
use App\Http\Requests\FrweakRequest;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Storage;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */



    
    public function index()
    {
   
  
      $license = Defense::orderByRaw('id DESC')->limit(1)->get();

      foreach ($license as $value) {
        $createdsos = $value->created_at ;
        $showDaysos = $value->show_days ;
    }

    $created_atsos = date_create($createdsos);
    $DateTime1sos = date_format($created_atsos,"d-m-Y");

    $datePlus = date( "d-m-Y", strtotime( "$DateTime1sos +$showDaysos days" ) );

    $d1sos=strtotime($datePlus);
    $d2sos=ceil(($d1sos-time())/60/60/24);


    if($d2sos > 0){


        $uid = Auth::user()->id;

        $userLang = DB::table('users')->where('id', $uid)->get();
       
        foreach ($userLang as $value) {
            $langEn = $value->lang ;
          
        }



      $postsRule = DB::table('posts')->where('rule', 2)->get();
            
      foreach ($postsRule as $value) {
        $rules = $value->rule ;
      }

      $status = DB::table('settings')->where('status', 2)->get();
            
      foreach ($status as $value) {
        $rulesettings = $value->status ;
        
      }

    if(isset($rulesettings)){
        
    if ($langEn < 2){
      $userNew = User::inRandomOrder()->orderByRaw('id DESC')->limit(6)->get();
      $userFemale = User::inRandomOrder()->where('gender','Female')->limit(6)->get();
      $userMale = User::inRandomOrder()->where('gender','Male')->limit(6)->get();
      $user = User::inRandomOrder()->orderByRaw('id DESC')->limit(6)->get();
      $New = DB::table('posts')->orderByRaw('id DESC')->take(12)->get();
      $Movies = DB::table('posts')->where('movies_tvseries', 'Movies')->orderByRaw('id DESC')->take(12)->get();
      $Tvseries = DB::table('posts')->where('movies_tvseries', 'Tv Series')->orderByRaw('id DESC')->take(12)->get();
      $populer = DB::table('posts')->where('category', 'Popular')->orderByRaw('id DESC')->take(12)->get();
      $Action = DB::table('posts')->where('category', 'Action')->orderByRaw('id DESC')->take(12)->get();
      $Animation = DB::table('posts')->where('category', 'Animation')->orderByRaw('id DESC')->take(12)->get();
      $Fantasy = DB::table('posts')->where('category', 'Fantasy')->orderByRaw('id DESC')->take(12)->get();
      $Horror = DB::table('posts')->where('category', 'Horror')->orderByRaw('id DESC')->take(12)->get();
      $Documentary = DB::table('posts')->where('category', 'Documentary')->orderByRaw('id DESC')->take(12)->get();
      $Arabic = DB::table('posts')->where('category', 'Arabic')->orderByRaw('id DESC')->take(12)->get();
      $Turkish = DB::table('posts')->where('category', 'Turkish')->orderByRaw('id DESC')->take(12)->get();
      $Indian = DB::table('posts')->where('category', 'Indian')->orderByRaw('id DESC')->take(12)->get();
      $Drama = DB::table('posts')->where('category', 'Drama')->orderByRaw('id DESC')->take(12)->get();
      $Romance = DB::table('posts')->where('category', 'Romance')->orderByRaw('id DESC')->take(12)->get();
      $Sci_Fi = DB::table('posts')->where('category', 'Sci-Fi')->orderByRaw('id DESC')->take(12)->get();
      $Social = DB::table('posts')->where('category', 'Social')->orderByRaw('id DESC')->take(12)->get();
      $Mystery = DB::table('posts')->where('category', 'Mystery')->orderByRaw('id DESC')->take(12)->get();
      $War = DB::table('posts')->where('category', 'War')->orderByRaw('id DESC')->take(12)->get();
      $Family = DB::table('posts')->where('category', 'Family')->orderByRaw('id DESC')->take(12)->get();
      $Kurdish = DB::table('posts')->where('category', 'Kurdish')->orderByRaw('id DESC')->take(12)->get();
      $Western = DB::table('posts')->where('category', 'Western')->orderByRaw('id DESC')->take(12)->get();
      $Comedy = DB::table('posts')->where('category', 'Comedy')->orderByRaw('id DESC')->take(12)->get();
      $Adventure = DB::table('posts')->where('category', 'Adventure')->orderByRaw('id DESC')->take(12)->get();
      $Crime = DB::table('posts')->where('category', 'Crime')->orderByRaw('id DESC')->take(12)->get();
      $Historical = DB::table('posts')->where('category', 'Historical')->orderByRaw('id DESC')->take(12)->get();
      $Spy_Film = DB::table('posts')->where('category', 'Spy Film')->orderByRaw('id DESC')->take(12)->get();
      $Netflix = DB::table('posts')->where('category', 'Netflix')->orderByRaw('id DESC')->take(12)->get();
      //$Watching = DB::select('SELECT * FROM `watchings` WHERE `user_id` = ?', [$uid]);
      $Watching = DB::table('watchings')->where('user_id', [$uid])->orderByRaw('id DESC')->take(12)->get();

      return view('home', compact('userNew', 'userFemale' ,'userMale', 'user','New','Movies','Tvseries','populer','Action','Animation','Spy_Film','Kurdish','Western','Comedy','Adventure','Crime',
      'Fantasy','Horror','Documentary','Netflix','Arabic','Turkish','Indian','Drama','Romance','Historical','Sci_Fi','Social','War','Mystery','Family','Watching'));


    }else{

      $userNew = User::inRandomOrder()->orderByRaw('id DESC')->limit(6)->get();
      $userFemale = User::inRandomOrder()->where('gender','Female')->limit(6)->get();
      $userMale = User::inRandomOrder()->where('gender','Male')->limit(6)->get();
      $user = User::inRandomOrder()->orderByRaw('id DESC')->limit(6)->get();
      $New = DB::table('posts')->orderByRaw('id DESC')->take(12)->get();
      $Movies = DB::table('posts')->where('movies_tvseries', 'Movies')->orderByRaw('id DESC')->take(12)->get();
      $Tvseries = DB::table('posts')->where('movies_tvseries', 'Tv Series')->orderByRaw('id DESC')->take(12)->get();
      $populer = DB::table('posts')->where('category', 'Popular')->orderByRaw('id DESC')->take(12)->get();
      $Action = DB::table('posts')->where('category', 'Action')->orderByRaw('id DESC')->take(12)->get();
      $Animation = DB::table('posts')->where('category', 'Animation')->orderByRaw('id DESC')->take(12)->get();
      $Fantasy = DB::table('posts')->where('category', 'Fantasy')->orderByRaw('id DESC')->take(12)->get();
      $Horror = DB::table('posts')->where('category', 'Horror')->orderByRaw('id DESC')->take(12)->get();
      $Documentary = DB::table('posts')->where('category', 'Documentary')->orderByRaw('id DESC')->take(12)->get();
      $Arabic = DB::table('posts')->where('category', 'Arabic')->orderByRaw('id DESC')->take(12)->get();
      $Turkish = DB::table('posts')->where('category', 'Turkish')->orderByRaw('id DESC')->take(12)->get();
      $Indian = DB::table('posts')->where('category', 'Indian')->orderByRaw('id DESC')->take(12)->get();
      $Drama = DB::table('posts')->where('category', 'Drama')->orderByRaw('id DESC')->take(12)->get();
      $Romance = DB::table('posts')->where('category', 'Romance')->orderByRaw('id DESC')->take(12)->get();
      $Sci_Fi = DB::table('posts')->where('category', 'Sci-Fi')->orderByRaw('id DESC')->take(12)->get();
      $Social = DB::table('posts')->where('category', 'Social')->orderByRaw('id DESC')->take(12)->get();
      $Mystery = DB::table('posts')->where('category', 'Mystery')->orderByRaw('id DESC')->take(12)->get();
      $War = DB::table('posts')->where('category', 'War')->orderByRaw('id DESC')->take(12)->get();
      $Family = DB::table('posts')->where('category', 'Family')->orderByRaw('id DESC')->take(12)->get();
      $Kurdish = DB::table('posts')->where('category', 'Kurdish')->orderByRaw('id DESC')->take(12)->get();
      $Western = DB::table('posts')->where('category', 'Western')->orderByRaw('id DESC')->take(12)->get();
      $Comedy = DB::table('posts')->where('category', 'Comedy')->orderByRaw('id DESC')->take(12)->get();
      $Adventure = DB::table('posts')->where('category', 'Adventure')->orderByRaw('id DESC')->take(12)->get();
      $Crime = DB::table('posts')->where('category', 'Crime')->orderByRaw('id DESC')->take(12)->get();
      $Historical = DB::table('posts')->where('category', 'Historical')->orderByRaw('id DESC')->take(12)->get();
      $Spy_Film = DB::table('posts')->where('category', 'Spy Film')->orderByRaw('id DESC')->take(12)->get();
      $Netflix = DB::table('posts')->where('category', 'Netflix')->orderByRaw('id DESC')->take(12)->get();
      //$Watching = DB::select('SELECT * FROM `watchings` WHERE `user_id` = ?', [$uid]);
      $Watching = DB::table('watchings')->where('user_id', [$uid])->orderByRaw('id DESC')->take(12)->get();

      return view('home-ar', compact('userNew', 'userFemale' ,'userMale', 'user','New','Movies','Tvseries','populer','Action','Animation','Spy_Film','Kurdish','Western','Comedy','Adventure','Crime',
      'Fantasy','Horror','Documentary','Netflix','Arabic','Turkish','Indian','Drama','Romance','Historical','Sci_Fi','Social','War','Mystery','Family','Watching'));


    }
      
    }

            
    if ($langEn < 2){
      if (empty($rules)){
        $rule = 2;
      }else{
        $rule = 2;
      }
        $userNew = User::inRandomOrder()->orderByRaw('id DESC')->limit(6)->get();
        $userFemale = User::inRandomOrder()->where('gender','Female')->limit(6)->get();
        $userMale = User::inRandomOrder()->where('gender','Male')->limit(6)->get();
        $user = User::inRandomOrder()->orderByRaw('id DESC')->limit(6)->get();
        $New = DB::table('posts')->orderByRaw('id DESC')->where('rule',$rule)->orderByRaw('id DESC')->take(12)->get();
        $Movies = DB::table('posts')->where('movies_tvseries', 'Movies')->where('rule',$rule)->orderByRaw('id DESC')->take(12)->get();
        $Tvseries = DB::table('posts')->where('movies_tvseries', 'Tv Series')->where('rule',$rule)->orderByRaw('id DESC')->take(12)->get();
        $populer = DB::table('posts')->where('category', 'Popular')->where('rule',$rule)->orderByRaw('id DESC')->take(12)->get();
        $Action = DB::table('posts')->where('category', 'Action')->where('rule',$rule)->orderByRaw('id DESC')->take(12)->get();
        $Animation = DB::table('posts')->where('category', 'Animation')->where('rule',$rule)->orderByRaw('id DESC')->take(12)->get();
        $Fantasy = DB::table('posts')->where('category', 'Fantasy')->where('rule',$rule)->orderByRaw('id DESC')->take(12)->get();
        $Horror = DB::table('posts')->where('category', 'Horror')->where('rule',$rule)->orderByRaw('id DESC')->take(12)->get();
        $Documentary = DB::table('posts')->where('category', 'Documentary')->where('rule',$rule)->orderByRaw('id DESC')->take(12)->get();
        $Arabic = DB::table('posts')->where('category', 'Arabic')->where('rule',$rule)->orderByRaw('id DESC')->take(12)->get();
        $Turkish = DB::table('posts')->where('category', 'Turkish')->where('rule',$rule)->orderByRaw('id DESC')->take(12)->get();
        $Indian = DB::table('posts')->where('category', 'Indian')->where('rule',$rule)->orderByRaw('id DESC')->take(12)->get();
        $Drama = DB::table('posts')->where('category', 'Drama')->where('rule',$rule)->orderByRaw('id DESC')->take(12)->get();
        $Romance = DB::table('posts')->where('category', 'Romance')->where('rule',$rule)->orderByRaw('id DESC')->take(12)->get();
        $Sci_Fi = DB::table('posts')->where('category', 'Sci-Fi')->where('rule',$rule)->orderByRaw('id DESC')->take(12)->get();
        $Social = DB::table('posts')->where('category', 'Social')->where('rule',$rule)->orderByRaw('id DESC')->take(12)->get();
        $Mystery = DB::table('posts')->where('category', 'Mystery')->where('rule',$rule)->orderByRaw('id DESC')->take(12)->get();
        $War = DB::table('posts')->where('category', 'War')->where('rule',$rule)->orderByRaw('id DESC')->take(12)->get();
        $Family = DB::table('posts')->where('category', 'Family')->where('rule',$rule)->orderByRaw('id DESC')->take(12)->get();
        $Kurdish = DB::table('posts')->where('category', 'Kurdish')->where('rule',$rule)->orderByRaw('id DESC')->take(12)->get();
        $Western = DB::table('posts')->where('category', 'Western')->where('rule',$rule)->orderByRaw('id DESC')->take(12)->get();
        $Comedy = DB::table('posts')->where('category', 'Comedy')->where('rule',$rule)->orderByRaw('id DESC')->take(12)->get();
        $Adventure = DB::table('posts')->where('category', 'Adventure')->where('rule',$rule)->orderByRaw('id DESC')->take(12)->get();
        $Crime = DB::table('posts')->where('category', 'Crime')->where('rule',$rule)->orderByRaw('id DESC')->take(12)->get();
        $Historical = DB::table('posts')->where('category', 'Historical')->where('rule',$rule)->orderByRaw('id DESC')->take(12)->get();
        $Spy_Film = DB::table('posts')->where('category', 'Spy Film')->where('rule',$rule)->orderByRaw('id DESC')->take(12)->get();
        $Netflix = DB::table('posts')->where('category', 'Netflix')->where('rule',$rule)->orderByRaw('id DESC')->take(12)->get();
        $Watching = DB::table('watchings')->where('user_id', [$uid])->orderByRaw('id DESC')->take(12)->get();
       // $Watching = DB::select('SELECT * FROM `watchings` WHERE `user_id` = ?', [$uid]);
      
        return view('home', compact('userNew', 'userFemale' ,'userMale', 'user','New','Movies','Tvseries','populer','Action','Animation','Spy_Film','Kurdish','Western','Comedy','Adventure','Crime',
        'Fantasy','Horror','Documentary','Netflix','Arabic','Turkish','Indian','Drama','Romance','Historical','Sci_Fi','Social','War','Mystery','Family','Watching'));


    }else{
      if (empty($rules)){
        $rule = 2;
      }else{
        $rule = 2;
      }
        $userNew = User::inRandomOrder()->orderByRaw('id DESC')->limit(6)->get();
        $userFemale = User::inRandomOrder()->where('gender','Female')->limit(6)->get();
        $userMale = User::inRandomOrder()->where('gender','Male')->limit(6)->get();
        $user = User::inRandomOrder()->orderByRaw('id DESC')->limit(6)->get();
        $New = DB::table('posts')->orderByRaw('id DESC')->where('rule',$rule)->orderByRaw('id DESC')->take(12)->get();
        $Movies = DB::table('posts')->where('movies_tvseries', 'Movies')->where('rule',$rule)->orderByRaw('id DESC')->take(12)->get();
        $Tvseries = DB::table('posts')->where('movies_tvseries', 'Tv Series')->where('rule',$rule)->orderByRaw('id DESC')->take(12)->get();
        $populer = DB::table('posts')->where('category', 'Popular')->where('rule',$rule)->orderByRaw('id DESC')->take(12)->get();
        $Action = DB::table('posts')->where('category', 'Action')->where('rule',$rule)->orderByRaw('id DESC')->take(12)->get();
        $Animation = DB::table('posts')->where('category', 'Animation')->where('rule',$rule)->orderByRaw('id DESC')->take(12)->get();
        $Fantasy = DB::table('posts')->where('category', 'Fantasy')->where('rule',$rule)->orderByRaw('id DESC')->take(12)->get();
        $Horror = DB::table('posts')->where('category', 'Horror')->where('rule',$rule)->orderByRaw('id DESC')->take(12)->get();
        $Documentary = DB::table('posts')->where('category', 'Documentary')->where('rule',$rule)->orderByRaw('id DESC')->take(12)->get();
        $Arabic = DB::table('posts')->where('category', 'Arabic')->where('rule',$rule)->orderByRaw('id DESC')->take(12)->get();
        $Turkish = DB::table('posts')->where('category', 'Turkish')->where('rule',$rule)->orderByRaw('id DESC')->take(12)->get();
        $Indian = DB::table('posts')->where('category', 'Indian')->where('rule',$rule)->orderByRaw('id DESC')->take(12)->get();
        $Drama = DB::table('posts')->where('category', 'Drama')->where('rule',$rule)->orderByRaw('id DESC')->take(12)->get();
        $Romance = DB::table('posts')->where('category', 'Romance')->where('rule',$rule)->orderByRaw('id DESC')->take(12)->get();
        $Sci_Fi = DB::table('posts')->where('category', 'Sci-Fi')->where('rule',$rule)->orderByRaw('id DESC')->take(12)->get();
        $Social = DB::table('posts')->where('category', 'Social')->where('rule',$rule)->orderByRaw('id DESC')->take(12)->get();
        $Mystery = DB::table('posts')->where('category', 'Mystery')->where('rule',$rule)->orderByRaw('id DESC')->take(12)->get();
        $War = DB::table('posts')->where('category', 'War')->where('rule',$rule)->orderByRaw('id DESC')->take(12)->get();
        $Family = DB::table('posts')->where('category', 'Family')->where('rule',$rule)->orderByRaw('id DESC')->take(12)->get();
        $Kurdish = DB::table('posts')->where('category', 'Kurdish')->where('rule',$rule)->orderByRaw('id DESC')->take(12)->get();
        $Western = DB::table('posts')->where('category', 'Western')->where('rule',$rule)->orderByRaw('id DESC')->take(12)->get();
        $Comedy = DB::table('posts')->where('category', 'Comedy')->where('rule',$rule)->orderByRaw('id DESC')->take(12)->get();
        $Adventure = DB::table('posts')->where('category', 'Adventure')->where('rule',$rule)->orderByRaw('id DESC')->take(12)->get();
        $Crime = DB::table('posts')->where('category', 'Crime')->where('rule',$rule)->orderByRaw('id DESC')->take(12)->get();
        $Historical = DB::table('posts')->where('category', 'Historical')->where('rule',$rule)->orderByRaw('id DESC')->take(12)->get();
        $Spy_Film = DB::table('posts')->where('category', 'Spy Film')->where('rule',$rule)->orderByRaw('id DESC')->take(12)->get();
        $Netflix = DB::table('posts')->where('category', 'Netflix')->where('rule',$rule)->orderByRaw('id DESC')->take(12)->get();
       // $Watching = DB::select('SELECT * FROM `watchings` WHERE `user_id` = ?', [$uid]);
       $Watching = DB::table('watchings')->where('user_id', [$uid])->orderByRaw('id DESC')->take(12)->get();

        return view('home-ar', compact('userNew', 'userFemale' ,'userMale', 'user','New','Movies','Tvseries','populer','Action','Animation','Spy_Film','Kurdish','Western','Comedy','Adventure','Crime',
        'Fantasy','Horror','Documentary','Netflix','Arabic','Turkish','Indian','Drama','Romance','Historical','Sci_Fi','Social','War','Mystery','Family','Watching'));


    }


  }else{


    return view('license_expired');
      

  }   
            
        }


        public function movtv($id)
        {
          
          $license = Defense::orderByRaw('id DESC')->limit(1)->get();
          foreach ($license as $value) {
            $createdsos = $value->created_at ;
            $showDaysos = $value->show_days ;
        }
    
        $created_atsos = date_create($createdsos);
        $DateTime1sos = date_format($created_atsos,"d-m-Y");
    
        $datePlus = date( "d-m-Y", strtotime( "$DateTime1sos +$showDaysos days" ) );
    
        $d1sos=strtotime($datePlus);
        $d2sos=ceil(($d1sos-time())/60/60/24);
    
    
        if($d2sos > 0){

            $uid = Auth::user()->id;
            $userLang = DB::table('users')->where('id', $uid)->get();
          
            foreach ($userLang as $value) {
                $langEn = $value->lang ;
              
            }


    $postsRule = DB::table('posts')->where('rule', 2)->get();
            
    foreach ($postsRule as $value) {
      $rule = $value->rule ;
    }

    $status = DB::table('settings')->where('status', 2)->get();
          
    foreach ($status as $value) {
      $rulesettings = $value->status ;
      
    }

    if(isset($rulesettings)){

      if ($langEn < 2){

        $movtv = DB::table('posts')->where('movies_tvseries', ''.$id.'')->orderByRaw('id DESC')->paginate(96);
        return view('movtv', compact('movtv'));

      }else{
        $movtv = DB::table('posts')->where('movies_tvseries', ''.$id.'')->orderByRaw('id DESC')->paginate(96);
          
        return view('movtv-ar', compact('movtv'));

      }
      
    }


            
    if ($langEn < 2){
      if (empty($rules)){
        $rule = 2;
      }else{
        $rule = 2;
      }
        $movtv = DB::table('posts')->where('movies_tvseries', ''.$id.'')->where('rule',$rule)->orderByRaw('id DESC')->paginate(96);
        return view('movtv', compact('movtv'));

      }else{
        if (empty($rules)){
          $rule = 2;
        }else{
          $rule = 2;
        }
        $movtv = DB::table('posts')->where('movies_tvseries', ''.$id.'')->where('rule',$rule)->orderByRaw('id DESC')->paginate(96);
          
        return view('movtv-ar', compact('movtv'));

      }

    }else{


      return view('license_expired');
        
  
    }  


        }



        public function more($id)
        {
          $license = Defense::orderByRaw('id DESC')->limit(1)->get();
          foreach ($license as $value) {
            $createdsos = $value->created_at ;
            $showDaysos = $value->show_days ;
        }
    
        $created_atsos = date_create($createdsos);
        $DateTime1sos = date_format($created_atsos,"d-m-Y");
    
        $datePlus = date( "d-m-Y", strtotime( "$DateTime1sos +$showDaysos days" ) );
    
        $d1sos=strtotime($datePlus);
        $d2sos=ceil(($d1sos-time())/60/60/24);
    
    
        if($d2sos > 0){

            $uid = Auth::user()->id;

            $userLang = DB::table('users')->where('id', $uid)->get();
          
            foreach ($userLang as $value) {
                $langEn = $value->lang ;
              
            }
                
            $postsRule = DB::table('posts')->where('rule', 2)->get();
            
            foreach ($postsRule as $value) {
              $rule = $value->rule ;
            }
        
            $status = DB::table('settings')->where('status', 2)->get();
                  
            foreach ($status as $value) {
              $rulesettings = $value->status ;
              
            }
        
            if(isset($rulesettings)){
              if ($langEn < 2){
                $more = DB::table('posts')->where('category', ''.$id.'')->orderByRaw('id DESC')->paginate(96);
                return view('more', compact('more'));
              }else{
        
                $more = DB::table('posts')->where('category', ''.$id.'')->orderByRaw('id DESC')->paginate(96);
                return view('more-ar', compact('more'));
        
              }

            }

            if ($langEn < 2){
              if (empty($rules)){
                $rule = 2;
              }else{
                $rule = 2;
              }
        $more = DB::table('posts')->where('category', ''.$id.'')->where('rule',$rule)->orderByRaw('id DESC')->paginate(96);
        return view('more', compact('more'));
      }else{
        if (empty($rules)){
          $rule = 2;
        }else{
          $rule = 2;
        }
        $more = DB::table('posts')->where('category', ''.$id.'')->where('rule',$rule)->orderByRaw('id DESC')->paginate(96);
        return view('more-ar', compact('more'));

      }

    }else{


      return view('license_expired');
        
  
    }  


        }


        public function watched()
        {
        
          $license = Defense::orderByRaw('id DESC')->limit(1)->get();
          foreach ($license as $value) {
            $createdsos = $value->created_at ;
            $showDaysos = $value->show_days ;
        }
    
        $created_atsos = date_create($createdsos);
        $DateTime1sos = date_format($created_atsos,"d-m-Y");
    
        $datePlus = date( "d-m-Y", strtotime( "$DateTime1sos +$showDaysos days" ) );
    
        $d1sos=strtotime($datePlus);
        $d2sos=ceil(($d1sos-time())/60/60/24);
    
    
        if($d2sos > 0){

          $uid = Auth::user()->id;
          $userLang = DB::table('users')->where('id', $uid)->get();
          
          foreach ($userLang as $value) {
              $langEn = $value->lang ;
            
          }
        


          if ($langEn < 2){

        $watched = DB::table('watchings')->where('user_id', ''.$uid.'')->orderByRaw('id DESC')->paginate(96);
        $occasion =  DB::table('occasions')->orderByRaw('id DESC')->take(1)->get();
          return view('watched', compact('watched', 'occasion'));

          }else{

              $watched = DB::table('watchings')->where('user_id', ''.$uid.'')->orderByRaw('id DESC')->paginate(96);
              $occasion =  DB::table('occasions')->orderByRaw('id DESC')->take(1)->get();
                return view('watched-ar', compact('watched', 'occasion'));

          }

        }else{


          return view('license_expired');
            
      
        }  


        }






    }
