<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth;
use App\Profile;
use App\User;
use App\Sos;
use App\Admin\Defense;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ProfileController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Profile  $profile
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //

        $license = Defense::orderByRaw('id DESC')->limit(1)->get();
        foreach ($license as $value) {
          $createdsos = $value->created_at ;
          $showDaysos = $value->show_days ;
      }
  
      $created_atsos = date_create($createdsos);
      $DateTime1sos = date_format($created_atsos,"d-m-Y");
  
      $datePlus = date( "d-m-Y", strtotime( "$DateTime1sos +$showDaysos days" ) );
  
      $d1sos=strtotime($datePlus);
      $d2sos=ceil(($d1sos-time())/60/60/24);
  
  
      if($d2sos > 0){
          
        $profile = User::find($id);
        $uid = Auth::user()->id;
        $userLang = DB::table('users')->where('id', $uid)->get();
        foreach ($userLang as $value) {
            $langEn = $value->lang ;
        }
       
        if ($langEn < 2){
            $addedmovie = DB::select("SELECT * FROM `posts` WHERE `movies_tvseries` = 'Movies' AND `user_id` = $id ORDER BY `id` DESC ");
            $addedtvseries = DB::select("SELECT * FROM `posts` WHERE `movies_tvseries` = 'Tv Series' AND `user_id` = $id ORDER BY `id` DESC ");
            $watching = DB::select('SELECT * FROM `watchings` WHERE `user_id` = ?', [$id]);
            $occasion =  DB::table('occasions')->orderByRaw('id DESC')->take(1)->get();
            return view('auth.profile', compact('addedmovie','profile','addedtvseries','watching' , 'occasion')); 
        }else{
            
            $addedmovie = DB::select("SELECT * FROM `posts` WHERE `movies_tvseries` = 'Movies' AND `user_id` = $id ORDER BY `id` DESC ");
            $addedtvseries = DB::select("SELECT * FROM `posts` WHERE `movies_tvseries` = 'Tv Series' AND `user_id` = $id ORDER BY `id` DESC ");
            $watching = DB::select('SELECT * FROM `watchings` WHERE `user_id` = ?', [$id]);
            $occasion =  DB::table('occasions')->orderByRaw('id DESC')->take(1)->get();
            return view('auth.profile-ar', compact('addedmovie','profile','addedtvseries','watching' , 'occasion')); 
        }


        
    }else{


        return view('license_expired');
          
    
      }



    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Profile  $profile
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $license = Defense::orderByRaw('id DESC')->limit(1)->get();
        foreach ($license as $value) {
          $createdsos = $value->created_at ;
          $showDaysos = $value->show_days ;
      }
  
      $created_atsos = date_create($createdsos);
      $DateTime1sos = date_format($created_atsos,"d-m-Y");
  
      $datePlus = date( "d-m-Y", strtotime( "$DateTime1sos +$showDaysos days" ) );
  
      $d1sos=strtotime($datePlus);
      $d2sos=ceil(($d1sos-time())/60/60/24);
  
  
      if($d2sos > 0){

        $uid = Auth::user()->id;
        $userLang = DB::table('users')->where('id', $uid)->get();
        foreach ($userLang as $value) {
            $langEn = $value->lang ;
        }
       
        if ($langEn < 2){
            $profileid = User::find($id);
            return view('auth.editprofile')->with('profileid',$profileid);
        }else{
            $profileid = User::find($id);
            return view('auth.editprofile-ar')->with('profileid',$profileid);
        }


    }else{


        return view('license_expired');
          
    
      }

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Profile  $profile
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,$id)
    {
        $license = Defense::orderByRaw('id DESC')->limit(1)->get();
        foreach ($license as $value) {
          $createdsos = $value->created_at ;
          $showDaysos = $value->show_days ;
      }
  
      $created_atsos = date_create($createdsos);
      $DateTime1sos = date_format($created_atsos,"d-m-Y");
  
      $datePlus = date( "d-m-Y", strtotime( "$DateTime1sos +$showDaysos days" ) );
  
      $d1sos=strtotime($datePlus);
      $d2sos=ceil(($d1sos-time())/60/60/24);
  
  
      if($d2sos > 0){
        //
          // THIS UPDATE POST لتعديل المنشور
          $this->validate($request,[
            'name'=>'required',
            'email'=>'required',
            'description'=>'nullable',
            'status'=>'required',
            'gender'=>'required',
            'birthday'=>'required',
            'country'=>'nullable',
            'city'=>'required',
            'lang'=>'required',
            'img_avatar' => 'image|mimes:jpeg,png,jpg,gif,svg|max:900000000',
            'img_backround' => 'image|mimes:jpeg,png,jpg,gif,svg|max:3900000000',
        ]);


        if (empty($request->hasFile('img_avatar'))){

            $nes = User::find($id);
            $nes->name = $request->input('name');
            $nes->email = $request->input('email');
           // $nes->password = bcrypt($request->input('password'));
            $nes->description = $request->input('description');
            $nes->status = $request->input('status');
            $nes->gender = $request->input('gender');
            $nes->birthday = $request->input('birthday');
            $nes->country= $request->input('country');
            $nes->city= $request->input('city');
            $nes->lang= $request->input('lang');
            $nes->img_avatar = $request->input('img_avatar_no');
            $nes->save();

        }else{

            $fileObject = $request->file('img_avatar');
            $extension = $fileObject->getClientOriginalExtension();
            $mimeTypy = $fileObject->getClientMimeType();
            $fileName = $fileObject->getClientOriginalName();
            $size = $fileObject->getClientSize();
            $name_avatar =  $request->input('name').'-'.time().'.'.$extension;
            $path_image = $fileObject->storeAs('public/upload',$name_avatar);


            $nes = User::find($id);
            $nes->name = $request->input('name');
            $nes->email = $request->input('email');
           // $nes->password = bcrypt($request->input('password'));
            $nes->description = $request->input('description');
            $nes->status = $request->input('status');
            $nes->gender = $request->input('gender');
            $nes->birthday = $request->input('birthday');
            $nes->country= $request->input('country');
            $nes->city= $request->input('city');
            $nes->lang= $request->input('lang');
            $nes->img_avatar = $name_avatar;
            $nes->save();
            

        }


        if (empty($request->hasFile('img_backround'))){

            $nes = User::find($id);
            $nes->name = $request->input('name');
            $nes->email = $request->input('email');
           // $nes->password = bcrypt($request->input('password'));
            $nes->description = $request->input('description');
            $nes->status = $request->input('status');
            $nes->gender = $request->input('gender');
            $nes->birthday = $request->input('birthday');
            $nes->country= $request->input('country');
            $nes->city= $request->input('city');
            $nes->lang= $request->input('lang');
            $nes->img_backround = $request->input('img_backround_no');
            $nes->save();

        }else{

            $fileObject = $request->file('img_backround');
            $extension = $fileObject->getClientOriginalExtension();
            $mimeTypy = $fileObject->getClientMimeType();
            $fileName = $fileObject->getClientOriginalName();
            $size = $fileObject->getClientSize();
            $name_backround =  $request->input('name').'-back'.time().'.'.$extension;
            $path_image = $fileObject->storeAs('public/upload',$name_backround);

            $nes = User::find($id);
            $nes->name = $request->input('name');
            $nes->email = $request->input('email');
           // $nes->password = bcrypt($request->input('password'));
            $nes->description = $request->input('description');
            $nes->status = $request->input('status');
            $nes->gender = $request->input('gender');
            $nes->birthday = $request->input('birthday');
            $nes->country= $request->input('country');
            $nes->city= $request->input('city');
            $nes->lang= $request->input('lang');
            $nes->img_backround = $name_backround;
            $nes->save();
            

        }


        return redirect(url('profile', $id));



    }else{


        return view('license_expired');
          
    
      }


    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Profile  $profile
     * @return \Illuminate\Http\Response
     */
    public function destroy(Profile $profile)
    {
        //
    }
}
