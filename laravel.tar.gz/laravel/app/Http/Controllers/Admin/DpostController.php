<?php

namespace App\Http\Controllers\Admin;

use App\Comment;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Like;
use App\Post;
use App\Viewpost;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class DpostController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        if (Auth::user()->id === 1) {
        $allpost = Post::orderBy('id', 'DESC')->get();
        return view('admin.post.list')->with('allpost',$allpost);

    } else {

        return redirect(url('home'));

    }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        // GO PAGE EDIT POST للذهاب الى صفحة تعديل المنشور 
        if (Auth::user()->id === 1) {
        $postid = Post::find($id);
        return view('admin.post.edit')->with('postid',$postid);
    } else {

        return redirect(url('home'));

    }

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if (Auth::user()->id === 1) {
         // THIS UPDATE POST لتعديل المنشور
         $this->validate($request,[
            'title'=>'required|string|max:255',
            'post'=>'required|string|max:500',
            'category'=>'required|string|max:500',
            'movies&tvseries'=>'required|string|max:500',
            'year'=>'required|string|max:500',
            'trailer'=>'required|string|max:500',
            'imdb'=>'required|string|max:500',
            'rule'=>'string|max:3',
        ]);

        $nes = Post::find($id);
        $nes->title = $request->input('title');
        $nes->post = $request->input('post');
        $nes->category = $request->input('category');
        $nes->movies_tvseries = $request->input('movies&tvseries');
        $nes->year = $request->input('year');
        $nes->imdb= $request->input('imdb');
        $nes->trailer= $request->input('trailer');

        if(empty($request->input('rule'))){
        $nes->rule = 1;
        }else{
         $nes->rule = $request->input('rule');
        }
        
        $nes->save();

        return redirect(url('dpost'));

    } else {

        return redirect(url('home'));

    }



    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    { 
        if (Auth::user()->id === 1) {
         // find id post للبحث عن ايدي المنشور 
         $postdel = Post::find($id);
                
         // delete view
         $viewsdel = DB::table('viewposts')
         ->where('post_id', $id)
         ->get();

         // delete comment
         $commdel = DB::table('comments')
         ->where('post_id', $id)
         ->get();

         // delete like
         $likedel = DB::table('likes')
         ->where('post_id', $id)
         ->get();

         // delete watchings
         $watchingsdel = DB::table('watchings')
         ->where('postid', $id)
         ->get();


         
         if(isset($viewsdel)){

         foreach ($viewsdel as $value) {
             $viewsdelid[] =  $value->id;  
         }
           DB::table('viewposts')->whereIn('id', $viewsdelid)->delete();
         }



         if(isset($commdel)){
            foreach ($commdel as $value) {
             $commdelid[] =  $value->id;  
            }
          
            if(isset($commdelid)){
             DB::table('comments')->whereIn('id', $commdelid)->delete();
         }
             
         }





         if(isset($likedel)){
             foreach ($likedel as $value) {
                 $likedelid[] =  $value->id;  
                }
             if(isset($likedelid)){
                 DB::table('likes')->whereIn('id', $likedelid)->delete();
             }
             
         }




         if(isset($watchingsdel)){
             
             foreach ($watchingsdel as $value) {
                 $watchingsdelid[] =  $value->id;  
                }  

              DB::table('watchings')->whereIn('id', $watchingsdelid)->delete();
         
         }


         foreach ( json_decode( $postdel->video ) as $vidlist ) {
         Storage::delete(['public/upload/'.$vidlist->video]);
         }

         // delete files image & video لحذف ملفات الفديو والصوره
         Storage::delete(['public/upload/'.$postdel->image]);
         // delete database لحذف من قاعدة البيانات 
         $postdel->destroy($id);
         //back to pages posts للعودة الى الصفحة الرئيسية للمنشورات 

         //return redirect()->to(route('post.destroy',$id))->to(route('home'));
       
         return redirect(url('dpost'));

        } else {

            return redirect(url('home'));
    
        }

            }
        }