<?php

namespace App\Http\Controllers\Admin;
use Illuminate\Support\Facades\Auth;
use App\Comment;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Like;
use App\Post;
use App\User;
use App\Viewpost;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class DuserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        if (Auth::user()->id === 1) {
        $users = User::orderBy('id', 'DESC')->get();
        return view('admin.user.list', ['users' => $users]);

    } else {

        return redirect(url('home'));

    }

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        if (Auth::user()->id === 1) {
        $users = User::find($id);
        return view('admin.user.edit')->with('users',$users);
    } else {

        return redirect(url('home'));

    }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if (Auth::user()->id === 1) {

        $this->validate($request,[
            'name'=>'required',
            'email'=>'required',
            'description'=>'nullable',
            'status'=>'required',
            'gender'=>'required',
            'birthday'=>'required',
            'country'=>'nullable',
            'city'=>'required',

        ]);

        $nes = User::find($id);
        $nes->name = $request->input('name');
        $nes->email = $request->input('email');
        $nes->description = $request->input('description');
        $nes->status = $request->input('status');
        $nes->gender = $request->input('gender');
        $nes->birthday = $request->input('birthday');
        $nes->country= $request->input('country');
        $nes->city= $request->input('city');
        $nes->save();
        return redirect(url('duser'));

    } else {

        return redirect(url('home'));

    }
      
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        if (Auth::user()->id === 1) {
              // find id post للبحث عن ايدي المنشور 
              $userdel = User::find($id);

              // delete view
                      $viewsdel = DB::table('viewposts')
                      ->where('user_id', $id)
                      ->get();
              
                      if(isset($viewsdel)){
                          $vdel = $viewsdel->id;
                          $new_viewsdel = Viewpost::find($vdel);
                          $new_viewsdel->destroy($vdel);
                      }
                      
              
              // delete comment
                      $commdel = DB::table('comments')
                      ->where('user_id', $id)
                      ->get();
              
                      if(isset($commdel)){
                          $cdel = $commdel->id;
                          $new_viewsdel = Comment::find($cdel);
                          $new_viewsdel->destroy($cdel);
                      }
                    
              
              
              // delete like
                      $likedel = DB::table('likes')
                      ->where('user_id', $id)
                      ->get();
              
                      if(isset($likedel)){
                      $ldel = $likedel->id;
                      $del = Like::find($ldel);
                      $del->destroy($ldel);
                      }
              
              

              // delete post
              $postdel = DB::table('posts')
              ->where('user_id', $id)
              ->first();
      
              if(isset($postdel)){
              $pdel = $postdel->id;
              $del = Like::find($pdel);
              $del->destroy($pdel);
              }





                      // delete database لحذف من قاعدة البيانات 
                      $userdel->destroy($id);
                      //back to pages posts للعودة الى الصفحة الرئيسية للمنشورات 
                      return redirect(route('home'));

                    } else {

                        return redirect(url('home'));
                
                    }

                 
    }
}
