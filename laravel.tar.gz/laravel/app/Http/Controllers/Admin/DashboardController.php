<?php

namespace App\Http\Controllers\Admin;

use App\Comment;
use App\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Like;
use App\Post;
use App\Viewpost;
use App\Admin\Defense;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
class DashboardController extends Controller
{
    //
    public function index() 
    {
        if (Auth::user()->id === 1) {
            $sos = DB::table('defenses')->orderByRaw('id DESC')->take(1)->get();
            
            $movies = DB::table('posts')
            ->where('movies_tvseries', 'Movies')
            ->count();
     
            $tvseries = DB::table('posts')
             ->where('movies_tvseries', 'Tv Series')
             ->count();
     
            $likes = DB::table('likes')
             ->where('like', 1)
             ->count();
     
            $dslikes = DB::table('likes')
             ->where('like', 0)
             ->count();
     
     
            $users = User::count();
            $comments = Comment::count();
            $views = Viewpost::count();
            return view('admin.dashboard', ['users' => $users,'comments' => $comments, 'likes' => $likes, 'dslikes' => $dslikes, 'movies' => $movies, 'tvseries' => $tvseries, 'views' => $views , 'sos' => $sos ]);
       
        } else {

            return redirect(url('home'));

        }


    }


}
