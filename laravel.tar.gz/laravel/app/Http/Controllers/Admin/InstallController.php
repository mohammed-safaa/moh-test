<?php

namespace App\Http\Controllers\Admin;
use App\Setting;
use App\Admin\Defense;
use App\Sos;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class InstallController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
 

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //

        return view('admin.setting.add');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        
        $this->validate($request,[
            'title'=>'required',
        ]);
        $setting = Setting::orderByRaw('id DESC')->limit(1)->get();
        
        if (count($setting)==0) {
            $setting = new Setting();
            $setting->logo = "no-logo.png";
            $setting->title = $request->input('title');
            $setting->about = "about نبذا عنا";
            $setting->email = "Media-Pro@admin.com";
            $setting->address = "iraq - baghdad";
            $setting->phone = "12345656662";
            $setting->facebook = "https://www.facebook.com/";
            $setting->youtube = "https://www.youtube.com/?gl=TR";
            $setting->twitter = "https://twitter.com/twitter?lang=ar";
            $setting->web = "www.bagdhadtecnho.com";
            $setting->app_ip = "192.168.1.111";
            $setting->app_android = "https://play.google.com/store?hl=tr";
            $setting->app_ios = "https://apps.apple.com/tr/app/youtube/id544007664?l=tr/";
            $nl = (rand(1,10000));
            $setting->license_number = $nl;
            $setting->status = 2;
            $setting->save();  
    }

    $chsos = Defense::orderByRaw('id DESC')->limit(1)->get();

    if(count($chsos) == 0 ){
        $newSos = new Defense();
        $newSos->sos_title = "reguest free";
        $newSos->show_days = 7;
        $newSos->save();
    }




    return redirect(url('/'));

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
