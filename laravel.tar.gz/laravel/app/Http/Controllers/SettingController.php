<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use App\Setting;
use App\Sos;
use App\Admin\Defense;
use Illuminate\Http\Request;

class SettingController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //

        $id1 = 1;
        $setti = Setting::find($id1);
        return view('home')->with('setti',$setti);

    }

    public function nav($id)
    {
        //
    //    $id1 = 1;
    //     $appHe = DB::table('settings')->orderByRaw('id DESC')->take(1)->get();
    //     return view('nav')->with('appHe',$appHe);

    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Setting  $setting
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        $license = Defense::orderByRaw('id DESC')->limit(1)->get();
        foreach ($license as $value) {
          $createdsos = $value->created_at ;
      }
  
      $created_atsos = date_create($createdsos);
      $DateTime1sos = date_format($created_atsos,"d-m-Y");
      
      $datePlus = date( "d-m-Y", strtotime( "$DateTime1sos +12 month" ) );
      $d1sos=strtotime($datePlus);
      $d2sos=ceil(($d1sos-time())/60/60/24);
  
  
      if($d2sos > 0){

        $id1 = 1;
        $contact = Setting::find($id1);

        $uid = Auth::user()->id;
        $userLang = DB::table('users')->where('id', $uid)->get();

        foreach ($userLang as $value) {
            $langEn = $value->lang ;
           
        }
       
        if ($langEn < 2){
            return view('contact')->with('contact',$contact);
        }else{
            return view('contact-ar')->with('contact',$contact);
        }

    }else{


        return view('license_expired');
          
    
      }


  
        
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Setting  $setting
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
            //
            if (Auth::user()->id === 1) {
            $sett = Setting::find($id);
            return view('admin.setting.edit')->with('sett',$sett);

            } else {

            return redirect(url('home'));

            }
     
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Setting  $setting
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
  
        if (Auth::user()->id === 1) {
        $idst = 1;
        // THIS UPDATE POST لتعديل المنشور

        $this->validate($request,[
            'logo'=>'image|mimes:jpeg,png,jpg,gif,svg|max:900000000',
            'title'=>'string|max:255',
            'about'=>'string|max:500',
            'email'=>'string|max:255',
            'address'=>'string|max:255',
            'phone'=>'string|max:255',
            'facebook'=>'string|max:255',
            'youtube'=>'string|max:255',
            'twitter'=>'string|max:255',
            'web'=>'string|max:255',
            'app_ip'=>'string|max:255',
            'app_android'=>'string|max:255',
            'app_ios'=>'string|max:255',
            // 'status'=>'string|max:255',
            
        ]);

        if (!empty($request->hasFile('logo'))){

            $fileObject = $request->file('logo');
            $extension = $fileObject->getClientOriginalExtension();
            $mimeTypy = $fileObject->getClientMimeType();
            $fileName = $fileObject->getClientOriginalName();
            $size = $fileObject->getClientSize();
            $name_logo =  'logo'.time().'.'.$extension;
            $path_image = $fileObject->storeAs('public/upload',$name_logo);

            $nes = Setting::find($idst);
            $nes->logo = $name_logo;
            if (empty($request->input('status'))){
                $nes->status = 1; 
            }else{
                $nes->status = $request->input('status');
            }
            $nes->title = $request->input('title');
            $nes->about = $request->input('about');
            $nes->email = $request->input('email');
            $nes->address = $request->input('address');
            $nes->phone = $request->input('phone');
            $nes->facebook = $request->input('facebook');
            $nes->youtube = $request->input('youtube');
            $nes->twitter = $request->input('twitter');
            $nes->web = $request->input('web');
            $nes->app_ip = $request->input('app_ip');
            $nes->app_android = $request->input('app_android');
            $nes->app_ios = $request->input('app_ios');
            $nes->save();
            
            return redirect()->back();   

            
        }


        if (empty($request->input('status'))){

            $nes = Setting::find($idst);
            $nes->status = 1;
            $nes->title = $request->input('title');
            $nes->about = $request->input('about');
            $nes->email = $request->input('email');
            $nes->address = $request->input('address');
            $nes->phone = $request->input('phone');
            $nes->facebook = $request->input('facebook');
            $nes->youtube = $request->input('youtube');
            $nes->twitter = $request->input('twitter');
            $nes->web = $request->input('web');
            $nes->app_ip = $request->input('app_ip');
            $nes->app_android = $request->input('app_android');
            $nes->app_ios = $request->input('app_ios');
            $nes->save();
            return redirect()->back();  
        }else{

            $nes = Setting::find($idst);
            $nes->status = $request->input('status');
            $nes->title = $request->input('title');
            $nes->about = $request->input('about');
            $nes->email = $request->input('email');
            $nes->address = $request->input('address');
            $nes->phone = $request->input('phone');
            $nes->facebook = $request->input('facebook');
            $nes->youtube = $request->input('youtube');
            $nes->twitter = $request->input('twitter');
            $nes->web = $request->input('web');
            $nes->app_ip = $request->input('app_ip');
            $nes->app_android = $request->input('app_android');
            $nes->app_ios = $request->input('app_ios');
            $nes->save();
            return redirect()->back(); 

        }





    } else {

        return redirect(url('home'));

    }


    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Setting  $setting
     * @return \Illuminate\Http\Response
     */
    public function destroy(Setting $setting)
    {
        //
    }
}
