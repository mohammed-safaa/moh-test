<?php

namespace App\Http\Controllers;
use App\Http\Requests\PidnRequest;
use App\Admin\Pidn;
use App\Admin\Defense;
use Illuminate\Http\Request;

class PidnController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
       
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(PidnRequest $request)
    {
        //
    
        
        
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Admin\Pidn  $pidn
     * @return \Illuminate\Http\Response
     */
    public function show(Pidn $pidn)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Admin\Pidn  $pidn
     * @return \Illuminate\Http\Response
     */
    public function edit(Pidn $pidn)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Admin\Pidn  $pidn
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Pidn $pidn)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Admin\Pidn  $pidn
     * @return \Illuminate\Http\Response
     */
    public function destroy(Pidn $pidn)
    {
        //
    }
}
