<?php

namespace App\Http\Controllers;

use App\Comment;
use Illuminate\Http\Request;
use App\Http\Requests\CommentRequest;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class CommentController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(CommentRequest $request,$id)
    {
        //اضافة تعليق add comment

                
                    $cons= new Comment();
                    $cons->comment= $request->input('comment');
                    $cons->user_id = Auth::user()->id;
                    $cons->post_id = $id;
                    $cons->save();
             
               
        
               return redirect()->back();
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Comment  $comment
     * @return \Illuminate\Http\Response
     */
    public function show(Comment $comment)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Comment  $comment
     * @return \Illuminate\Http\Response
     */

    public function edit($id)
    {
        //
               // $profile = User::all();
               $profile = DB::select('SELECT `posts`.* , users.* FROM `posts` INNER JOIN users ON `posts`.user_id = users.id WHERE `posts`.id = $id');
               return view ('post.profile')->with('profile',$profile);
    }

    public function editget($id)
    {
        //
               // $profile = User::all();
               $profile = DB::select('SELECT `posts`.* , users.* FROM `posts` INNER JOIN users ON `posts`.user_id = users.id WHERE `posts`.id = $id');
               return view ('post.profile')->with('profile',$profile);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Comment  $comment
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Comment $comment)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Comment  $comment
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $del = Comment::find($id);
        // delete database لحذف من قاعدة البيانات 
        $del->destroy($id);
        return back()->withInput();
    }
}
