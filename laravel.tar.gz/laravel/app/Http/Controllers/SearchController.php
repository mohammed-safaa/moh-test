<?php

namespace App\Http\Controllers;
use App\Sos;
use App\Post;
use App\Search;
use App\Admin\Defense;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Input;

class SearchController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        if (Auth::user()->id === 1) {

        $allsearch = Search::orderBy('id', 'DESC')->get();
        return view('admin.search.list', ['allsearch' => $allsearch]);
        
    } else {

        return redirect(url('home'));

    }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //

    
    }


    public function search()
    {
        $license = Defense::orderByRaw('id DESC')->limit(1)->get();
        foreach ($license as $value) {
          $createdsos = $value->created_at ;
          $showDaysos = $value->show_days ;
      }
  
      $created_atsos = date_create($createdsos);
      $DateTime1sos = date_format($created_atsos,"d-m-Y");
  
      $datePlus = date( "d-m-Y", strtotime( "$DateTime1sos +$showDaysos days" ) );
  
      $d1sos=strtotime($datePlus);
      $d2sos=ceil(($d1sos-time())/60/60/24);
  
  
      if($d2sos > 0){
          
        $uid = Auth::user()->id;
        $userLang = DB::table('users')->where('id', $uid)->get();
         
        foreach ($userLang as $value) {
            $langEn = $value->lang ;
           
        }

          
        if ($langEn < 2){
            $search_input = Input::get ( 'search' );
            $search = Post::where('title','LIKE','%'.$search_input.'%')->orWhere('category','LIKE','%'.$search_input.'%')->get();
        
            $searchcak = DB::table('searches')
            ->where('Search', $search_input)
            ->where('user_id', Auth::user()->id)
            ->first();
    
            if(!$searchcak){
                $pos = new Search();
                $pos->Search = $search_input;
                $pos->user_id = Auth::user()->id;
                $pos->save();
            }
    
        
            if(count($search) > 0){
                return view('post.search')->withDetails($search)->withQuery ( $search_input );
            }else{
                return view ('post.notfound')->withMessage('No Details found. Try to search again !');
            } 
            
        }else{

            $search_input = Input::get ( 'search' );
            $search = Post::where('title','LIKE','%'.$search_input.'%')->orWhere('category','LIKE','%'.$search_input.'%')->get();
        
            $searchcak = DB::table('searches')
            ->where('Search', $search_input)
            ->where('user_id', Auth::user()->id)
            ->first();
    
            if(!$searchcak){
                $pos = new Search();
                $pos->Search = $search_input;
                $pos->user_id = Auth::user()->id;
                $pos->save();
            }
    
        
            if(count($search) > 0){
                return view('post.search-ar')->withDetails($search)->withQuery ( $search_input );
            }else{
                return view ('post.notfound')->withMessage('No Details found. Try to search again !');
            }
             

        }



    }else{


        return view('license_expired');
          
    
      }



    }

    public function fatchsearch()
    {
        //
        $fatchsearch = DB::table('searches')
        ->where('user_id', Auth::user()->id)
        ->first();
        return view('layouts.app', ['fatchsearch' => $fatchsearch]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Search  $search
     * @return \Illuminate\Http\Response
     */
    public function show(Search $search)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Search  $search
     * @return \Illuminate\Http\Response
     */
    public function edit(Search $search)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Search  $search
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Search $search)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Search  $search
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $Searchdel = Search::find($id);
        $Searchdel->destroy($id);
        return redirect(url('search'));
    }
}
