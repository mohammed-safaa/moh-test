<?php

namespace App\Http\Controllers;

use App\Like;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Post;
use Illuminate\Support\Facades\Storage;
use App\Viewpost;
use Illuminate\Support\Facades\DB;

class LikeController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index($id)
    {
        //
        $likes = Like::find($id);
        return view('post.watch',compact('likes'));

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    public function like(Request $request)
    {
        //
        $like_s = $request->like_s;
        $post_id = $request->post_id;

        $like = DB::table('likes')
        ->where('post_id', $post_id)
        ->where('user_id', Auth::user()->id)
        ->first();

        if(!$like)
        {
        $new_like = new Like();
        $new_like->post_id = $post_id;
        $new_like->user_id =Auth::user()->id;
        $new_like->like = 1;
        $new_like->save();
        $is_like = 1;
        }

        elseif ($like->like == 1) {
            # like
            DB::table('likes')
            ->where('post_id', $post_id)
            ->where('user_id', Auth::user()->id)
            ->delete();
            $is_like = 0;
        }
        elseif ($like->like == 0) {
            # dislike
            DB::table('likes')
            ->where('post_id', $post_id)
            ->where('user_id', Auth::user()->id)
            ->update(['like' => 1]);
            $is_like = 1;
        }

        $response = array(
        'is_like' => $is_like,
        );

        return response()->json($response , 200);

return redirect()->route('profile', ['id' => 1]);
    }

    public function dislike(Request $request)
    {
        //
        $like_s = $request->like_s;
        $post_id = $request->post_id;

        $dislike = DB::table('likes')
        ->where('post_id', $post_id)
        ->where('user_id', Auth::user()->id)
        ->first();

        if(!$dislike)
        {
        $new_dislike = new Like();
        $new_dislike->post_id = $post_id;
        $new_dislike->user_id =Auth::user()->id;
        $new_dislike->like = 0;
        $new_dislike->save();
        $is_dislike = 1;
        }

        elseif ($dislike->like == 0) {
            # like
            DB::table('likes')
            ->where('post_id', $post_id)
            ->where('user_id', Auth::user()->id)
            ->delete();
            $is_dislike = 0;
        }
        elseif ($dislike->like == 1) {
            # dislike
            DB::table('likes')
            ->where('post_id', $post_id)
            ->where('user_id', Auth::user()->id)
            ->update(['like' => 0]);
            $is_dislike = 1;
        }






        $response = array(
        'is_dislike' => $is_dislike,
        );

        return response()->json($response , 200);
        
       
      

        
    }
   


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Like  $like
     * @return \Illuminate\Http\Response
     */
    public function show(Like $like)
    {
        //
        
    }

 
    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Like  $like
     * @return \Illuminate\Http\Response
     */
    public function edit(Like $like)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Like  $like
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Like $like)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Like  $like
     * @return \Illuminate\Http\Response
     */
    public function destroy(Like $like)
    {
        //
    }
}
