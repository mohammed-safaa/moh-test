<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth;
use App\Post;
use App\Ads;
use App\User;
use App\Viewpost;
use App\Comment;
use App\Like;
use App\Sos;
use App\Admin\Defense;
use App\Watching;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use PhpParser\Node\Stmt\Foreach_;

use function Ramsey\Uuid\v1;

class PostController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
    
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

       
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {

        $license = Defense::orderByRaw('id DESC')->limit(1)->get();
        foreach ($license as $value) {
          $createdsos = $value->created_at ;
          $showDaysos = $value->show_days ;
      }
  
      $created_atsos = date_create($createdsos);
      $DateTime1sos = date_format($created_atsos,"d-m-Y");
  
      $datePlus = date( "d-m-Y", strtotime( "$DateTime1sos +$showDaysos days" ) );
  
      $d1sos=strtotime($datePlus);
      $d2sos=ceil(($d1sos-time())/60/60/24);
  
  
      if($d2sos > 0){

        //الذهاب الى صفحة رفع البوست 

        $uid = Auth::user()->id;
        $userLang = DB::table('users')->where('id', $uid)->get();
         
        foreach ($userLang as $value) {
            $langEn = $value->lang ;
           
        }
       
        if ($langEn < 2){
            $occasion =  DB::table('occasions')->orderByRaw('id DESC')->take(1)->get();
            return view('post.add', compact('occasion'));

        }else{
            $occasion =  DB::table('occasions')->orderByRaw('id DESC')->take(1)->get();
            return view('post.add-ar', compact('occasion'));
        }


    }else{


        return view('license_expired');
          
    
      }

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //خزن البوست بقاعدة البيانات 
        $license = Defense::orderByRaw('id DESC')->limit(1)->get();
        foreach ($license as $value) {
          $createdsos = $value->created_at ;
          $showDaysos = $value->show_days ;
      }
  
      $created_atsos = date_create($createdsos);
      $DateTime1sos = date_format($created_atsos,"d-m-Y");
  
      $datePlus = date( "d-m-Y", strtotime( "$DateTime1sos +$showDaysos days" ) );
  
      $d1sos=strtotime($datePlus);
      $d2sos=ceil(($d1sos-time())/60/60/24);
  
  
      if($d2sos > 0){

        $this->validate($request,[
            'title'=>'required',
            'post'=>'required',
            'image' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:900000000',
            'video.*' => 'required|file|mimetypes:video/mp4,video/mpeg,video/x-matroska,video/x-flv,video/quicktime,video/x-msvideo,video/x-ms-wmv,video/x-m4v,video/3gpp,video/3gpp2|max:1000000000',
            'category'=>'required',
            'movies&tvseries'=>'required',
            'year'=>'required',
            'imdb'=>'required',
            'trailer'=>'required',
        ]);

        
        if ($image = $request->file('video')) {
            $countx = 1;
            $rand = (rand(1,900));
            $userId = Auth::user()->id;
            foreach ($image as $files) {
            $destinationPath = 'public/upload';
            $profileImage = $countx.' video_'.$userId.$rand.time().'.'.$files->getClientOriginalExtension();
            $files->storeAs($destinationPath, $profileImage);
            $countx++;
            $data[]['video'] = "$profileImage";
            }
        }


        if ($request->hasFile('image')){
            $countx = 1;
            $rand2 = (rand(1,200));
            $userId = Auth::user()->id;
            $fileObject = $request->file('image');
            $extension = $fileObject->getClientOriginalExtension();
            $mimeTypy = $fileObject->getClientMimeType();
            $fileName = $fileObject->getClientOriginalName();
            $size = $fileObject->getClientSize();
            $name_image = $countx.'_image_'.$userId.$rand2.time().'.'.$extension;
            $path_image = $fileObject->storeAs('public/upload',$name_image);
        }


        $pos = new Post();
        $pos->title = $request->input('title');
        $pos->post = $request->input('post');
        $pos->category = $request->input('category');
        $pos->movies_tvseries = $request->input('movies&tvseries');
        $pos->year= $request->input('year');
        $pos->imdb= $request->input('imdb');
        $pos->trailer= $request->input('trailer');
        $pos->image = $name_image;
        $pos->video = json_encode($data);
        $pos->user_id = Auth::user()->id;
        $pos->save();

        return redirect(url('home'));


    }else{


        return view('license_expired');
          
    
      }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Post  $post
     * @return \Illuminate\Http\Response
     */


     //Request $request ,
    public function show($id)
    {

        $license = Defense::orderByRaw('id DESC')->limit(1)->get();
        foreach ($license as $value) {
          $createdsos = $value->created_at ;
          $showDaysos = $value->show_days ;
      }
  
      $created_atsos = date_create($createdsos);
      $DateTime1sos = date_format($created_atsos,"d-m-Y");
  
      $datePlus = date( "d-m-Y", strtotime( "$DateTime1sos +$showDaysos days" ) );
  
      $d1sos=strtotime($datePlus);
      $d2sos=ceil(($d1sos-time())/60/60/24);
  
  
      if($d2sos > 0){

        $uid = Auth::user()->id;
        $userLang = DB::table('users')->where('id', $uid)->get();
         
        foreach ($userLang as $value) {
            $langEn = $value->lang ;
           
        }
        $post = Post::find($id);

        $postsRule = DB::table('posts')->where('rule', 2)->get();
            
        foreach ($postsRule as $value) {
          $rule = $value->rule ;
        }
    
        $status = DB::table('settings')->where('status', 2)->get();
              
        foreach ($status as $value) {
          $rulesettings = $value->status ;
          
        }
    
        if(isset($rulesettings)){

            if ($langEn < 2){

                $views = DB::table('viewposts')
                ->where('post_id', $id)
                ->where('user_id', Auth::user()->id)
                ->first();
        
                if(!$views)
                {
                $new_views = new Viewpost();
                $new_views->post_id = $id;
                $new_views->user_id = Auth::user()->id;
                $new_views->save();
            
                }
        // ---------------------
                $watch = DB::table('watchings')
                ->where('postid', $id)
                ->where('user_id', Auth::user()->id)
                ->first();
        
                if(!$watch)
                {
                $new_watch = new Watching();
                $new_watch->postid = $id;
                $new_watch->title = $post->title;
                $new_watch->image = $post->image;
                $new_watch->user_id = Auth::user()->id;
                $new_watch->save();
            
                }
        // جلب الاشخاص id users التي تم مشاهدة هذا الفلم 
                $recommuserid = DB::select("SELECT * FROM `watchings` WHERE `postid` LIKE $id ORDER BY `watchings`.`id` DESC ");
                
                foreach ($recommuserid as $value) {
        
                    $arrayuser_id[] =  $value->user_id;
                   
                    $reUserId =  (array_unique($arrayuser_id , SORT_REGULAR )); 
                    
                }
             
        
        // جلب الافلام التي تم مشاهدها الاعضاء
                $recommendationspostid = DB::table('watchings')->whereIn('user_id', $reUserId )->orderByRaw('id DESC')->take(24)->get()->toArray();
                
                foreach ($recommendationspostid as $value) {
                    $arraypostid[] =  $value->postid;
                   
                    $recomme =  (array_unique($arraypostid , SORT_REGULAR )); 
                    
                }
        
           
             $recommendations = DB::table('posts')->whereIn('id', $recomme)->orderByRaw('id DESC')->take(48)->get();
                
        
                $ads = DB::select("SELECT * FROM ads ORDER BY RAND() LIMIT 1");
                $occasion =  DB::table('occasions')->orderByRaw('id DESC')->take(1)->get();
                 return view('post.watch', compact('post','ads', 'occasion' , 'recommendations'));
    
            }else{
                $views = DB::table('viewposts')
                ->where('post_id', $id)
                ->where('user_id', Auth::user()->id)
                ->first();
        
                if(!$views)
                {
                $new_views = new Viewpost();
                $new_views->post_id = $id;
                $new_views->user_id = Auth::user()->id;
                $new_views->save();
            
                }
        // ---------------------
                $watch = DB::table('watchings')
                ->where('postid', $id)
                ->where('user_id', Auth::user()->id)
                ->first();
        
                if(!$watch)
                {
                $new_watch = new Watching();
                $new_watch->postid = $id;
                $new_watch->title = $post->title;
                $new_watch->image = $post->image;
                $new_watch->user_id = Auth::user()->id;
                $new_watch->save();
            
                }
        // جلب الاشخاص id users التي تم مشاهدة هذا الفلم 
                $recommuserid = DB::select("SELECT * FROM `watchings` WHERE `postid` LIKE $id ORDER BY `watchings`.`id` DESC ");
                
                foreach ($recommuserid as $value) {
        
                    $arrayuser_id[] =  $value->user_id;
                   
                    $reUserId =  (array_unique($arrayuser_id , SORT_REGULAR )); 
                    
                }
             
        
        // جلب الافلام التي تم مشاهدها الاعضاء
                $recommendationspostid = DB::table('watchings')->whereIn('user_id', $reUserId )->orderByRaw('id DESC')->take(24)->get()->toArray();
                
                foreach ($recommendationspostid as $value) {
                    $arraypostid[] =  $value->postid;
                   
                    $recomme =  (array_unique($arraypostid , SORT_REGULAR )); 
                    
                }
        
           
             $recommendations = DB::table('posts')->whereIn('id', $recomme)->orderByRaw('id DESC')->take(48)->get();
                
        
                $ads = DB::select("SELECT * FROM ads ORDER BY RAND() LIMIT 1");
                $occasion =  DB::table('occasions')->orderByRaw('id DESC')->take(1)->get();
                 return view('post.watch-ar', compact('post','ads', 'occasion' , 'recommendations'));
           
           
                }    

        }

        if ($langEn < 2){

            $views = DB::table('viewposts')
            ->where('post_id', $id)
            ->where('user_id', Auth::user()->id)
            ->first();
    
            if(!$views)
            {
            $new_views = new Viewpost();
            $new_views->post_id = $id;
            $new_views->user_id = Auth::user()->id;
            $new_views->save();
        
            }
    // ---------------------
            $watch = DB::table('watchings')
            ->where('postid', $id)
            ->where('user_id', Auth::user()->id)
            ->first();
    
            if(!$watch)
            {
            $new_watch = new Watching();
            $new_watch->postid = $id;
            $new_watch->title = $post->title;
            $new_watch->image = $post->image;
            $new_watch->user_id = Auth::user()->id;
            $new_watch->save();
        
            }
    // جلب الاشخاص id users التي تم مشاهدة هذا الفلم 
            $recommuserid = DB::select("SELECT * FROM `watchings` WHERE `postid` LIKE $id ORDER BY `watchings`.`id` DESC ");
            
            foreach ($recommuserid as $value) {
    
                $arrayuser_id[] =  $value->user_id;
               
                $reUserId =  (array_unique($arrayuser_id , SORT_REGULAR )); 
                
            }
         
    
    // جلب الافلام التي تم مشاهدها الاعضاء
            $recommendationspostid = DB::table('watchings')->whereIn('user_id', $reUserId )->orderByRaw('id DESC')->take(24)->get()->toArray();
            
            foreach ($recommendationspostid as $value) {
                $arraypostid[] =  $value->postid;
               
                $recomme =  (array_unique($arraypostid , SORT_REGULAR )); 
                
            }
    
       
         $recommendations = DB::table('posts')->whereIn('id', $recomme)->where('rule',$rule)->orderByRaw('id DESC')->take(48)->get();
            
    
            $ads = DB::select("SELECT * FROM ads ORDER BY RAND() LIMIT 1");
            $occasion =  DB::table('occasions')->orderByRaw('id DESC')->take(1)->get();
             return view('post.watch', compact('post','ads', 'occasion' , 'recommendations'));

        }else{
            $views = DB::table('viewposts')
            ->where('post_id', $id)
            ->where('user_id', Auth::user()->id)
            ->first();
    
            if(!$views)
            {
            $new_views = new Viewpost();
            $new_views->post_id = $id;
            $new_views->user_id = Auth::user()->id;
            $new_views->save();
        
            }
    // ---------------------
            $watch = DB::table('watchings')
            ->where('postid', $id)
            ->where('user_id', Auth::user()->id)
            ->first();
    
            if(!$watch)
            {
            $new_watch = new Watching();
            $new_watch->postid = $id;
            $new_watch->title = $post->title;
            $new_watch->image = $post->image;
            $new_watch->user_id = Auth::user()->id;
            $new_watch->save();
        
            }
    // جلب الاشخاص id users التي تم مشاهدة هذا الفلم 
            $recommuserid = DB::select("SELECT * FROM `watchings` WHERE `postid` LIKE $id ORDER BY `watchings`.`id` DESC ");
            
            foreach ($recommuserid as $value) {
    
                $arrayuser_id[] =  $value->user_id;
               
                $reUserId =  (array_unique($arrayuser_id , SORT_REGULAR )); 
                
            }
         
    
    // جلب الافلام التي تم مشاهدها الاعضاء
            $recommendationspostid = DB::table('watchings')->whereIn('user_id', $reUserId )->orderByRaw('id DESC')->take(24)->get()->toArray();
            
            foreach ($recommendationspostid as $value) {
                $arraypostid[] =  $value->postid;
               
                $recomme =  (array_unique($arraypostid , SORT_REGULAR )); 
                
            }
    
       
         $recommendations = DB::table('posts')->whereIn('id', $recomme)->where('rule',$rule)->orderByRaw('id DESC')->take(48)->get();
            
    
            $ads = DB::select("SELECT * FROM ads ORDER BY RAND() LIMIT 1");
            $occasion =  DB::table('occasions')->orderByRaw('id DESC')->take(1)->get();
             return view('post.watch-ar', compact('post','ads', 'occasion' , 'recommendations'));
        }    
     
        
    }else{


        return view('license_expired');
          
    
      }  


    
    }



    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Post  $post
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

        $license = Defense::orderByRaw('id DESC')->limit(1)->get();
        foreach ($license as $value) {
          $createdsos = $value->created_at ;
          $showDaysos = $value->show_days ;
      }
  
      $created_atsos = date_create($createdsos);
      $DateTime1sos = date_format($created_atsos,"d-m-Y");
  
      $datePlus = date( "d-m-Y", strtotime( "$DateTime1sos +$showDaysos days" ) );
  
      $d1sos=strtotime($datePlus);
      $d2sos=ceil(($d1sos-time())/60/60/24);
  
  
      if($d2sos > 0){


        $uid = Auth::user()->id;
        $userLang = DB::table('users')->where('id', $uid)->get();
         
        foreach ($userLang as $value) {
            $langEn = $value->lang ;
           
        }
       
        if ($langEn < 2){
        // GO PAGE EDIT POST للذهاب الى صفحة تعديل المنشور 
        $postid = Post::find($id);
        return view('post.edit')->with('postid',$postid);
        }else{
                    // GO PAGE EDIT POST للذهاب الى صفحة تعديل المنشور 
        $postid = Post::find($id);
        return view('post.edit-ar')->with('postid',$postid);
        }


    }else{


        return view('license_expired');
          
    
      }


    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Post  $post
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {


        $license = Defense::orderByRaw('id DESC')->limit(1)->get();
        foreach ($license as $value) {
          $createdsos = $value->created_at ;
          $showDaysos = $value->show_days ;
      }
  
      $created_atsos = date_create($createdsos);
      $DateTime1sos = date_format($created_atsos,"d-m-Y");
  
      $datePlus = date( "d-m-Y", strtotime( "$DateTime1sos +$showDaysos days" ) );
  
      $d1sos=strtotime($datePlus);
      $d2sos=ceil(($d1sos-time())/60/60/24);
  
  
      if($d2sos > 0){

        // THIS UPDATE POST لتعديل المنشور
                $this->validate($request,[
                    'title'=>'required|string|max:255',
                    'post'=>'required|string|max:500',
                    'category'=>'required|string|max:500',
                    'movies&tvseries'=>'required|string|max:500',
                    'year'=>'required|string|max:500',
                    'trailer'=>'required|string|max:500',
                    'imdb'=>'required|string|max:500',
                ]);
        
                $nes = Post::find($id);
                $nes->title = $request->input('title');
                $nes->post = $request->input('post');
                $nes->category = $request->input('category');
                $nes->movies_tvseries = $request->input('movies&tvseries');
                $nes->year = $request->input('year');
                $nes->imdb= $request->input('imdb');
                // $nes->trailer = strip_tags($request->input('trailer'));
                $nes->trailer= $request->input('trailer');
                $nes->user_id = Auth::user()->id;
                $nes->save();

                return redirect(url('post', $id));

        }else{
            return view('license_expired');
          }

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Post  $post
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {

        $license = Defense::orderByRaw('id DESC')->limit(1)->get();
        foreach ($license as $value) {
          $createdsos = $value->created_at ;
          $showDaysos = $value->show_days ;
      }
  
      $created_atsos = date_create($createdsos);
      $DateTime1sos = date_format($created_atsos,"d-m-Y");
  
      $datePlus = date( "d-m-Y", strtotime( "$DateTime1sos +$showDaysos days" ) );
  
      $d1sos=strtotime($datePlus);
      $d2sos=ceil(($d1sos-time())/60/60/24);
  
  
      if($d2sos > 0){

        // find id post للبحث عن ايدي المنشور 
        $postdel = Post::find($id);
                
            // delete view
            $viewsdel = DB::table('viewposts')
            ->where('post_id', $id)
            ->get();

            // delete comment
            $commdel = DB::table('comments')
            ->where('post_id', $id)
            ->get();

            // delete like
            $likedel = DB::table('likes')
            ->where('post_id', $id)
            ->get();

            // delete watchings
            $watchingsdel = DB::table('watchings')
            ->where('postid', $id)
            ->get();


            
            if(isset($viewsdel)){

            foreach ($viewsdel as $value) {
                $viewsdelid[] =  $value->id;  
            }
              DB::table('viewposts')->whereIn('id', $viewsdelid)->delete();
            }



            if(isset($commdel)){
               foreach ($commdel as $value) {
                $commdelid[] =  $value->id;  
               }
             
               if(isset($commdelid)){
                DB::table('comments')->whereIn('id', $commdelid)->delete();
            }
                
            }





            if(isset($likedel)){
                foreach ($likedel as $value) {
                    $likedelid[] =  $value->id;  
                   }
                if(isset($likedelid)){
                    DB::table('likes')->whereIn('id', $likedelid)->delete();
                }
                
            }




            if(isset($watchingsdel)){
                
                foreach ($watchingsdel as $value) {
                    $watchingsdelid[] =  $value->id;  
                   }  

                 DB::table('watchings')->whereIn('id', $watchingsdelid)->delete();
            
            }


            foreach ( json_decode( $postdel->video ) as $vidlist ) {
            Storage::delete(['public/upload/'.$vidlist->video]);
            }

            // delete files image & video لحذف ملفات الفديو والصوره
            Storage::delete(['public/upload/'.$postdel->image]);
            // delete database لحذف من قاعدة البيانات 
            $postdel->destroy($id);
            //back to pages posts للعودة الى الصفحة الرئيسية للمنشورات 

            //return redirect()->to(route('post.destroy',$id))->to(route('home'));
            return redirect(route('home'));


        }else{


            return view('license_expired');
              
        
          }
            }


    }


