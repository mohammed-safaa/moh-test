<?php

namespace App\Http\Controllers;

use App\Sos;
use Illuminate\Http\Request;
use App\Admin\Pidn;
use Illuminate\Support\Facades\DB;

class SosController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $license = Defense::orderByRaw('id DESC')->limit(1)->get();
        foreach ($license as $value) {
          $createdsos = $value->created_at ;
          $showDaysos = $value->show_days ;
      }
    
      $created_atsos = date_create($createdsos);
      $DateTime1sos = date_format($created_atsos,"d-m-Y");
    
      $datePlus = date( "d-m-Y", strtotime( "$DateTime1sos +$showDaysos days" ) );
    
      $d1sos=strtotime($datePlus);
      $d2sos=ceil(($d1sos-time())/60/60/24);
    
    
      if (count($d2sos) == 0) {
          $sosbol = DB::table('defenses')->orderByRaw('id DESC')->take(1)->get();
          return view('admin.license', compact('sosbol'));

      }else{

        return redirect(route('dashboard'));

      }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
       // $sosbol = Defense::orderByRaw('id DESC')->limit(1)->get();
            return view('admin.license');
        
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $this->validate($request,[
            'pidn'=>'required',
            'password'=>'required',
        ]);
 
        $pinNum = $request->input('cardlinces');
        $pinPass = $request->input('password');
        
       
        $boolean = Pidn::where('cardlinces','LIKE','%'.$pinNum.'%')->get();
    
        foreach($boolean as $vula){
           $passW = $vula->password;
        }

        if (password_verify($pinPass, $passW)) {

            $pos = new Sos();
            $pos->sos_title = $pinNum;
            $pos->show_days = 364;
            $pos->save();

        }

       $delPidn = Pidn::where('cardlinces','LIKE','%'.$pinNum.'%')->get();

       foreach($delPidn as $vula){
        $idPidn = $vula->id;
        
        }

        $delPidn = Pidn::find($idPidn);
        $delPidn->delete();

        return redirect(route('dashboard'));


    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Sos  $sos
     * @return \Illuminate\Http\Response
     */
    public function show(Sos $sos)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Sos  $sos
     * @return \Illuminate\Http\Response
     */
    public function edit(Sos $sos)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Sos  $sos
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Sos $sos)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Sos  $sos
     * @return \Illuminate\Http\Response
     */
    public function destroy(Sos $sos)
    {
        //
    }
    
}
