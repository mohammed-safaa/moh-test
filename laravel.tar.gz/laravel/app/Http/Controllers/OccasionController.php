<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth;
use App\Occasion;
use App\Admin\Defense;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
class OccasionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        if (Auth::user()->id === 1) {

        $occ = Occasion::orderBy('id', 'DESC')->get();
        return view('admin.occasions.list', compact('occ'));

    } else {

        return redirect(url('home'));

    }
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        if (Auth::user()->id === 1) {
        return view('admin.occasions.add');
    } else {

        return redirect(url('home'));

    }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
      
        //
        if (Auth::user()->id === 1) {

        $this->validate($request,[
        'occasion_title'=>'required',
        'occasion_about'=>'required',
        'show_days'=>'required',
        'image' => 'image|mimes:jpeg,png,jpg,gif,svg|max:300000',


        ]);


        if ($request->hasFile('image')){
        $fileObject = $request->file('image');
        $extension = $fileObject->getClientOriginalExtension();
        $mimeTypy = $fileObject->getClientMimeType();
        $fileName = $fileObject->getClientOriginalName();
        $size = $fileObject->getClientSize();
        $name_image = $request->input('occasions_title').'IMG-Occ_'.time().'.'.$extension;
        $path_image = $fileObject->storeAs('public/upload',$name_image);
        }else{
        $name_image = '';
        }


        $ads = new Occasion();
        $ads->occasion_title = $request->input('occasion_title');
        $ads->occasion_about = $request->input('occasion_about');
        $ads->show_days = $request->input('show_days');
        $ads->image = $name_image;
        $ads->save();

        return redirect(route('occ.index'));

    } else {

        return redirect(url('home'));

    }

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Occasion  $occasion
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        $license = Defense::orderByRaw('id DESC')->limit(1)->get();
        foreach ($license as $value) {
          $createdsos = $value->created_at ;
          $showDaysos = $value->show_days ;
      }
  
      $created_atsos = date_create($createdsos);
      $DateTime1sos = date_format($created_atsos,"d-m-Y");
  
      $datePlus = date( "d-m-Y", strtotime( "$DateTime1sos +$showDaysos days" ) );
  
      $d1sos=strtotime($datePlus);
      $d2sos=ceil(($d1sos-time())/60/60/24);
  
  
      if($d2sos > 0){


        $occh = Occasion::find($id);
        $uid = Auth::user()->id;
        $userLang = DB::table('users')->where('id', $uid)->get();
         
        foreach ($userLang as $value) {
            $langEn = $value->lang ; 
        }
        
        if ($langEn < 2){
            
            return view('occasions.watch')->with('occh',$occh);
        }else{
           
            return view('occasions.watch-ar')->with('occh',$occh);
        }

    }else{


        return view('license_expired');
          
    
      }

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Occasion  $occasion
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        if (Auth::user()->id === 1) {

        $occid = Occasion::find($id);
        return view('admin.occasions.edit')->with('occid',$occid);

    } else {

        return redirect(url('home'));

    }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Occasion  $occasion
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
       //
       if (Auth::user()->id === 1) {

        $this->validate($request,[
        'occasion_title'=>'required',
        'occasion_about'=>'required',
        'show_days'=>'required',
        ]);


        $ads = Occasion::find($id);
        $ads->occasion_title = $request->input('occasion_title');
        $ads->occasion_about = $request->input('occasion_about');
        $ads->show_days = $request->input('show_days');
        $ads->save();

        return redirect(route('occ.index'));

    } else {

        return redirect(url('home'));

    }

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Occasion  $occasion
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        if (Auth::user()->id === 1) {

        $occdel = Occasion::find($id);
        Storage::delete(['public/upload/'.$occdel->image]);
        $occdel->destroy($id);
        return redirect(route('occ.index'));

    } else {

        return redirect(url('home'));

    }
    }
}
