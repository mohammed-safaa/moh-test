<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ads extends Model
{
    //
    public function posts()
    {
        return $this->belongsTo('App\Post');
    }
}
