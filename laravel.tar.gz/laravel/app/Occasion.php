<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Occasion extends Model
{
    //

    public $table = "occasions";

    public function posts()
    {
        return $this->belongsTo('App\Post');
    }

    public function user()
    {
      return $this->belongsTo('App\User');
    }



}
