
$(document).ready(function(){
    $("#like").on('click', function(){
      //
      var like_s = $(this).attr('data-like');
      var post_id = $(this).attr('data-postid');
      post_id = post_id.slice(0,-2);
    //  alert(like_s);
      $.ajax({
      type: 'POST',
      url: url,
      data: { like_s: like_s, post_id: post_id , _token: token },
      success: function(data){
    // alert(data.is_like);
      //  عمل رفريش للصفحة 
    location.reload();
      
      if(data.$is_like == 1){

      $('*[data-postid="'+ post_id +'_l"]').removeClass('btn btn-secondary').addClass('btn btn-success');
      $('*[data-postid="'+ post_id +'_d"]').removeClass('btn btn-danger').addClass('btn btn-secondary');
      var cu_like = $('*[data-postid="'+ post_id +'_l"]').find('.like_count').text();
      var post_id = parseInt(cu_like) +1;
      $('*[data-postid="'+ post_id +'_l"]').find('.like_count').text(new_like);
      }

      if(data.$is_like == 0){
      $('*[data-postid="'+ post_id +'_l"]').removeClass('btn btn-success').addClass('btn btn-secondary');
      $('*[data-postid="'+ post_id +'_d"]').removeClass('btn btn-danger').addClass('btn btn-secondary');
      }

      }
      
      })

      });
  });



    // dislike script
    $(document).ready(function(){
    $("#dislike").on('click', function(){
        var like_s = $(this).attr('data-like');
        var post_id = $(this).attr('data-postid');
        post_id = post_id.slice(0,-2);
                     //alert(news_id);
             $.ajax({
                 type: 'POST',
                 url: url_dis,
                 data: { like_s: like_s, post_id: post_id , _token: token },
                 
                 success: function(data){
                    //  عمل رفريش للصفحة 
                    location.reload();
                    // alert(data.is_dislike);
                     if(data.$is_dislike == 1)
                     {
                     $('*[data-postid="'+ post_id +'_d"]').removeClass('btn btn-success').addClass('btn btn-danger');
                     $('*[data-postid="'+ post_id +'_l"]').removeClass('btn btn-secondary').addClass('btn btn-success');
                     var cu_like = $('*[data-postid="'+ post_id +'_d"]').find('.like_count').text();
                     var post_id = parseInt(cu_like) +1;
                     $('*[data-postid="'+ post_id +'_d"]').find('.like_count').text(new_like);
                    }
 
                     if(data.$is_dislike == 0)
                     {
                     $('*[data-postid="'+ post_id +'_d"]').removeClass('btn btn-danger').addClass('btn btn-secondary');
                     $('*[data-postid="'+ post_id +'_l"]').removeClass('btn btn-success').addClass('btn btn-secondary');
                     }
 
                 }
             })
         });
        });



    // ----------------------------------------------------

        $(document).ready(function(){
          $("#commsubm").on('click', function(){
            //
            var comment = $('#inpcomme').val();
            var post_id = $('#postid').val();
            //post_id = post_id.slice(0,-2);
          // alert('commevt');
            $.ajax({
            type: 'POST',
            url: '/comm/'+post_id,
            data: { comment: comment, _token: token },
            cache: true,
         success: function(data){
      //    //alert('success comment sent');
      //       //  عمل رفريش للصفحة 
    location.reload();
            

      
 
      
      }    
    })  
  });
});
      